"use strict";
(self["webpackChunkconnections"] = self["webpackChunkconnections"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var _guest_guest_public_landing_guest_public_landing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guest/guest-public-landing/guest-public-landing.component */ 3648);
/* harmony import */ var _shared_layout_page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared/layout/page-not-found/page-not-found.component */ 742);
/* harmony import */ var _connections_connection_central_connection_central_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./connections/connection-central/connection-central.component */ 7844);
/* harmony import */ var _connections_create_connections_create_connections_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./connections/create-connections/create-connections.component */ 7185);
/* harmony import */ var _connections_get_connections_get_connections_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./connections/get-connections/get-connections.component */ 7462);
/* harmony import */ var _connections_update_connections_update_connections_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./connections/update-connections/update-connections.component */ 4185);
/* harmony import */ var _connections_delete_connections_delete_connections_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./connections/delete-connections/delete-connections.component */ 4119);
/* harmony import */ var _quest_quest_rewards_page_quest_rewards_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./quest/quest-rewards-page/quest-rewards-page.component */ 9098);
/* harmony import */ var _features_theme_switcher_theme_switcher_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/theme-switcher/theme-switcher.component */ 9963);
/* harmony import */ var _features_epris_page_red_page_red_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./features-epris/page-red/page-red.component */ 7390);
/* harmony import */ var _features_epris_page_blue_page_blue_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./features-epris/page-blue/page-blue.component */ 6095);
/* harmony import */ var _features_epris_page_purple_page_purple_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./features-epris/page-purple/page-purple.component */ 4075);
/* harmony import */ var _features_epris_page_gray_page_gray_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./features-epris/page-gray/page-gray.component */ 8536);
/* harmony import */ var _organization_organization_landing_organization_landing_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./organization/organization-landing/organization-landing.component */ 3401);
/* harmony import */ var _organization_create_organization_create_organization_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./organization/create-organization/create-organization.component */ 1384);
/* harmony import */ var _organization_get_organization_get_organization_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./organization/get-organization/get-organization.component */ 6133);
/* harmony import */ var _organization_update_organization_update_organization_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./organization/update-organization/update-organization.component */ 9515);
/* harmony import */ var _organization_delete_organization_delete_organization_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./organization/delete-organization/delete-organization.component */ 1957);
/* harmony import */ var _events_events_landing_events_landing_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./events/events-landing/events-landing.component */ 558);
/* harmony import */ var _events_create_events_create_events_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./events/create-events/create-events.component */ 1312);
/* harmony import */ var _events_get_events_get_events_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./events/get-events/get-events.component */ 8101);
/* harmony import */ var _events_update_events_update_events_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./events/update-events/update-events.component */ 4008);
/* harmony import */ var _events_delete_events_delete_events_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./events/delete-events/delete-events.component */ 3797);
/* harmony import */ var _shared_roles_role_landing_role_landing_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./shared/roles/role-landing/role-landing.component */ 5974);
/* harmony import */ var _shared_roles_create_roles_create_roles_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./shared/roles/create-roles/create-roles.component */ 1758);
/* harmony import */ var _shared_roles_get_roles_get_roles_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./shared/roles/get-roles/get-roles.component */ 2536);
/* harmony import */ var _shared_roles_update_roles_update_roles_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./shared/roles/update-roles/update-roles.component */ 5337);
/* harmony import */ var _shared_roles_delete_roles_delete_roles_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./shared/roles/delete-roles/delete-roles.component */ 8178);
/* harmony import */ var _shared_links_links_landing_links_landing_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./shared/links/links-landing/links-landing.component */ 624);
/* harmony import */ var _shared_pii_pii_landing_pii_landing_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./shared/pii/pii-landing/pii-landing.component */ 899);
/* harmony import */ var _shared_pii_create_pii_create_pii_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./shared/pii/create-pii/create-pii.component */ 2950);
/* harmony import */ var _shared_pii_get_pii_get_pii_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./shared/pii/get-pii/get-pii.component */ 1351);
/* harmony import */ var _shared_pii_update_pii_update_pii_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./shared/pii/update-pii/update-pii.component */ 7285);
/* harmony import */ var _shared_pii_delete_pii_delete_pii_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./shared/pii/delete-pii/delete-pii.component */ 5758);
/* harmony import */ var _shared_tags_tag_landing_tag_landing_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./shared/tags/tag-landing/tag-landing.component */ 7322);
/* harmony import */ var _shared_tags_create_tags_create_tags_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./shared/tags/create-tags/create-tags.component */ 4768);
/* harmony import */ var _shared_tags_get_tags_get_tags_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./shared/tags/get-tags/get-tags.component */ 9904);
/* harmony import */ var _shared_tags_update_tags_update_tags_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./shared/tags/update-tags/update-tags.component */ 4938);
/* harmony import */ var _shared_tags_delete_tags_delete_tags_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./shared/tags/delete-tags/delete-tags.component */ 404);
/* harmony import */ var _features_crud_crud_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./features/crud/crud.component */ 9266);
/* harmony import */ var _shared_links_get_links_get_links_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./shared/links/get-links/get-links.component */ 3576);
/* harmony import */ var _shared_links_create_links_create_links_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./shared/links/create-links/create-links.component */ 5217);
/* harmony import */ var _shared_links_delete_links_delete_links_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./shared/links/delete-links/delete-links.component */ 3976);
/* harmony import */ var _shared_links_update_links_update_links_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./shared/links/update-links/update-links.component */ 3849);
/* harmony import */ var _shared_journey_journey_landing_journey_landing_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./shared/journey/journey-landing/journey-landing.component */ 6671);
/* harmony import */ var _shared_trigger_trigger_landing_trigger_landing_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./shared/trigger/trigger-landing/trigger-landing.component */ 4666);
/* harmony import */ var _features_qr_code_generator_qr_code_generator_component__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./features/qr-code-generator/qr-code-generator.component */ 5308);
/* harmony import */ var _event_management_organization_manager_organization_manager_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./event-management/organization-manager/organization-manager.component */ 5233);
/* harmony import */ var _features_michael_profile_loader_profile_loader_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./features-michael/profile-loader/profile-loader.component */ 3156);
/* harmony import */ var _features_michael_qr_reader_qr_reader_component__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./features-michael/qr-reader/qr-reader.component */ 5093);
/* harmony import */ var _qr_save_mock_qr_code_save_qr_code_save_component__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./qr-save-mock/qr-code-save/qr-code-save.component */ 584);
/* harmony import */ var _qr_save_mock_qr_code_display_qr_code_display_component__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./qr-save-mock/qr-code-display/qr-code-display.component */ 9074);
/* harmony import */ var _features_image_uploader_image_uploader_component__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./features/image-uploader/image-uploader.component */ 6687);
/* harmony import */ var _quest_badge_landing_badge_landing_component__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./quest/badge-landing/badge-landing.component */ 5027);
/* harmony import */ var _quest_create_badge_create_badge_component__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./quest/create-badge/create-badge.component */ 3366);
/* harmony import */ var _quest_get_badge_get_badge_component__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./quest/get-badge/get-badge.component */ 2207);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! @angular/core */ 4650);



























































const routes = [{
  path: 'guest',
  component: _guest_guest_public_landing_guest_public_landing_component__WEBPACK_IMPORTED_MODULE_0__.GuestPublicLandingComponent
}, {
  path: 'page-not-found',
  component: _shared_layout_page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_1__.PageNotFoundComponent
}, {
  path: 'connections',
  component: _connections_connection_central_connection_central_component__WEBPACK_IMPORTED_MODULE_2__.ConnectionCentralComponent
}, {
  path: 'get-connection',
  component: _connections_get_connections_get_connections_component__WEBPACK_IMPORTED_MODULE_4__.GetConnectionsComponent
}, {
  path: 'create-connection',
  component: _connections_create_connections_create_connections_component__WEBPACK_IMPORTED_MODULE_3__.CreateConnectionsComponent
}, {
  path: 'delete-connection',
  component: _connections_delete_connections_delete_connections_component__WEBPACK_IMPORTED_MODULE_6__.DeleteConnectionsComponent
}, {
  path: 'update-connection',
  component: _connections_update_connections_update_connections_component__WEBPACK_IMPORTED_MODULE_5__.UpdateConnectionsComponent
}, {
  path: 'quests',
  component: _quest_quest_rewards_page_quest_rewards_page_component__WEBPACK_IMPORTED_MODULE_7__.QuestRewardsPageComponent
}, {
  path: 'theme',
  component: _features_theme_switcher_theme_switcher_component__WEBPACK_IMPORTED_MODULE_8__.ThemeSwitcherComponent
}, {
  path: 'gray',
  component: _features_epris_page_gray_page_gray_component__WEBPACK_IMPORTED_MODULE_12__.PageGrayComponent
}, {
  path: 'crud',
  component: _features_crud_crud_component__WEBPACK_IMPORTED_MODULE_39__.CrudComponent
}, {
  path: 'blue',
  component: _features_epris_page_blue_page_blue_component__WEBPACK_IMPORTED_MODULE_10__.PageBlueComponent
}, {
  path: 'purple',
  component: _features_epris_page_purple_page_purple_component__WEBPACK_IMPORTED_MODULE_11__.PagePurpleComponent
}, {
  path: 'red',
  component: _features_epris_page_red_page_red_component__WEBPACK_IMPORTED_MODULE_9__.PageRedComponent
}, {
  path: 'events',
  component: _events_events_landing_events_landing_component__WEBPACK_IMPORTED_MODULE_18__.EventsLandingComponent
}, {
  path: 'get-event',
  component: _events_get_events_get_events_component__WEBPACK_IMPORTED_MODULE_20__.GetEventsComponent
}, {
  path: 'create-event',
  component: _events_create_events_create_events_component__WEBPACK_IMPORTED_MODULE_19__.CreateEventsComponent
}, {
  path: 'delete-event',
  component: _events_delete_events_delete_events_component__WEBPACK_IMPORTED_MODULE_22__.DeleteEventsComponent
}, {
  path: 'update-event',
  component: _events_update_events_update_events_component__WEBPACK_IMPORTED_MODULE_21__.UpdateEventsComponent
}, {
  path: 'organization',
  component: _organization_organization_landing_organization_landing_component__WEBPACK_IMPORTED_MODULE_13__.OrganizationLandingComponent
}, {
  path: 'get-organization',
  component: _organization_get_organization_get_organization_component__WEBPACK_IMPORTED_MODULE_15__.GetOrganizationComponent
}, {
  path: 'create-organization',
  component: _organization_create_organization_create_organization_component__WEBPACK_IMPORTED_MODULE_14__.CreateOrganizationComponent
}, {
  path: 'delete-organization',
  component: _organization_delete_organization_delete_organization_component__WEBPACK_IMPORTED_MODULE_17__.DeleteOrganizationComponent
}, {
  path: 'update-organization',
  component: _organization_update_organization_update_organization_component__WEBPACK_IMPORTED_MODULE_16__.UpdateOrganizationComponent
}, {
  path: 'get-link',
  component: _shared_links_get_links_get_links_component__WEBPACK_IMPORTED_MODULE_40__.GetLinksComponent
}, {
  path: 'create-link',
  component: _shared_links_create_links_create_links_component__WEBPACK_IMPORTED_MODULE_41__.CreateLinksComponent
}, {
  path: 'delete-link',
  component: _shared_links_delete_links_delete_links_component__WEBPACK_IMPORTED_MODULE_42__.DeleteLinksComponent
}, {
  path: 'update-link',
  component: _shared_links_update_links_update_links_component__WEBPACK_IMPORTED_MODULE_43__.UpdateLinksComponent
}, {
  path: 'roles',
  component: _shared_roles_role_landing_role_landing_component__WEBPACK_IMPORTED_MODULE_23__.RoleLandingComponent
}, {
  path: 'get-role',
  component: _shared_roles_get_roles_get_roles_component__WEBPACK_IMPORTED_MODULE_25__.GetRolesComponent
}, {
  path: 'create-role',
  component: _shared_roles_create_roles_create_roles_component__WEBPACK_IMPORTED_MODULE_24__.CreateRolesComponent
}, {
  path: 'delete-role',
  component: _shared_roles_delete_roles_delete_roles_component__WEBPACK_IMPORTED_MODULE_27__.DeleteRolesComponent
}, {
  path: 'update-role',
  component: _shared_roles_update_roles_update_roles_component__WEBPACK_IMPORTED_MODULE_26__.UpdateRolesComponent
}, {
  path: 'links',
  component: _shared_links_links_landing_links_landing_component__WEBPACK_IMPORTED_MODULE_28__.LinksLandingComponent
}, {
  path: 'tags',
  component: _shared_tags_tag_landing_tag_landing_component__WEBPACK_IMPORTED_MODULE_34__.TagLandingComponent
}, {
  path: 'get-tag',
  component: _shared_tags_get_tags_get_tags_component__WEBPACK_IMPORTED_MODULE_36__.GetTagsComponent
}, {
  path: 'create-tag',
  component: _shared_tags_create_tags_create_tags_component__WEBPACK_IMPORTED_MODULE_35__.CreateTagsComponent
}, {
  path: 'delete-tag',
  component: _shared_tags_delete_tags_delete_tags_component__WEBPACK_IMPORTED_MODULE_38__.DeleteTagsComponent
}, {
  path: 'update-tag',
  component: _shared_tags_update_tags_update_tags_component__WEBPACK_IMPORTED_MODULE_37__.UpdateTagsComponent
}, {
  path: 'pii',
  component: _shared_pii_pii_landing_pii_landing_component__WEBPACK_IMPORTED_MODULE_29__.PiiLandingComponent
}, {
  path: 'get-pii',
  component: _shared_pii_get_pii_get_pii_component__WEBPACK_IMPORTED_MODULE_31__.GetPiiComponent
}, {
  path: 'create-pii',
  component: _shared_pii_create_pii_create_pii_component__WEBPACK_IMPORTED_MODULE_30__.CreatePiiComponent
}, {
  path: 'delete-pii',
  component: _shared_pii_delete_pii_delete_pii_component__WEBPACK_IMPORTED_MODULE_33__.DeletePiiComponent
}, {
  path: 'update-pii',
  component: _shared_pii_update_pii_update_pii_component__WEBPACK_IMPORTED_MODULE_32__.UpdatePiiComponent
},
// { path: 'quest', component: PiiLandingComponent },
{
  path: 'journey',
  component: _shared_journey_journey_landing_journey_landing_component__WEBPACK_IMPORTED_MODULE_44__.JourneyLandingComponent
}, {
  path: 'trigger',
  component: _shared_trigger_trigger_landing_trigger_landing_component__WEBPACK_IMPORTED_MODULE_45__.TriggerLandingComponent
}, {
  path: 'qrcode',
  component: _features_qr_code_generator_qr_code_generator_component__WEBPACK_IMPORTED_MODULE_46__.QrCodeGeneratorComponent
}, {
  path: 'org-event',
  component: _event_management_organization_manager_organization_manager_component__WEBPACK_IMPORTED_MODULE_47__.OrganizationManagerComponent
}, {
  path: 'qrcode-reader',
  component: _features_michael_qr_reader_qr_reader_component__WEBPACK_IMPORTED_MODULE_49__.QrReaderComponent
}, {
  path: 'profile-loader',
  component: _features_michael_profile_loader_profile_loader_component__WEBPACK_IMPORTED_MODULE_48__.ProfileLoaderComponent
}, {
  path: 'qr-code-save',
  component: _qr_save_mock_qr_code_save_qr_code_save_component__WEBPACK_IMPORTED_MODULE_50__.QrCodeSaveComponent
}, {
  path: 'qr-code-display',
  component: _qr_save_mock_qr_code_display_qr_code_display_component__WEBPACK_IMPORTED_MODULE_51__.QrCodeDisplayComponent
}, {
  path: 'image-uploader',
  component: _features_image_uploader_image_uploader_component__WEBPACK_IMPORTED_MODULE_52__.ImageUploaderComponent
}, {
  path: 'badge',
  component: _quest_badge_landing_badge_landing_component__WEBPACK_IMPORTED_MODULE_53__.BadgeLandingComponent
}, {
  path: 'create-badge',
  component: _quest_create_badge_create_badge_component__WEBPACK_IMPORTED_MODULE_54__.CreateBadgeComponent
}, {
  path: 'get-badge',
  component: _quest_get_badge_get_badge_component__WEBPACK_IMPORTED_MODULE_55__.GetBadgeComponent
}, {
  path: '',
  redirectTo: 'guest',
  pathMatch: 'full'
}, {
  path: '**',
  redirectTo: 'page-not-found'
}];
let AppRoutingModule = /*#__PURE__*/(() => {
  class AppRoutingModule {
    static #_ = this.ɵfac = function AppRoutingModule_Factory(t) {
      return new (t || AppRoutingModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_56__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_56__["ɵɵdefineInjector"]({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_57__.RouterModule.forRoot(routes), _angular_router__WEBPACK_IMPORTED_MODULE_57__.RouterModule]
    });
  }
  return AppRoutingModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_56__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_57__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_57__.RouterModule]
  });
})();

/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _shared_layout_header_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shared/layout/header/header.component */ 4162);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 4793);



let AppComponent = /*#__PURE__*/(() => {
  class AppComponent {
    constructor() {
      this.title = 'Connections';
      this.headerFooter = false;
    }
    static #_ = this.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 2,
      vars: 0,
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-header")(1, "router-outlet");
        }
      },
      dependencies: [_shared_layout_header_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet]
    });
  }
  return AppComponent;
})();

/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 1481);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/shared.module */ 4466);
/* harmony import */ var _guest_guest_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./guest/guest.module */ 1277);
/* harmony import */ var _quest_quest_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./quest/quest.module */ 3014);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var _organization_organization_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./organization/organization.module */ 7197);
/* harmony import */ var _events_events_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./events/events.module */ 2734);
/* harmony import */ var _connections_connections_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./connections/connections.module */ 9243);
/* harmony import */ var _features_features_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./features/features.module */ 5790);
/* harmony import */ var _event_management_organization_manager_organization_manager_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./event-management/organization-manager/organization-manager.component */ 5233);
/* harmony import */ var _event_management_event_manager_event_manager_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./event-management/event-manager/event-manager.component */ 6551);
/* harmony import */ var _event_management_panelist_manager_panelist_manager_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./event-management/panelist-manager/panelist-manager.component */ 4538);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 7070);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _features_michael_features_michael_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./features-michael/features-michael.module */ 627);
/* harmony import */ var _qr_save_mock_qr_code_save_qr_code_save_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./qr-save-mock/qr-code-save/qr-code-save.component */ 584);
/* harmony import */ var _qr_save_mock_qr_code_display_qr_code_display_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./qr-save-mock/qr-code-display/qr-code-display.component */ 9074);
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./material/material.module */ 898);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/platform-browser/animations */ 4934);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 4650);






















let AppModule = /*#__PURE__*/(() => {
  class AppModule {
    static #_ = this.ɵfac = function AppModule_Factory(t) {
      return new (t || AppModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjector"]({
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.BrowserModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _guest_guest_module__WEBPACK_IMPORTED_MODULE_3__.GuestModule, _quest_quest_module__WEBPACK_IMPORTED_MODULE_4__.QuestModule, _organization_organization_module__WEBPACK_IMPORTED_MODULE_5__.OrganizationModule, _events_events_module__WEBPACK_IMPORTED_MODULE_6__.EventsModule, _connections_connections_module__WEBPACK_IMPORTED_MODULE_7__.ConnectionsModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_18__.HttpClientModule, _features_features_module__WEBPACK_IMPORTED_MODULE_8__.FeaturesModule, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_19__.NgxQRCodeModule, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.FormsModule, _features_michael_features_michael_module__WEBPACK_IMPORTED_MODULE_12__.FeaturesMichaelModule, _material_material_module__WEBPACK_IMPORTED_MODULE_15__.MaterialModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_21__.BrowserAnimationsModule]
    });
  }
  return AppModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _event_management_organization_manager_organization_manager_component__WEBPACK_IMPORTED_MODULE_9__.OrganizationManagerComponent, _event_management_event_manager_event_manager_component__WEBPACK_IMPORTED_MODULE_10__.EventManagerComponent, _event_management_panelist_manager_panelist_manager_component__WEBPACK_IMPORTED_MODULE_11__.PanelistManagerComponent, _qr_save_mock_qr_code_save_qr_code_save_component__WEBPACK_IMPORTED_MODULE_13__.QrCodeSaveComponent, _qr_save_mock_qr_code_display_qr_code_display_component__WEBPACK_IMPORTED_MODULE_14__.QrCodeDisplayComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.BrowserModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _guest_guest_module__WEBPACK_IMPORTED_MODULE_3__.GuestModule, _quest_quest_module__WEBPACK_IMPORTED_MODULE_4__.QuestModule, _organization_organization_module__WEBPACK_IMPORTED_MODULE_5__.OrganizationModule, _events_events_module__WEBPACK_IMPORTED_MODULE_6__.EventsModule, _connections_connections_module__WEBPACK_IMPORTED_MODULE_7__.ConnectionsModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_18__.HttpClientModule, _features_features_module__WEBPACK_IMPORTED_MODULE_8__.FeaturesModule, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_19__.NgxQRCodeModule, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.FormsModule, _features_michael_features_michael_module__WEBPACK_IMPORTED_MODULE_12__.FeaturesMichaelModule, _material_material_module__WEBPACK_IMPORTED_MODULE_15__.MaterialModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_21__.BrowserAnimationsModule]
  });
})();

/***/ }),

/***/ 8660:
/*!******************************************************************************!*\
  !*** ./src/app/connections/block-connections/block-connections.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlockConnectionsComponent": () => (/* binding */ BlockConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let BlockConnectionsComponent = /*#__PURE__*/(() => {
  class BlockConnectionsComponent {
    static #_ = this.ɵfac = function BlockConnectionsComponent_Factory(t) {
      return new (t || BlockConnectionsComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BlockConnectionsComponent,
      selectors: [["app-block-connections"]],
      decls: 2,
      vars: 0,
      template: function BlockConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "block-connections works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return BlockConnectionsComponent;
})();

/***/ }),

/***/ 2102:
/*!**************************************************************************!*\
  !*** ./src/app/connections/connection-card/connection-card.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionCardComponent": () => (/* binding */ ConnectionCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ConnectionCardComponent = /*#__PURE__*/(() => {
  class ConnectionCardComponent {
    static #_ = this.ɵfac = function ConnectionCardComponent_Factory(t) {
      return new (t || ConnectionCardComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ConnectionCardComponent,
      selectors: [["app-connection-card"]],
      decls: 2,
      vars: 0,
      template: function ConnectionCardComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "connection-card works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return ConnectionCardComponent;
})();

/***/ }),

/***/ 7844:
/*!********************************************************************************!*\
  !*** ./src/app/connections/connection-central/connection-central.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionCentralComponent": () => (/* binding */ ConnectionCentralComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let ConnectionCentralComponent = /*#__PURE__*/(() => {
  class ConnectionCentralComponent {
    constructor(router) {
      this.router = router;
    }
    onGetConnection() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-connection');
    }
    onCreateConnection() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-connection');
    }
    onDeleteConnection() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-connection');
    }
    onUpdateConnection() {
      this.router.navigateByUrl('/update-connection');
    }
    static #_ = this.ɵfac = function ConnectionCentralComponent_Factory(t) {
      return new (t || ConnectionCentralComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ConnectionCentralComponent,
      selectors: [["app-connection-central"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function ConnectionCentralComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConnectionCentralComponent_Template_button_click_5_listener() {
            return ctx.onGetConnection();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConnectionCentralComponent_Template_button_click_7_listener() {
            return ctx.onCreateConnection();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConnectionCentralComponent_Template_button_click_9_listener() {
            return ctx.onDeleteConnection();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConnectionCentralComponent_Template_button_click_11_listener() {
            return ctx.onUpdateConnection();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return ConnectionCentralComponent;
})();

/***/ }),

/***/ 6008:
/*!********************************************************************************!*\
  !*** ./src/app/connections/connection-landing/connection-landing.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionLandingComponent": () => (/* binding */ ConnectionLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ConnectionLandingComponent = /*#__PURE__*/(() => {
  class ConnectionLandingComponent {
    static #_ = this.ɵfac = function ConnectionLandingComponent_Factory(t) {
      return new (t || ConnectionLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ConnectionLandingComponent,
      selectors: [["app-connection-landing"]],
      decls: 2,
      vars: 0,
      template: function ConnectionLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "connection-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return ConnectionLandingComponent;
})();

/***/ }),

/***/ 9243:
/*!***************************************************!*\
  !*** ./src/app/connections/connections.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionsModule": () => (/* binding */ ConnectionsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _connection_central_connection_central_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./connection-central/connection-central.component */ 7844);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 4466);
/* harmony import */ var _get_connections_get_connections_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./get-connections/get-connections.component */ 7462);
/* harmony import */ var _create_connections_create_connections_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-connections/create-connections.component */ 7185);
/* harmony import */ var _connection_card_connection_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./connection-card/connection-card.component */ 2102);
/* harmony import */ var _update_connections_update_connections_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./update-connections/update-connections.component */ 4185);
/* harmony import */ var _block_connections_block_connections_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./block-connections/block-connections.component */ 8660);
/* harmony import */ var _remove_connections_remove_connections_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./remove-connections/remove-connections.component */ 8289);
/* harmony import */ var _get_groups_get_groups_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./get-groups/get-groups.component */ 1180);
/* harmony import */ var _create_groups_create_groups_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./create-groups/create-groups.component */ 432);
/* harmony import */ var _delete_connections_delete_connections_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./delete-connections/delete-connections.component */ 4119);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _connection_landing_connection_landing_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./connection-landing/connection-landing.component */ 6008);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 4650);















let ConnectionsModule = /*#__PURE__*/(() => {
  class ConnectionsModule {
    static #_ = this.ɵfac = function ConnectionsModule_Factory(t) {
      return new (t || ConnectionsModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({
      type: ConnectionsModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule]
    });
  }
  return ConnectionsModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetNgModuleScope"](ConnectionsModule, {
    declarations: [_connection_central_connection_central_component__WEBPACK_IMPORTED_MODULE_0__.ConnectionCentralComponent, _get_connections_get_connections_component__WEBPACK_IMPORTED_MODULE_2__.GetConnectionsComponent, _create_connections_create_connections_component__WEBPACK_IMPORTED_MODULE_3__.CreateConnectionsComponent, _connection_card_connection_card_component__WEBPACK_IMPORTED_MODULE_4__.ConnectionCardComponent, _update_connections_update_connections_component__WEBPACK_IMPORTED_MODULE_5__.UpdateConnectionsComponent, _block_connections_block_connections_component__WEBPACK_IMPORTED_MODULE_6__.BlockConnectionsComponent, _remove_connections_remove_connections_component__WEBPACK_IMPORTED_MODULE_7__.RemoveConnectionsComponent, _get_groups_get_groups_component__WEBPACK_IMPORTED_MODULE_8__.GetGroupsComponent, _create_groups_create_groups_component__WEBPACK_IMPORTED_MODULE_9__.CreateGroupsComponent, _delete_connections_delete_connections_component__WEBPACK_IMPORTED_MODULE_10__.DeleteConnectionsComponent, _connection_landing_connection_landing_component__WEBPACK_IMPORTED_MODULE_11__.ConnectionLandingComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule],
    exports: [_connection_central_connection_central_component__WEBPACK_IMPORTED_MODULE_0__.ConnectionCentralComponent]
  });
})();

/***/ }),

/***/ 7185:
/*!********************************************************************************!*\
  !*** ./src/app/connections/create-connections/create-connections.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateConnectionsComponent": () => (/* binding */ CreateConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/connection.service */ 5684);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateConnectionsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Connection User ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateConnectionsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Username is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateConnectionsComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "First Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateConnectionsComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Last Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateConnectionsComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Email is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateConnectionsComponent = /*#__PURE__*/(() => {
  class CreateConnectionsComponent {
    constructor(connService, fb) {
      this.connService = connService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.connectionForm = this.fb.group({
        connection_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        first_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        last_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        alternate_string: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.connectionForm.valid) {
      event.preventDefault();
      console.log('Conn Form Value', this.connectionForm.value);
      //create connection call
      //use subscribe with next and error object as per new standard
      this.connService.createConnection(this.connectionForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.connectionForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Conn completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateConnectionsComponent_Factory(t) {
      return new (t || CreateConnectionsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__.ConnectionService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateConnectionsComponent,
      selectors: [["app-create-connections"]],
      decls: 39,
      vars: 7,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "number", "placeholder", "Enter User ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "username", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "username", "id", "username", "type", "text", "placeholder", "Enter Connection Username", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "first_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "first_name", "id", "first_name", "type", "text", "placeholder", "Enter Connection First Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "last_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "last_name", "id", "last_name", "type", "text", "placeholder", "Enter Connection Last Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Connection Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "CONNECTION DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateConnectionsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Connection User ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, CreateConnectionsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Connection Username");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, CreateConnectionsComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Connection First Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](23, CreateConnectionsComponent_div_23_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 4)(25, "label", 12)(26, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Connection Last Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](29, CreateConnectionsComponent_div_29_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "div", 4)(31, "label", 14)(32, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](33, "Connection Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](34, "input", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](35, CreateConnectionsComponent_div_35_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "div", 16)(37, "button", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](38, " Create Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_4_0;
          let tmp_5_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.connectionForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionForm && (ctx.connectionForm == null ? null : (tmp_1_0 = ctx.connectionForm.get("user_id")) == null ? null : tmp_1_0.invalid) && ((ctx.connectionForm == null ? null : (tmp_1_0 = ctx.connectionForm.get("user_id")) == null ? null : tmp_1_0.dirty) || (ctx.connectionForm == null ? null : (tmp_1_0 = ctx.connectionForm.get("user_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionForm && (ctx.connectionForm == null ? null : (tmp_2_0 = ctx.connectionForm.get("username")) == null ? null : tmp_2_0.invalid) && ((ctx.connectionForm == null ? null : (tmp_2_0 = ctx.connectionForm.get("username")) == null ? null : tmp_2_0.dirty) || (ctx.connectionForm == null ? null : (tmp_2_0 = ctx.connectionForm.get("username")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionForm && (ctx.connectionForm == null ? null : (tmp_3_0 = ctx.connectionForm.get("first_name")) == null ? null : tmp_3_0.invalid) && ((ctx.connectionForm == null ? null : (tmp_3_0 = ctx.connectionForm.get("first_name")) == null ? null : tmp_3_0.dirty) || (ctx.connectionForm == null ? null : (tmp_3_0 = ctx.connectionForm.get("first_name")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionForm && (ctx.connectionForm == null ? null : (tmp_4_0 = ctx.connectionForm.get("last_name")) == null ? null : tmp_4_0.invalid) && ((ctx.connectionForm == null ? null : (tmp_4_0 = ctx.connectionForm.get("last_name")) == null ? null : tmp_4_0.dirty) || (ctx.connectionForm == null ? null : (tmp_4_0 = ctx.connectionForm.get("last_name")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionForm && (ctx.connectionForm == null ? null : (tmp_5_0 = ctx.connectionForm.get("email")) == null ? null : tmp_5_0.invalid) && ((ctx.connectionForm == null ? null : (tmp_5_0 = ctx.connectionForm.get("email")) == null ? null : tmp_5_0.dirty) || (ctx.connectionForm == null ? null : (tmp_5_0 = ctx.connectionForm.get("email")) == null ? null : tmp_5_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.connectionForm && ctx.connectionForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateConnectionsComponent;
})();

/***/ }),

/***/ 432:
/*!**********************************************************************!*\
  !*** ./src/app/connections/create-groups/create-groups.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateGroupsComponent": () => (/* binding */ CreateGroupsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let CreateGroupsComponent = /*#__PURE__*/(() => {
  class CreateGroupsComponent {
    static #_ = this.ɵfac = function CreateGroupsComponent_Factory(t) {
      return new (t || CreateGroupsComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: CreateGroupsComponent,
      selectors: [["app-create-groups"]],
      decls: 2,
      vars: 0,
      template: function CreateGroupsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-groups works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return CreateGroupsComponent;
})();

/***/ }),

/***/ 4119:
/*!********************************************************************************!*\
  !*** ./src/app/connections/delete-connections/delete-connections.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteConnectionsComponent": () => (/* binding */ DeleteConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/connection.service */ 5684);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteConnectionsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Connection ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteConnectionsComponent = /*#__PURE__*/(() => {
  class DeleteConnectionsComponent {
    constructor(connService, fb) {
      this.connService = connService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        connId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteConnection() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.connId;
        this.connService.deleteConnections(id).subscribe({
          next: response => {
            console.log('Connection deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting connection:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteConnectionsComponent_Factory(t) {
      return new (t || DeleteConnectionsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__.ConnectionService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteConnectionsComponent,
      selectors: [["app-delete-connections"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "connId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "connId", "id", "connId", "type", "number", "placeholder", "Enter Conn ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteConnectionsComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteConnection();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Connection ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteConnectionsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("connId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("connId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("connId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteConnectionsComponent;
})();

/***/ }),

/***/ 7462:
/*!**************************************************************************!*\
  !*** ./src/app/connections/get-connections/get-connections.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetConnectionsComponent": () => (/* binding */ GetConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/connection.service */ 5684);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);



function GetConnectionsComponent_div_5_li_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const connection_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"]("", connection_r4.username, " , ", connection_r4.user_id, "");
  }
}
function GetConnectionsComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, GetConnectionsComponent_div_5_li_2_Template, 2, 2, "li", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.connections);
  }
}
function GetConnectionsComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0, " No connections found.\n");
  }
}
let GetConnectionsComponent = /*#__PURE__*/(() => {
  class GetConnectionsComponent {
    constructor(connService) {
      this.connService = connService;
      this.connections = [];
    }
    ngOnInit() {
      //get all connections
      this.connService.getConnections().subscribe({
        next: data => {
          this.connections = data;
          console.log('Connections:', this.connections);
        },
        error: error => {
          console.error('Error fetching connections:', error);
        },
        complete: () => {
          console.log('Request to fetch Connection completed');
        }
      });
    }
    static #_ = this.ɵfac = function GetConnectionsComponent_Factory(t) {
      return new (t || GetConnectionsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__.ConnectionService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetConnectionsComponent,
      selectors: [["app-get-connections"]],
      decls: 8,
      vars: 2,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-full"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [4, "ngIf", "ngIfElse"], ["noData", ""], [4, "ngFor", "ngForOf"]],
      template: function GetConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "CONNECTION NAME & ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, GetConnectionsComponent_div_5_Template, 3, 1, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GetConnectionsComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connections.length > 0)("ngIfElse", _r1);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf]
    });
  }
  return GetConnectionsComponent;
})();

/***/ }),

/***/ 1180:
/*!****************************************************************!*\
  !*** ./src/app/connections/get-groups/get-groups.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetGroupsComponent": () => (/* binding */ GetGroupsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let GetGroupsComponent = /*#__PURE__*/(() => {
  class GetGroupsComponent {
    static #_ = this.ɵfac = function GetGroupsComponent_Factory(t) {
      return new (t || GetGroupsComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: GetGroupsComponent,
      selectors: [["app-get-groups"]],
      decls: 2,
      vars: 0,
      template: function GetGroupsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "get-groups works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return GetGroupsComponent;
})();

/***/ }),

/***/ 8289:
/*!********************************************************************************!*\
  !*** ./src/app/connections/remove-connections/remove-connections.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RemoveConnectionsComponent": () => (/* binding */ RemoveConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let RemoveConnectionsComponent = /*#__PURE__*/(() => {
  class RemoveConnectionsComponent {
    static #_ = this.ɵfac = function RemoveConnectionsComponent_Factory(t) {
      return new (t || RemoveConnectionsComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: RemoveConnectionsComponent,
      selectors: [["app-remove-connections"]],
      decls: 2,
      vars: 0,
      template: function RemoveConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "remove-connections works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return RemoveConnectionsComponent;
})();

/***/ }),

/***/ 4185:
/*!********************************************************************************!*\
  !*** ./src/app/connections/update-connections/update-connections.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateConnectionsComponent": () => (/* binding */ UpdateConnectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/connection.service */ 5684);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdateConnectionsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Connection User ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateConnectionsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Username is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateConnectionsComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "First Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateConnectionsComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Last Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateConnectionsComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Email is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateConnectionsComponent = /*#__PURE__*/(() => {
  class UpdateConnectionsComponent {
    constructor(connService, fb) {
      this.connService = connService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.connectionUpdatedForm = this.fb.group({
        connection_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        first_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        last_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        alternate_string: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log('Connection Updated Form Value', this.connectionUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.connService.updateConnection(this.connectionUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.connectionUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated Connection completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateConnectionsComponent_Factory(t) {
      return new (t || UpdateConnectionsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__.ConnectionService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateConnectionsComponent,
      selectors: [["app-update-connections"]],
      decls: 39,
      vars: 7,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "number", "placeholder", "Enter User ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "username", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "username", "id", "username", "type", "text", "placeholder", "Enter Connection Username", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "first_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "first_name", "id", "first_name", "type", "text", "placeholder", "Enter Connection First Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "last_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "last_name", "id", "last_name", "type", "text", "placeholder", "Enter Connection Last Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Connection Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdateConnectionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE CONNECTION DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateConnectionsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Connection User ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateConnectionsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Connection Username");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, UpdateConnectionsComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Connection First Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](23, UpdateConnectionsComponent_div_23_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 4)(25, "label", 12)(26, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Connection Last Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](29, UpdateConnectionsComponent_div_29_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "div", 4)(31, "label", 14)(32, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](33, "Connection Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](34, "input", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](35, UpdateConnectionsComponent_div_35_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "div", 16)(37, "button", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](38, " Update Connection ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_4_0;
          let tmp_5_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.connectionUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionUpdatedForm && (ctx.connectionUpdatedForm == null ? null : (tmp_1_0 = ctx.connectionUpdatedForm.get("user_id")) == null ? null : tmp_1_0.invalid) && ((ctx.connectionUpdatedForm == null ? null : (tmp_1_0 = ctx.connectionUpdatedForm.get("user_id")) == null ? null : tmp_1_0.dirty) || (ctx.connectionUpdatedForm == null ? null : (tmp_1_0 = ctx.connectionUpdatedForm.get("user_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionUpdatedForm && (ctx.connectionUpdatedForm == null ? null : (tmp_2_0 = ctx.connectionUpdatedForm.get("username")) == null ? null : tmp_2_0.invalid) && ((ctx.connectionUpdatedForm == null ? null : (tmp_2_0 = ctx.connectionUpdatedForm.get("username")) == null ? null : tmp_2_0.dirty) || (ctx.connectionUpdatedForm == null ? null : (tmp_2_0 = ctx.connectionUpdatedForm.get("username")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionUpdatedForm && (ctx.connectionUpdatedForm == null ? null : (tmp_3_0 = ctx.connectionUpdatedForm.get("first_name")) == null ? null : tmp_3_0.invalid) && ((ctx.connectionUpdatedForm == null ? null : (tmp_3_0 = ctx.connectionUpdatedForm.get("first_name")) == null ? null : tmp_3_0.dirty) || (ctx.connectionUpdatedForm == null ? null : (tmp_3_0 = ctx.connectionUpdatedForm.get("first_name")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionUpdatedForm && (ctx.connectionUpdatedForm == null ? null : (tmp_4_0 = ctx.connectionUpdatedForm.get("last_name")) == null ? null : tmp_4_0.invalid) && ((ctx.connectionUpdatedForm == null ? null : (tmp_4_0 = ctx.connectionUpdatedForm.get("last_name")) == null ? null : tmp_4_0.dirty) || (ctx.connectionUpdatedForm == null ? null : (tmp_4_0 = ctx.connectionUpdatedForm.get("last_name")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.connectionUpdatedForm && (ctx.connectionUpdatedForm == null ? null : (tmp_5_0 = ctx.connectionUpdatedForm.get("email")) == null ? null : tmp_5_0.invalid) && ((ctx.connectionUpdatedForm == null ? null : (tmp_5_0 = ctx.connectionUpdatedForm.get("email")) == null ? null : tmp_5_0.dirty) || (ctx.connectionUpdatedForm == null ? null : (tmp_5_0 = ctx.connectionUpdatedForm.get("email")) == null ? null : tmp_5_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.connectionUpdatedForm && ctx.connectionUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdateConnectionsComponent;
})();

/***/ }),

/***/ 5953:
/*!*********************************************!*\
  !*** ./src/app/core/pipes/initials.pipe.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InitialsPipe": () => (/* binding */ InitialsPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let InitialsPipe = /*#__PURE__*/(() => {
  class InitialsPipe {
    transform(fullName) {
      if (!fullName) return '';
      const nameParts = fullName.split(' ');
      return nameParts.map(part => part.charAt(0).toUpperCase()).join('');
    }
    static #_ = this.ɵfac = function InitialsPipe_Factory(t) {
      return new (t || InitialsPipe)();
    };
    static #_2 = this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
      name: "initials",
      type: InitialsPipe,
      pure: true
    });
  }
  return InitialsPipe;
})();

/***/ }),

/***/ 4052:
/*!************************************************!*\
  !*** ./src/app/core/services/badge.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BadgeService": () => (/* binding */ BadgeService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 262);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);





let BadgeService = /*#__PURE__*/(() => {
  class BadgeService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getBadge(badge_id) {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_badges + '/GetBadge/' + badge_id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createBadge(badge) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_badges + '/AddBadge/', JSON.stringify(badge), this.httpOptions).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function BadgeService_Factory(t) {
      return new (t || BadgeService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: BadgeService,
      factory: BadgeService.ɵfac,
      providedIn: 'root'
    });
  }
  return BadgeService;
})();

/***/ }),

/***/ 5684:
/*!*****************************************************!*\
  !*** ./src/app/core/services/connection.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConnectionService": () => (/* binding */ ConnectionService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let ConnectionService = /*#__PURE__*/(() => {
  class ConnectionService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.apiURL = 'http://api.mozli.com/Biodata';
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getConnections() {
      return this.httpClient.get(this.apiURL + '/GetConnections/').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createConnection(connection) {
      return this.httpClient.post(this.apiURL + '/AddConnection/', JSON.stringify(connection), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteConnections(connection_id) {
      return this.httpClient.delete(this.apiURL + '/DeleteConnection/' + connection_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass connection id as a query parameter to update
    //right now connection id is given as req body
    updateConnection(connection) {
      return this.httpClient.put(this.apiURL + '/UpdateConnection/', JSON.stringify(connection), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    getEnvironment() {
      this.envName = src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.environmentName;
      return this.envName;
    }
    static #_ = this.ɵfac = function ConnectionService_Factory(t) {
      return new (t || ConnectionService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: ConnectionService,
      factory: ConnectionService.ɵfac,
      providedIn: 'root'
    });
  }
  return ConnectionService;
})();

/***/ }),

/***/ 3117:
/*!************************************************!*\
  !*** ./src/app/core/services/event.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventService": () => (/* binding */ EventService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let EventService = /*#__PURE__*/(() => {
  class EventService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getEvents() {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_event + '/GetAllEvents/').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createEvent(event) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_event + '/AddEvent/', JSON.stringify(event), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteEvents(event_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_event + '/DeleteEvent/' + event_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass event id as a query parameter to update
    //right now event id is given as req body
    updateEvent(event) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_event + '/UpdateEvent/', JSON.stringify(event), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function EventService_Factory(t) {
      return new (t || EventService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: EventService,
      factory: EventService.ɵfac,
      providedIn: 'root'
    });
  }
  return EventService;
})();

/***/ }),

/***/ 7363:
/*!************************************************!*\
  !*** ./src/app/core/services/links.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LinksService": () => (/* binding */ LinksService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 262);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);





let LinksService = /*#__PURE__*/(() => {
  class LinksService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getLink(user_id) {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_socialMediLink + '/GetSocialMediaLinks/' + user_id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createLink(link) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_socialMediLink + '/AddSocialMediaLink/', JSON.stringify(link), this.httpOptions).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteLink(key_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_socialMediLink + '/DeleteSocialMediaLink/' + key_id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    updateLink(link) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_socialMediLink + '/UpdateSocialMediaLink/', JSON.stringify(link), this.httpOptions).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function LinksService_Factory(t) {
      return new (t || LinksService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: LinksService,
      factory: LinksService.ɵfac,
      providedIn: 'root'
    });
  }
  return LinksService;
})();

/***/ }),

/***/ 4261:
/*!*******************************************************!*\
  !*** ./src/app/core/services/organization.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrganizationService": () => (/* binding */ OrganizationService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let OrganizationService = /*#__PURE__*/(() => {
  class OrganizationService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getOrganizations() {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_organization + '/GetOrganizations/').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createOrganization(organization) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_organization + '/AddOrganization/', JSON.stringify(organization), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteOrganizations(organization_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_organization + '/DeleteOrganization/' + organization_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass org id as a query parameter to update
    //right now org id is given as req body 
    updateOrganization(organization) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_organization + '/UpdateOrganization/', JSON.stringify(organization), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function OrganizationService_Factory(t) {
      return new (t || OrganizationService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: OrganizationService,
      factory: OrganizationService.ɵfac,
      providedIn: 'root'
    });
  }
  return OrganizationService;
})();

/***/ }),

/***/ 8203:
/*!**********************************************!*\
  !*** ./src/app/core/services/pii.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PiiService": () => (/* binding */ PiiService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let PiiService = /*#__PURE__*/(() => {
  class PiiService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getUserPii(user_id) {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_userPii + '/GetUserPii/' + user_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createUserPii(pii) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_userPii + '/AddUserPii', JSON.stringify(pii), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteUserPii(user_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_userPii + '/DeleteUserPii/' + user_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass org id as a query parameter to update
    //right now org id is given as req body
    updateUserPii(pii) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_userPii + '/UpdateUserPii/', JSON.stringify(pii), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function PiiService_Factory(t) {
      return new (t || PiiService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: PiiService,
      factory: PiiService.ɵfac,
      providedIn: 'root'
    });
  }
  return PiiService;
})();

/***/ }),

/***/ 7245:
/*!************************************************!*\
  !*** ./src/app/core/services/roles.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RolesService": () => (/* binding */ RolesService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let RolesService = /*#__PURE__*/(() => {
  class RolesService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getUserRoles() {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_roles + '/GetAllUserRoles/').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createUserRole(role) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_roles + '/AddUserRole/', JSON.stringify(role), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteUserRoles(role_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_roles + '/DeleteUserRole/' + role_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass role id as a query parameter to update
    //right now role id is given as req body
    updateUserRole(role) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_roles + '/UpdateUserRole/', JSON.stringify(role), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function RolesService_Factory(t) {
      return new (t || RolesService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: RolesService,
      factory: RolesService.ɵfac,
      providedIn: 'root'
    });
  }
  return RolesService;
})();

/***/ }),

/***/ 3171:
/*!***********************************************!*\
  !*** ./src/app/core/services/tags.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TagsService": () => (/* binding */ TagsService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 262);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);






let TagsService = /*#__PURE__*/(() => {
  class TagsService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getTags() {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_tags + '/GetTags/').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    createTag(tag) {
      return this.httpClient.post(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_tags + '/AddTag/', JSON.stringify(tag), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    deleteTags(tag_id) {
      return this.httpClient.delete(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_tags + '/DeleteTag/' + tag_id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    //we need to pass tag id as a query parameter to update
    //right now tag id is given as req body
    updateTag(tag) {
      return this.httpClient.put(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_tags + '/UpdateTag/', JSON.stringify(tag), this.httpOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function TagsService_Factory(t) {
      return new (t || TagsService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: TagsService,
      factory: TagsService.ɵfac,
      providedIn: 'root'
    });
  }
  return TagsService;
})();

/***/ }),

/***/ 8386:
/*!***********************************************!*\
  !*** ./src/app/core/services/user.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserService": () => (/* binding */ UserService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 262);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 2843);
/* harmony import */ var src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment.dev */ 1652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);





let UserService = /*#__PURE__*/(() => {
  class UserService {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.httpOptions = {
        headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
    }
    getUserProfile(user_id) {
      return this.httpClient.get(src_environments_environment_dev__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl_user + '/GetUserProfile/' + user_id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.errorHandler));
    }
    errorHandler(error) {
      let errorMessage = '';
      if (error.error instanceof ErrorEvent) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => new Error(error.message || 'Server Error'));
    }
    static #_ = this.ɵfac = function UserService_Factory(t) {
      return new (t || UserService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
    };
    static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: UserService,
      factory: UserService.ɵfac,
      providedIn: 'root'
    });
  }
  return UserService;
})();

/***/ }),

/***/ 6551:
/*!***************************************************************************!*\
  !*** ./src/app/event-management/event-manager/event-manager.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventManagerComponent": () => (/* binding */ EventManagerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _panelist_manager_panelist_manager_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../panelist-manager/panelist-manager.component */ 4538);




function EventManagerComponent_div_11_li_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function EventManagerComponent_div_11_li_4_Template_button_click_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r5);
      const event_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r4.selectEvent(event_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Manage Panelists");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const event_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", event_r3.name, " ");
  }
}
function EventManagerComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Events In Organizaton");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, EventManagerComponent_div_11_li_4_Template, 5, 1, "li", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.organization == null ? null : ctx_r0.organization.events);
  }
}
function EventManagerComponent_app_panelist_manager_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-panelist-manager", 10);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("event", ctx_r1.selectedEvent);
  }
}
let EventManagerComponent = /*#__PURE__*/(() => {
  class EventManagerComponent {
    constructor() {
      this.newEventName = '';
      this.selectedEvent = null;
    }
    addEvent() {
      if (this.organization) {
        const newEvent = {
          id: this.organization.events.length + 1,
          name: this.newEventName,
          panelists: []
        };
        this.organization.events.push(newEvent);
        this.newEventName = '';
      }
    }
    selectEvent(event) {
      this.selectedEvent = event;
    }
    static #_ = this.ɵfac = function EventManagerComponent_Factory(t) {
      return new (t || EventManagerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: EventManagerComponent,
      selectors: [["app-event-manager"]],
      inputs: {
        organization: "organization"
      },
      decls: 15,
      vars: 4,
      consts: [[3, "ngSubmit"], [1, "mb-4"], ["for", "newEventName", 1, "block", "text-gray-700", "text-sm", "font-bold", "mb-2"], ["id", "newEventName", "type", "text", "name", "newEventName", "required", "", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline", 3, "ngModel", "ngModelChange"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [3, "event", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "click"], [3, "event"]],
      template: function EventManagerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "form", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function EventManagerComponent_Template_form_ngSubmit_3_listener() {
            return ctx.addEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 1)(5, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, " Event Name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "input", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function EventManagerComponent_Template_input_ngModelChange_7_listener($event) {
            return ctx.newEventName = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 4)(9, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, " Add Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, EventManagerComponent_div_11_Template, 5, 1, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "br");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, EventManagerComponent_app_panelist_manager_14_Template, 1, 1, "app-panelist-manager", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Manage Events for ", ctx.organization == null ? null : ctx.organization.name, "");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.newEventName);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.organization == null ? null : ctx.organization.events.length) > 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.selectedEvent);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgForm, _panelist_manager_panelist_manager_component__WEBPACK_IMPORTED_MODULE_0__.PanelistManagerComponent]
    });
  }
  return EventManagerComponent;
})();

/***/ }),

/***/ 5233:
/*!*****************************************************************************************!*\
  !*** ./src/app/event-management/organization-manager/organization-manager.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrganizationManagerComponent": () => (/* binding */ OrganizationManagerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _event_manager_event_manager_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../event-manager/event-manager.component */ 6551);




function OrganizationManagerComponent_div_11_li_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function OrganizationManagerComponent_div_11_li_4_Template_button_click_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r5);
      const org_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r4.selectOrganization(org_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Manage Events");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const org_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", org_r3.name, " ");
  }
}
function OrganizationManagerComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organizations Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, OrganizationManagerComponent_div_11_li_4_Template, 5, 1, "li", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.organizations);
  }
}
function OrganizationManagerComponent_app_event_manager_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-event-manager", 10);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("organization", ctx_r1.selectedOrganization);
  }
}
let OrganizationManagerComponent = /*#__PURE__*/(() => {
  class OrganizationManagerComponent {
    constructor() {
      this.newOrgName = '';
      this.organizations = [];
      this.selectedOrganization = null;
    }
    addOrganization() {
      const newOrg = {
        id: this.organizations.length + 1,
        name: this.newOrgName,
        events: []
      };
      this.organizations.push(newOrg);
      this.newOrgName = '';
    }
    selectOrganization(org) {
      this.selectedOrganization = org;
    }
    static #_ = this.ɵfac = function OrganizationManagerComponent_Factory(t) {
      return new (t || OrganizationManagerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: OrganizationManagerComponent,
      selectors: [["app-organization-manager"]],
      decls: 15,
      vars: 3,
      consts: [[3, "ngSubmit"], [1, "mb-4"], ["for", "newOrgName", 1, "block", "text-gray-700", "text-sm", "font-bold", "mb-2"], ["id", "newOrgName", "type", "text", "name", "newOrgName", "required", "", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline", 3, "ngModel", "ngModelChange"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [3, "organization", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "click"], [3, "organization"]],
      template: function OrganizationManagerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organizations");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "form", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function OrganizationManagerComponent_Template_form_ngSubmit_3_listener() {
            return ctx.addOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 1)(5, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, " Organization Name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "input", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function OrganizationManagerComponent_Template_input_ngModelChange_7_listener($event) {
            return ctx.newOrgName = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 4)(9, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, " Add Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, OrganizationManagerComponent_div_11_Template, 5, 1, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "br");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, OrganizationManagerComponent_app_event_manager_14_Template, 1, 1, "app-event-manager", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.newOrgName);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizations.length > 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.selectedOrganization);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgForm, _event_manager_event_manager_component__WEBPACK_IMPORTED_MODULE_0__.EventManagerComponent]
    });
  }
  return OrganizationManagerComponent;
})();

/***/ }),

/***/ 4538:
/*!*********************************************************************************!*\
  !*** ./src/app/event-management/panelist-manager/panelist-manager.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PanelistManagerComponent": () => (/* binding */ PanelistManagerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 7070);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 4006);




function PanelistManagerComponent_div_15_li_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br")(3, "ngx-qrcode", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const panelist_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", panelist_r2.name, ": ", panelist_r2.description, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", panelist_r2.qrData);
  }
}
function PanelistManagerComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Panelists in Event");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, PanelistManagerComponent_div_15_li_4_Template, 4, 3, "li", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.event == null ? null : ctx_r0.event.panelists);
  }
}
let PanelistManagerComponent = /*#__PURE__*/(() => {
  class PanelistManagerComponent {
    constructor() {
      this.newPanelistName = '';
      this.newEventDescription = '';
    }
    addPanelist() {
      if (this.event) {
        const compactString = this.createCompactString(this.newPanelistName, this.newEventDescription);
        const newPanelist = {
          id: this.event.panelists.length + 1,
          name: this.newPanelistName,
          description: this.newEventDescription,
          qrData: compactString
        };
        this.event.panelists.push(newPanelist);
        this.newPanelistName = '';
        this.newEventDescription = '';
      }
    }
    createCompactString(name, description) {
      // For simplicity, we're just concatenating the strings. You can implement any compacting algorithm you need.
      return `${name}:${description}`;
    }
    static #_ = this.ɵfac = function PanelistManagerComponent_Factory(t) {
      return new (t || PanelistManagerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PanelistManagerComponent,
      selectors: [["app-panelist-manager"]],
      inputs: {
        event: "event"
      },
      decls: 16,
      vars: 4,
      consts: [[3, "ngSubmit"], [1, "mb-4"], ["for", "panelistName", 1, "block", "text-gray-700", "text-sm", "font-bold", "mb-2"], ["id", "panelistName", "name", "newPanelistName", "required", "", "type", "text", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline", 3, "ngModel", "ngModelChange"], ["for", "eventDescription", 1, "block", "text-gray-700", "text-sm", "font-bold", "mb-2"], ["id", "eventDescription", "name", "newEventDescription", "required", "", "type", "text", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline", 3, "ngModel", "ngModelChange"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [4, "ngFor", "ngForOf"], [3, "value"]],
      template: function PanelistManagerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "form", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function PanelistManagerComponent_Template_form_ngSubmit_3_listener() {
            return ctx.addPanelist();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 1)(5, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Panelist Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PanelistManagerComponent_Template_input_ngModelChange_7_listener($event) {
            return ctx.newPanelistName = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 1)(9, "label", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Event Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "input", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PanelistManagerComponent_Template_input_ngModelChange_11_listener($event) {
            return ctx.newEventDescription = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 6)(13, "button", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, " Add Panelist ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](15, PanelistManagerComponent_div_15_Template, 5, 1, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Manage Panelists for ", ctx.event == null ? null : ctx.event.name, "");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.newPanelistName);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.newEventDescription);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.event == null ? null : ctx.event.panelists.length) > 0);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_2__.QrcodeComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgForm]
    });
  }
  return PanelistManagerComponent;
})();

/***/ }),

/***/ 1312:
/*!*****************************************************************!*\
  !*** ./src/app/events/create-events/create-events.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateEventsComponent": () => (/* binding */ CreateEventsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/event.service */ 3117);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateEventsComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Organization ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateEventsComponent = /*#__PURE__*/(() => {
  class CreateEventsComponent {
    constructor(eventService, fb) {
      this.eventService = eventService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.eventForm = this.fb.group({
        organization_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        event_name: [''],
        description: [''],
        start_date: [''],
        end_date: [''],
        venue_name: [''],
        address_line1: [''],
        address_line2: [''],
        city: [''],
        state_province: [''],
        postal_code: [''],
        country: [''],
        email: [''],
        phone_number: [''],
        website: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.eventForm.valid) {
      event.preventDefault();
      console.log('Event Form Value', this.eventForm.value);
      //create event call
      //use subscribe with next and error object as per new standard
      this.eventService.createEvent(this.eventForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.eventForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Event completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateEventsComponent_Factory(t) {
      return new (t || CreateEventsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__.EventService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateEventsComponent,
      selectors: [["app-create-events"]],
      decls: 85,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "event_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "event_name", "id", "event_name", "type", "text", "placeholder", "Enter Event Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "organization_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_id", "id", "organization_id", "type", "number", "placeholder", "Enter Event Org ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "description", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "description", "id", "description", "type", "text", "placeholder", "Enter Event Description", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "start_date", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "start_date", "id", "start_date", "type", "date", "placeholder", "Enter Event Start Date", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "end_date", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "end_date", "id", "end_date", "type", "date", "placeholder", "Enter Event End Date", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "venue_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "venue_name", "id", "venue_name", "type", "text", "placeholder", "Enter Event Venue Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "address_line1", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line1", "id", "address_line1", "placeholder", "Enter Event Address Line 1", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "address_line2", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line2", "id", "address_line2", "placeholder", "Enter Event Address Line 2", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "city", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "city", "id", "city", "type", "text", "placeholder", "Enter Event City", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "state_province", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "state_province", "id", "state_province", "type", "text", "placeholder", "Enter Event State/Province", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "postal_code", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "postal_code", "id", "postal_code", "type", "text", "placeholder", "Enter Event Postal Code", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "country", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "country", "id", "country", "type", "text", "placeholder", "Enter Event Country", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Event Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "phone_number", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "phone_number", "id", "phone_number", "type", "text", "placeholder", "Enter Event Phone Number", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "website", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "website", "id", "website", "type", "text", "placeholder", "Enter Event Website", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateEventsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "EVENT DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateEventsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Event Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 4)(12, "label", 7)(13, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Event Organization ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](16, CreateEventsComponent_div_16_Template, 3, 0, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Event Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 4)(23, "label", 12)(24, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Event Start Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](26, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 4)(28, "label", 14)(29, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Event End Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](31, "input", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div", 4)(33, "label", 16)(34, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "Event Venue Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](36, "input", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div", 18)(38, "label", 19)(39, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](40, "Event Address Line 1");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](41, "textarea", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 18)(43, "label", 21)(44, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](45, "Event Address Line 2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](46, "textarea", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](47, "div", 4)(48, "label", 23)(49, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](50, "Event City");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](51, "input", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](52, "div", 4)(53, "label", 25)(54, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](55, "Event State/Province");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](56, "input", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](57, "div", 4)(58, "label", 27)(59, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](60, "Event Postal Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](61, "input", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](62, "div", 4)(63, "label", 29)(64, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](65, "Event Country");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](66, "input", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](67, "div", 4)(68, "label", 31)(69, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](70, "Event Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](71, "input", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](72, "div", 4)(73, "label", 33)(74, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](75, "Event Phone Number");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](76, "input", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](77, "div", 4)(78, "label", 35)(79, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](80, "Event Website");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](81, "input", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](82, "div", 37)(83, "button", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](84, " Create Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.eventForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.eventForm && (ctx.eventForm == null ? null : (tmp_1_0 = ctx.eventForm.get("organization_id")) == null ? null : tmp_1_0.invalid) && ((ctx.eventForm == null ? null : (tmp_1_0 = ctx.eventForm.get("organization_id")) == null ? null : tmp_1_0.dirty) || (ctx.eventForm == null ? null : (tmp_1_0 = ctx.eventForm.get("organization_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](67);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.eventForm && ctx.eventForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateEventsComponent;
})();

/***/ }),

/***/ 3797:
/*!*****************************************************************!*\
  !*** ./src/app/events/delete-events/delete-events.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteEventsComponent": () => (/* binding */ DeleteEventsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/event.service */ 3117);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteEventsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Event ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteEventsComponent = /*#__PURE__*/(() => {
  class DeleteEventsComponent {
    constructor(eventService, fb) {
      this.eventService = eventService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        eventId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteEvent() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.eventId;
        this.eventService.deleteEvents(id).subscribe({
          next: response => {
            console.log('Event deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting event:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteEventsComponent_Factory(t) {
      return new (t || DeleteEventsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__.EventService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteEventsComponent,
      selectors: [["app-delete-events"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "eventId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "eventId", "id", "eventId", "type", "number", "placeholder", "Enter Event ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteEventsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteEventsComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Event ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteEventsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("eventId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("eventId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("eventId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteEventsComponent;
})();

/***/ }),

/***/ 558:
/*!*******************************************************************!*\
  !*** ./src/app/events/events-landing/events-landing.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventsLandingComponent": () => (/* binding */ EventsLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let EventsLandingComponent = /*#__PURE__*/(() => {
  class EventsLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetEvent() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-event');
    }
    onCreateEvent() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-event');
    }
    onDeleteEvent() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-event');
    }
    onUpdateEvent() {
      this.router.navigateByUrl('/update-event');
    }
    static #_ = this.ɵfac = function EventsLandingComponent_Factory(t) {
      return new (t || EventsLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: EventsLandingComponent,
      selectors: [["app-events-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function EventsLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventsLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventsLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventsLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EventsLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateEvent();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return EventsLandingComponent;
})();

/***/ }),

/***/ 2734:
/*!*****************************************!*\
  !*** ./src/app/events/events.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventsModule": () => (/* binding */ EventsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _events_landing_events_landing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./events-landing/events-landing.component */ 558);
/* harmony import */ var _create_events_create_events_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-events/create-events.component */ 1312);
/* harmony import */ var _get_events_get_events_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./get-events/get-events.component */ 8101);
/* harmony import */ var _update_events_update_events_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./update-events/update-events.component */ 4008);
/* harmony import */ var _delete_events_delete_events_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./delete-events/delete-events.component */ 3797);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4650);








let EventsModule = /*#__PURE__*/(() => {
  class EventsModule {
    static #_ = this.ɵfac = function EventsModule_Factory(t) {
      return new (t || EventsModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: EventsModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule]
    });
  }
  return EventsModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](EventsModule, {
    declarations: [_events_landing_events_landing_component__WEBPACK_IMPORTED_MODULE_0__.EventsLandingComponent, _create_events_create_events_component__WEBPACK_IMPORTED_MODULE_1__.CreateEventsComponent, _get_events_get_events_component__WEBPACK_IMPORTED_MODULE_2__.GetEventsComponent, _update_events_update_events_component__WEBPACK_IMPORTED_MODULE_3__.UpdateEventsComponent, _delete_events_delete_events_component__WEBPACK_IMPORTED_MODULE_4__.DeleteEventsComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule]
  });
})();

/***/ }),

/***/ 8101:
/*!***********************************************************!*\
  !*** ./src/app/events/get-events/get-events.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetEventsComponent": () => (/* binding */ GetEventsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/event.service */ 3117);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);



function GetEventsComponent_div_5_li_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const event_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"]("", event_r4.event_name, " , ", event_r4.event_id, "");
  }
}
function GetEventsComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, GetEventsComponent_div_5_li_2_Template, 2, 2, "li", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.events);
  }
}
function GetEventsComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0, " No events found.\n");
  }
}
let GetEventsComponent = /*#__PURE__*/(() => {
  class GetEventsComponent {
    constructor(eventService) {
      this.eventService = eventService;
      this.events = [];
    }
    ngOnInit() {
      //get all events
      this.eventService.getEvents().subscribe({
        next: data => {
          this.events = data;
          console.log('Events:', this.events);
        },
        error: error => {
          console.error('Error fetching events:', error);
        },
        complete: () => {
          console.log('Request to fetch Event completed');
        }
      });
    }
    static #_ = this.ɵfac = function GetEventsComponent_Factory(t) {
      return new (t || GetEventsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__.EventService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetEventsComponent,
      selectors: [["app-get-events"]],
      decls: 8,
      vars: 2,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-full"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [4, "ngIf", "ngIfElse"], ["noData", ""], [4, "ngFor", "ngForOf"]],
      template: function GetEventsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "EVENT NAME & ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, GetEventsComponent_div_5_Template, 3, 1, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GetEventsComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.events.length > 0)("ngIfElse", _r1);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf]
    });
  }
  return GetEventsComponent;
})();

/***/ }),

/***/ 4008:
/*!*****************************************************************!*\
  !*** ./src/app/events/update-events/update-events.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateEventsComponent": () => (/* binding */ UpdateEventsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/event.service */ 3117);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdateEventsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Event ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateEventsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Organization ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateEventsComponent = /*#__PURE__*/(() => {
  class UpdateEventsComponent {
    constructor(eventService, fb) {
      this.eventService = eventService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.eventUpdatedForm = this.fb.group({
        event_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        organization_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        event_name: [''],
        description: [''],
        start_date: [''],
        end_date: [''],
        venue_name: [''],
        address_line1: [''],
        address_line2: [''],
        city: [''],
        state_province: [''],
        postal_code: [''],
        country: [''],
        email: [''],
        phone_number: [''],
        website: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log('Event Updated Form Value', this.eventUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.eventService.updateEvent(this.eventUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.eventUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated Event completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateEventsComponent_Factory(t) {
      return new (t || UpdateEventsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_event_service__WEBPACK_IMPORTED_MODULE_0__.EventService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateEventsComponent,
      selectors: [["app-update-events"]],
      decls: 86,
      vars: 4,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "event_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "event_id", "id", "event_id", "type", "number", "placeholder", "Enter Event ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "organization_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_id", "id", "organization_id", "type", "number", "placeholder", "Enter Event Org ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "description", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "description", "id", "description", "type", "text", "placeholder", "Enter Event Description", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "start_date", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "start_date", "id", "start_date", "type", "date", "placeholder", "Enter Event Start Date", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "end_date", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "end_date", "id", "end_date", "type", "date", "placeholder", "Enter Event End Date", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "venue_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "venue_name", "id", "venue_name", "type", "text", "placeholder", "Enter Event Venue Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "address_line1", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line1", "id", "address_line1", "placeholder", "Enter Event Address Line 1", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "address_line2", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line2", "id", "address_line2", "placeholder", "Enter Event Address Line 2", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "city", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "city", "id", "city", "type", "text", "placeholder", "Enter Event City", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "state_province", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "state_province", "id", "state_province", "type", "text", "placeholder", "Enter Event State/Province", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "postal_code", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "postal_code", "id", "postal_code", "type", "text", "placeholder", "Enter Event Postal Code", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "country", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "country", "id", "country", "type", "text", "placeholder", "Enter Event Country", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Event Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "phone_number", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "phone_number", "id", "phone_number", "type", "text", "placeholder", "Enter Event Phone Number", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "website", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "website", "id", "website", "type", "text", "placeholder", "Enter Event Website", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdateEventsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE EVENT DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateEventsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Event ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateEventsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Event Organization ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, UpdateEventsComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Event Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "div", 4)(24, "label", 12)(25, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26, "Event Start Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](27, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "div", 4)(29, "label", 14)(30, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](31, "Event End Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](32, "input", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "div", 4)(34, "label", 16)(35, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36, "Event Venue Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](37, "input", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "div", 18)(39, "label", 19)(40, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](41, "Event Address Line 1");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](42, "textarea", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](43, "div", 18)(44, "label", 21)(45, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](46, "Event Address Line 2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](47, "textarea", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](48, "div", 4)(49, "label", 23)(50, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](51, "Event City");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](52, "input", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](53, "div", 4)(54, "label", 25)(55, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](56, "Event State/Province");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](57, "input", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](58, "div", 4)(59, "label", 27)(60, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](61, "Event Postal Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](62, "input", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](63, "div", 4)(64, "label", 29)(65, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](66, "Event Country");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](67, "input", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](68, "div", 4)(69, "label", 31)(70, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](71, "Event Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](72, "input", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](73, "div", 4)(74, "label", 33)(75, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](76, "Event Phone Number");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](77, "input", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](78, "div", 4)(79, "label", 35)(80, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](81, "Event Website");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](82, "input", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](83, "div", 37)(84, "button", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](85, " Update Event ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.eventUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.eventUpdatedForm && (ctx.eventUpdatedForm == null ? null : (tmp_1_0 = ctx.eventUpdatedForm.get("event_id")) == null ? null : tmp_1_0.invalid) && ((ctx.eventUpdatedForm == null ? null : (tmp_1_0 = ctx.eventUpdatedForm.get("event_id")) == null ? null : tmp_1_0.dirty) || (ctx.eventUpdatedForm == null ? null : (tmp_1_0 = ctx.eventUpdatedForm.get("event_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.eventUpdatedForm && (ctx.eventUpdatedForm == null ? null : (tmp_2_0 = ctx.eventUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.invalid) && ((ctx.eventUpdatedForm == null ? null : (tmp_2_0 = ctx.eventUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.dirty) || (ctx.eventUpdatedForm == null ? null : (tmp_2_0 = ctx.eventUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](67);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.eventUpdatedForm && ctx.eventUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdateEventsComponent;
})();

/***/ }),

/***/ 6095:
/*!*****************************************************************!*\
  !*** ./src/app/features-epris/page-blue/page-blue.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageBlueComponent": () => (/* binding */ PageBlueComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let PageBlueComponent = /*#__PURE__*/(() => {
  class PageBlueComponent {
    constructor(router) {
      this.router = router;
      this.userFullName = 'John Bianchi';
      this.userFirstName = 'John';
    }
    onLinkedInClick() {
      window.open('https://www.linkedin.com/in/bianchijohn/', '_blank');
    }
    onPatchWRKClick() {
      window.open('https://www.circlepass.io/patchwrq', '_blank');
    }
    onQuestAppClick() {
      window.open('https://www.circlepass.io/quest', '_blank');
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/organization');
    }
    onEvents() {
      //using router to navigate on same page
      this.router.navigateByUrl('/events');
    }
    onConnections() {
      //using router to navigate on same page
      this.router.navigateByUrl('/connections');
    }
    static #_ = this.ɵfac = function PageBlueComponent_Factory(t) {
      return new (t || PageBlueComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PageBlueComponent,
      selectors: [["app-page-blue"]],
      decls: 77,
      vars: 1,
      consts: [["data-theme", "patchWrk"], [1, "flex", "justify-between", "items-center", "p-3", "bg-primary"], [1, "flex", "items-center", "gap-4"], [1, "uppercase", "text-infoLight", "font-display"], ["src", "/assets/images/onboarding-images/qr-icon.png", "alt", "QR icon", 1, "header-icon", "w-8"], ["src", "/assets/icon/hamburger.png", "alt", "Menu icon", 1, "header-icon", "w-8"], [1, "profile", "p-7", "bg-cover", "bg-center", "bg-primary", "retroDiner:bg-accentDark"], [1, "flex", "items-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "w-20"], [1, "ml-5"], [1, "text-xl", "mb-4", "text-infoLight", "uppercase", "font-display"], [1, "grid", "grid-cols-4", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-8", "h-8"], [1, "about-me", "bg-inactive", "retroDiner:bg-tertiary", "px-8", "text-center", "py-5"], [1, "text-sm", "uppercase", "text-center", "leading-10", "text-info", "font-display"], [1, "pb-4", "text-sm"], ["id", "links"], [1, "flex", "flex-col", "w-9/12", "mx-auto", "mt-8", "space-y-6", "font-semibold"], ["type", "button", 1, "w-full", "bg-primary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-secondary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-tertiary", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "bg-inactive", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "badges"], ["id", "badgesQuests", 1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-blue", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "from-accentDark", "to-primary", "retroDiner:from-accentLight", "retroDiner:to-primary", "border-3", "border-info"], [1, "text-center", "w-full", "text-infoLight", "z-30"], ["href", "#", "title", "quest badge"], ["src", "../assets/images/onboarding-images/quest.png", "alt", "quest badge", 1, "w-auto", "h-14", "mt-2", "mx-auto"], [1, "text-center", "text-xs", "uppercase", "pt-1", "mt-2", "w-full"], ["id", "badgesMine", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "my badges"], ["src", "../assets/images/onboarding-images/badges.png", "alt", "badges", 1, "w-auto", "h-12", "mx-auto", "mt-3"], ["id", "badgesRewards", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "rewards badge"], ["src", "../assets/images/onboarding-images/rewards.png", "alt", "rewards badge", 1, "w-auto", "h-16", "mx-auto", "mt-3"], [1, "bg-primary", "text-infoLight"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"]],
      template: function PageBlueComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Profile Page");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4)(7, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6)(9, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "img", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9)(12, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11)(15, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "img", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 20)(24, "h1", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "About Me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 23)(31, "div", 24)(32, "button", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageBlueComponent_Template_button_click_32_listener() {
            return ctx.onLinkedInClick();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " LinkedIn ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "button", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageBlueComponent_Template_button_click_34_listener() {
            return ctx.onConnections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Connections ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageBlueComponent_Template_button_click_36_listener() {
            return ctx.onEvents();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Events ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "button", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageBlueComponent_Template_button_click_38_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, " Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 29)(41, "div", 30)(42, "div", 31)(43, "div", 32)(44, "a", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 36)(49, "div", 31)(50, "div", 32)(51, "a", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "img", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 39)(56, "div", 31)(57, "div", 32)(58, "a", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "img", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "footer", 42)(63, "div", 43)(64, "nav", 44)(65, "div", 45)(66, "a", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "img", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 45)(69, "a", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 45)(72, "a", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "img", 51);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 45)(75, "a", 52);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "img", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.userFullName);
        }
      },
      styles: ["body {\r\n\theight: fit-content;\r\n\theight: -moz-fit-content;\r\n\theight: -webkit-fit-content;\r\n}\r\n\r\n.about-me {\r\n\tborder-top: 3px solid #FFFFFF;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/***** THEME *****/\r\n.theme-header .title-text,\r\n.profile .title-text,\r\n.about-me .title-text,\r\n.badges {\r\n\tfont-family: 'Merienda', cursive;\r\n}\r\n\r\n.about-me,\r\nbutton {\r\n\tfont-family: 'Tenor Sans', sans-serif;\r\n}"],
      encapsulation: 2
    });
  }
  return PageBlueComponent;
})();

/***/ }),

/***/ 8536:
/*!*****************************************************************!*\
  !*** ./src/app/features-epris/page-gray/page-gray.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageGrayComponent": () => (/* binding */ PageGrayComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let PageGrayComponent = /*#__PURE__*/(() => {
  class PageGrayComponent {
    constructor(router) {
      this.router = router;
      this.userFullName = 'John Bianchi';
    }
    onLinkedInClick() {
      window.open('https://www.linkedin.com/in/bianchijohn/', '_blank');
    }
    onPatchWRKClick() {
      window.open('https://www.circlepass.io/patchwrq', '_blank');
    }
    onQuestAppClick() {
      window.open('https://www.circlepass.io/quest', '_blank');
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/organization');
    }
    onEvents() {
      //using router to navigate on same page
      this.router.navigateByUrl('/events');
    }
    onConnections() {
      //using router to navigate on same page
      this.router.navigateByUrl('/connections');
    }
    static #_ = this.ɵfac = function PageGrayComponent_Factory(t) {
      return new (t || PageGrayComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PageGrayComponent,
      selectors: [["app-page-gray"]],
      decls: 77,
      vars: 1,
      consts: [["data-theme", "grey"], [1, "flex", "justify-between", "items-center", "p-3", "bg-primary"], [1, "flex", "items-center", "gap-4"], [1, "uppercase", "text-infoLight", "font-display"], ["src", "/assets/images/onboarding-images/qr-icon.png", "alt", "QR icon", 1, "header-icon", "w-8"], ["src", "/assets/icon/hamburger.png", "alt", "Menu icon", 1, "header-icon", "w-8"], [1, "profile", "p-7", "bg-cover", "bg-center", "bg-primary", "retroDiner:bg-accentDark"], [1, "flex", "items-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "w-20"], [1, "ml-5"], [1, "text-xl", "mb-4", "text-infoLight", "uppercase", "font-display"], [1, "grid", "grid-cols-4", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-8", "h-8"], [1, "about-me", "bg-inactive", "retroDiner:bg-tertiary", "px-8", "text-center", "py-5"], [1, "text-sm", "uppercase", "text-center", "leading-10", "text-[#212121]", "font-display"], [1, "pb-4", "text-sm"], ["id", "links"], [1, "flex", "flex-col", "w-9/12", "mx-auto", "mt-8", "space-y-6", "font-semibold"], ["type", "button", 1, "w-full", "bg-primary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-secondary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-tertiary", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "bg-inactive", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "badges"], ["id", "badgesQuests", 1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-blue", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "from-accentDark", "to-primary", "retroDiner:from-accentLight", "retroDiner:to-primary", "border-3", "border-info"], [1, "text-center", "w-full", "text-infoLight", "z-30"], ["href", "#", "title", "quest badge"], ["src", "../assets/images/onboarding-images/quest.png", "alt", "quest badge", 1, "w-auto", "h-14", "mt-2", "mx-auto"], [1, "text-center", "text-xs", "uppercase", "pt-1", "mt-2", "w-full"], ["id", "badgesMine", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "my badges"], ["src", "../assets/images/onboarding-images/badges.png", "alt", "badges", 1, "w-auto", "h-12", "mx-auto", "mt-3"], ["id", "badgesRewards", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "rewards badge"], ["src", "../assets/images/onboarding-images/rewards.png", "alt", "rewards badge", 1, "w-auto", "h-16", "mx-auto", "mt-3"], [1, "bg-primary", "text-infoLight"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"]],
      template: function PageGrayComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Profile Page");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4)(7, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6)(9, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "img", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9)(12, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11)(15, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "img", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 20)(24, "h1", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "About Me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 23)(31, "div", 24)(32, "button", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageGrayComponent_Template_button_click_32_listener() {
            return ctx.onLinkedInClick();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " LinkedIn ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "button", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageGrayComponent_Template_button_click_34_listener() {
            return ctx.onConnections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Connections ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageGrayComponent_Template_button_click_36_listener() {
            return ctx.onEvents();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Events ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "button", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageGrayComponent_Template_button_click_38_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, " Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 29)(41, "div", 30)(42, "div", 31)(43, "div", 32)(44, "a", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 36)(49, "div", 31)(50, "div", 32)(51, "a", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "img", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 39)(56, "div", 31)(57, "div", 32)(58, "a", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "img", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "footer", 42)(63, "div", 43)(64, "nav", 44)(65, "div", 45)(66, "a", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "img", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 45)(69, "a", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 45)(72, "a", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "img", 51);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 45)(75, "a", 52);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "img", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.userFullName);
        }
      },
      styles: ["body {\r\n\theight: fit-content;\r\n\theight: -moz-fit-content;\r\n\theight: -webkit-fit-content;\r\n\tborder-right: #000 2px solid;\r\n\tborder-left: #000 2px solid;\r\n}\r\n\r\n.about-me {\r\n\tborder-top: 3px solid #FFFFFF;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/***** THEME *****/\r\n.theme-header .title-text,\r\n.profile .title-text,\r\n.about-me .title-text,\r\n.badges {\r\n\tfont-family: \"Roboto Slab\", serif;\r\n}"],
      encapsulation: 2
    });
  }
  return PageGrayComponent;
})();

/***/ }),

/***/ 4075:
/*!*********************************************************************!*\
  !*** ./src/app/features-epris/page-purple/page-purple.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagePurpleComponent": () => (/* binding */ PagePurpleComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let PagePurpleComponent = /*#__PURE__*/(() => {
  class PagePurpleComponent {
    constructor(router) {
      this.router = router;
      this.userFullName = 'John Bianchi';
    }
    onLinkedInClick() {
      window.open('https://www.linkedin.com/in/bianchijohn/', '_blank');
    }
    onPatchWRKClick() {
      window.open('https://www.circlepass.io/patchwrq', '_blank');
    }
    onQuestAppClick() {
      window.open('https://www.circlepass.io/quest', '_blank');
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/organization');
    }
    onEvents() {
      //using router to navigate on same page
      this.router.navigateByUrl('/events');
    }
    onConnections() {
      //using router to navigate on same page
      this.router.navigateByUrl('/connections');
    }
    static #_ = this.ɵfac = function PagePurpleComponent_Factory(t) {
      return new (t || PagePurpleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PagePurpleComponent,
      selectors: [["app-page-purple"]],
      decls: 77,
      vars: 1,
      consts: [["data-theme", "dragons"], [1, "flex", "justify-between", "items-center", "p-3", "bg-primary"], [1, "flex", "items-center", "gap-4"], [1, "uppercase", "text-infoLight", "font-display"], ["src", "/assets/images/onboarding-images/qr-icon.png", "alt", "QR icon", 1, "header-icon", "w-8"], ["src", "/assets/icon/hamburger.png", "alt", "Menu icon", 1, "header-icon", "w-8"], [1, "profile", "p-7", "bg-cover", "bg-center", "bg-primary", "retroDiner:bg-accentDark"], [1, "flex", "items-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "w-20"], [1, "ml-5"], [1, "text-xl", "mb-4", "text-infoLight", "uppercase", "font-display"], [1, "grid", "grid-cols-4", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-8", "h-8"], [1, "about-me", "bg-inactive", "retroDiner:bg-tertiary", "px-8", "text-center", "py-5"], [1, "text-sm", "uppercase", "text-center", "leading-10", "text-info", "font-display"], [1, "pb-4", "text-sm"], ["id", "links"], [1, "flex", "flex-col", "w-9/12", "mx-auto", "mt-8", "space-y-6", "font-semibold"], ["type", "button", 1, "w-full", "bg-primary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-[#353535]", "bg-secondary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-tertiary", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "bg-inactive", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "badges"], ["id", "badgesQuests", 1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-blue", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "from-accentDark", "to-primary", "retroDiner:from-accentLight", "retroDiner:to-primary", "border-3", "border-info"], [1, "text-center", "w-full", "text-infoLight", "z-30"], ["href", "#", "title", "quest badge"], ["src", "../assets/images/onboarding-images/quest.png", "alt", "quest badge", 1, "w-auto", "h-14", "mt-2", "mx-auto"], [1, "text-center", "text-xs", "uppercase", "pt-1", "mt-2", "w-full"], ["id", "badgesMine", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "my badges"], ["src", "../assets/images/onboarding-images/badges.png", "alt", "badges", 1, "w-auto", "h-12", "mx-auto", "mt-3"], ["id", "badgesRewards", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "rewards badge"], ["src", "../assets/images/onboarding-images/rewards.png", "alt", "rewards badge", 1, "w-auto", "h-16", "mx-auto", "mt-3"], [1, "bg-primary", "text-infoLight"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"]],
      template: function PagePurpleComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Profile Page");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4)(7, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6)(9, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "img", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9)(12, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11)(15, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "img", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 20)(24, "h1", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "About Me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 23)(31, "div", 24)(32, "button", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PagePurpleComponent_Template_button_click_32_listener() {
            return ctx.onLinkedInClick();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " LinkedIn ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "button", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PagePurpleComponent_Template_button_click_34_listener() {
            return ctx.onConnections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Connections ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PagePurpleComponent_Template_button_click_36_listener() {
            return ctx.onEvents();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Events ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "button", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PagePurpleComponent_Template_button_click_38_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, " Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 29)(41, "div", 30)(42, "div", 31)(43, "div", 32)(44, "a", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 36)(49, "div", 31)(50, "div", 32)(51, "a", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "img", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 39)(56, "div", 31)(57, "div", 32)(58, "a", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "img", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "footer", 42)(63, "div", 43)(64, "nav", 44)(65, "div", 45)(66, "a", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "img", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 45)(69, "a", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 45)(72, "a", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "img", 51);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 45)(75, "a", 52);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "img", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.userFullName);
        }
      },
      styles: ["body {\r\n\theight: fit-content;\r\n\theight: -moz-fit-content;\r\n\theight: -webkit-fit-content;\r\n\tborder-right: #212121 1px solid;\r\n\tborder-left: #212121 1px solid;\r\n}\r\n\r\n.about-me {\r\n\tborder-top: 3px solid #FFFFFF;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/***** THEME *****/\r\n.theme-header .title-text,\r\n.profile .title-text,\r\n.about-me .title-text {\r\n\tfont-family: \"Titan One\", sans-serif;\r\n}\r\n\r\nbutton,\r\n.badges {\r\n\tfont-family: \"Merriweather Sans\", sans-serif;\r\n}"],
      encapsulation: 2
    });
  }
  return PagePurpleComponent;
})();

/***/ }),

/***/ 7390:
/*!***************************************************************!*\
  !*** ./src/app/features-epris/page-red/page-red.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageRedComponent": () => (/* binding */ PageRedComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let PageRedComponent = /*#__PURE__*/(() => {
  class PageRedComponent {
    constructor(router) {
      this.router = router;
      this.userFullName = 'John Bianchi';
    }
    onLinkedInClick() {
      window.open('https://www.linkedin.com/in/bianchijohn/', '_blank');
    }
    onPatchWRKClick() {
      window.open('https://www.circlepass.io/patchwrq', '_blank');
    }
    onQuestAppClick() {
      window.open('https://www.circlepass.io/quest', '_blank');
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/organization');
    }
    onEvents() {
      //using router to navigate on same page
      this.router.navigateByUrl('/events');
    }
    onConnections() {
      //using router to navigate on same page
      this.router.navigateByUrl('/connections');
    }
    static #_ = this.ɵfac = function PageRedComponent_Factory(t) {
      return new (t || PageRedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PageRedComponent,
      selectors: [["app-page-red"]],
      decls: 77,
      vars: 1,
      consts: [["data-theme", "nyias"], [1, "flex", "justify-between", "items-center", "p-3", "bg-primary"], [1, "flex", "items-center", "gap-4"], [1, "uppercase", "text-infoLight", "font-display"], ["src", "/assets/images/onboarding-images/qr-icon.png", "alt", "QR icon", 1, "header-icon", "w-8"], ["src", "/assets/icon/hamburger.png", "alt", "Menu icon", 1, "header-icon", "w-8"], [1, "profile", "p-7", "bg-cover", "bg-center", "bg-primary", "retroDiner:bg-accentDark"], [1, "flex", "items-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "w-20"], [1, "ml-5"], [1, "text-xl", "mb-4", "text-infoLight", "uppercase", "font-display"], [1, "grid", "grid-cols-4", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-8", "h-8"], [1, "about-me", "bg-inactive", "retroDiner:bg-tertiary", "px-8", "text-center", "py-5"], [1, "text-sm", "uppercase", "text-center", "leading-10", "text-info", "font-display"], [1, "pb-4", "text-sm"], ["id", "links"], [1, "flex", "flex-col", "w-9/12", "mx-auto", "mt-8", "space-y-6"], ["type", "button", 1, "w-full", "bg-primary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-info", "bg-secondary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-trimDark", "bg-tertiary", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "bg-inactive", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "badges"], ["id", "badgesQuests", 1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-blue", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "from-accentDark", "to-primary", "retroDiner:from-accent-light", "retroDiner:to-primary", "border-3", "border-info"], [1, "text-center", "w-full", "text-infoLight", "z-30"], ["href", "#", "title", "quest badge"], ["src", "../assets/images/onboarding-images/quest.png", "alt", "quest badge", 1, "w-auto", "h-14", "mt-2", "mx-auto"], [1, "text-center", "text-xs", "uppercase", "pt-1", "mt-2", "w-full"], ["id", "badgesMine", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "my badges"], ["src", "../assets/images/onboarding-images/badges.png", "alt", "badges", 1, "w-auto", "h-12", "mx-auto", "mt-3"], ["id", "badgesRewards", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "rewards badge"], ["src", "../assets/images/onboarding-images/rewards.png", "alt", "rewards badge", 1, "w-auto", "h-16", "mx-auto", "mt-3"], [1, "bg-primary", "text-infoLight"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"]],
      template: function PageRedComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Profile Page");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4)(7, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6)(9, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "img", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9)(12, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11)(15, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "img", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "a", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "img", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 20)(24, "h1", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "About Me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 23)(31, "div", 24)(32, "button", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageRedComponent_Template_button_click_32_listener() {
            return ctx.onLinkedInClick();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " LinkedIn ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "button", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageRedComponent_Template_button_click_34_listener() {
            return ctx.onConnections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Connections ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageRedComponent_Template_button_click_36_listener() {
            return ctx.onEvents();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, " Events ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "button", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PageRedComponent_Template_button_click_38_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, " Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 29)(41, "div", 30)(42, "div", 31)(43, "div", 32)(44, "a", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 36)(49, "div", 31)(50, "div", 32)(51, "a", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "img", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 39)(56, "div", 31)(57, "div", 32)(58, "a", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "img", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "p", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "footer", 42)(63, "div", 43)(64, "nav", 44)(65, "div", 45)(66, "a", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "img", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 45)(69, "a", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 45)(72, "a", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "img", 51);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 45)(75, "a", 52);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "img", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.userFullName);
        }
      },
      styles: ["body {\r\n\theight: fit-content;\r\n\theight: -moz-fit-content;\r\n\theight: -webkit-fit-content;\r\n\tborder-right: #000 2px solid;\r\n\tborder-left: #000 2px solid;\r\n\tbackground-color: #F2F7F9;\r\n}\r\n\r\n.about-me {\r\n\tborder-top: 3px solid #FFFFFF;\r\n\tbox-sizing: border-box;\r\n}\r\n\r\n/***** THEME *****/\r\n.theme-header .title-text,\r\n.profile .title-text,\r\n.about-me .title-text,\r\nbutton,\r\n.badges {\r\n\tfont-family: \"Anton\", sans-serif;\r\n}"],
      encapsulation: 2
    });
  }
  return PageRedComponent;
})();

/***/ }),

/***/ 9144:
/*!***************************************************************!*\
  !*** ./src/app/features-michael/com-one/com-one.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComOneComponent": () => (/* binding */ ComOneComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ComOneComponent = /*#__PURE__*/(() => {
  class ComOneComponent {
    static #_ = this.ɵfac = function ComOneComponent_Factory(t) {
      return new (t || ComOneComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ComOneComponent,
      selectors: [["app-com-one"]],
      decls: 6,
      vars: 0,
      consts: [["title", "Component Communication in Angular", "target", "_blank", "href", "https://www.geeksforgeeks.org/component-communication-in-angular/"]],
      template: function ComOneComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "com-one works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ul")(3, "li")(4, "a", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " https://www.geeksforgeeks.org/component-communication-in-angular/");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return ComOneComponent;
})();

/***/ }),

/***/ 143:
/*!***************************************************************!*\
  !*** ./src/app/features-michael/com-two/com-two.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComTwoComponent": () => (/* binding */ ComTwoComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ComTwoComponent = /*#__PURE__*/(() => {
  class ComTwoComponent {
    static #_ = this.ɵfac = function ComTwoComponent_Factory(t) {
      return new (t || ComTwoComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ComTwoComponent,
      selectors: [["app-com-two"]],
      decls: 6,
      vars: 0,
      consts: [["title", "Component Communication in Angular", "target", "_blank", "href", "https://www.geeksforgeeks.org/component-communication-in-angular/"]],
      template: function ComTwoComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "com-two works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ul")(3, "li")(4, "a", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " https://www.geeksforgeeks.org/component-communication-in-angular/");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return ComTwoComponent;
})();

/***/ }),

/***/ 627:
/*!*************************************************************!*\
  !*** ./src/app/features-michael/features-michael.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeaturesMichaelModule": () => (/* binding */ FeaturesMichaelModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _com_one_com_one_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./com-one/com-one.component */ 9144);
/* harmony import */ var _com_two_com_two_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./com-two/com-two.component */ 143);
/* harmony import */ var _qr_reader_qr_reader_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./qr-reader/qr-reader.component */ 5093);
/* harmony import */ var _profile_loader_profile_loader_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile-loader/profile-loader.component */ 3156);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ 9652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);








let FeaturesMichaelModule = /*#__PURE__*/(() => {
  class FeaturesMichaelModule {
    static #_ = this.ɵfac = function FeaturesMichaelModule_Factory(t) {
      return new (t || FeaturesMichaelModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
      type: FeaturesMichaelModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionModule]
    });
  }
  return FeaturesMichaelModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](FeaturesMichaelModule, {
    declarations: [_com_one_com_one_component__WEBPACK_IMPORTED_MODULE_0__.ComOneComponent, _com_two_com_two_component__WEBPACK_IMPORTED_MODULE_1__.ComTwoComponent, _qr_reader_qr_reader_component__WEBPACK_IMPORTED_MODULE_2__.QrReaderComponent, _profile_loader_profile_loader_component__WEBPACK_IMPORTED_MODULE_3__.ProfileLoaderComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionModule]
  });
})();

/***/ }),

/***/ 3156:
/*!*****************************************************************************!*\
  !*** ./src/app/features-michael/profile-loader/profile-loader.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileLoaderComponent": () => (/* binding */ ProfileLoaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var src_app_core_pipes_initials_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/pipes/initials.pipe */ 5953);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/pii.service */ 8203);
/* harmony import */ var src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/links.service */ 7363);
/* harmony import */ var src_app_core_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/user.service */ 8386);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ 9652);










function ProfileLoaderComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", ctx_r0.profileInitials, " , ", ctx_r0.id, "");
  }
}
function ProfileLoaderComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function ProfileLoaderComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "mat-expansion-panel", 12)(2, "mat-expansion-panel-header")(3, "mat-panel-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Bio");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("Bio: ", ctx_r2.bio, "");
  }
}
function ProfileLoaderComponent_div_19_li_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const link_r7 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r5.showImage(link_r7.url_label), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", link_r7.link_type, " , ", link_r7.url_link, "");
  }
}
function ProfileLoaderComponent_div_19_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("+ ", ctx_r6.linksSAdjusted, " more");
  }
}
function ProfileLoaderComponent_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "mat-expansion-panel", 12)(2, "mat-expansion-panel-header")(3, "mat-panel-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "S Links");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProfileLoaderComponent_div_19_li_5_Template, 3, 3, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "slice");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProfileLoaderComponent_div_19_div_7_Template, 3, 1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind3"](6, 2, ctx_r3.linksS, 0, 4));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r3.linksS.length > 4);
  }
}
function ProfileLoaderComponent_div_20_li_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const link_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", link_r10.link_type, " , ", link_r10.url_link, "");
  }
}
function ProfileLoaderComponent_div_20_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("+ ", ctx_r9.linksWAdjusted, " more");
  }
}
function ProfileLoaderComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "mat-expansion-panel", 12)(2, "mat-expansion-panel-header")(3, "mat-panel-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "W Links");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProfileLoaderComponent_div_20_li_5_Template, 2, 2, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "slice");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProfileLoaderComponent_div_20_div_7_Template, 3, 1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind3"](6, 2, ctx_r4.linksW, 0, 3));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r4.linksW.length > 3);
  }
}
let ProfileLoaderComponent = /*#__PURE__*/(() => {
  class ProfileLoaderComponent {
    constructor(fb, piiService, linkService, initialPipe, userService) {
      this.fb = fb;
      this.piiService = piiService;
      this.linkService = linkService;
      this.initialPipe = initialPipe;
      this.userService = userService;
      this.id = 0;
      this.links = [];
      this.linksS = [];
      this.linksW = [];
      this.profileInitials = '';
      this.imgSrc = '';
      this.theme = '';
      this.givenName = '';
      this.inputForm = this.fb.group({
        userId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
      });
      this.bio = '';
      this.linksSAdjusted = 0;
      this.linksWAdjusted = 0;
      this.firstName = '';
      this.lastName = '';
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.piiform.valid) {
      event.preventDefault();
      console.log("User Id Value", this.inputForm.value);
      this.id = this.inputForm.value.userId;
      this.piiService.getUserPii(this.id).subscribe({
        next: response => {
          this.bio = response.biography;
          console.log('Bio get successfully:', this.bio);
          this.inputForm.reset();
        },
        error: error => {
          console.error('Error:', error);
        }
      });
      this.linkService.getLink(this.id).subscribe({
        next: response => {
          this.links = response;
          console.log('Links get successfully:', this.links);
          this.sortLinks();
          this.inputForm.reset();
        },
        error: error => {
          console.error('Error:', error);
        }
      });
      this.userService.getUserProfile(this.id).subscribe({
        next: response => {
          this.firstName = response.first_name;
          this.lastName = response.last_name;
          this.theme = response.user_theme.theme_name ? response.user_theme.theme_name : 'N/A';
          this.givenName = this.firstName + " " + this.lastName;
          this.profileInitials = this.initialPipe.transform(this.givenName);
          console.log(this.givenName);
          console.log(this.theme);
        }
      });
    }
    sortLinks() {
      this.linksS = this.links.filter(link => link.link_type == 'S');
      this.linksW = this.links.filter(link => link.link_type == 'W');
      this.linksSAdjusted = this.linksS.length - 4;
      this.linksWAdjusted = this.linksW.length - 3;
    }
    showImage(url_label) {
      switch (url_label) {
        case "Classmates":
          return '/assets/images/social-logos/classmates.png';
        case "Discord":
          return '/assets/images/social-logos/discord.png';
        case "Facebook":
          return '/assets/images/social-logos/facebook.png';
        case "Flikr":
          return '/assets/images/social-logos/flikr.png';
        case "Goodreads":
          return '/assets/images/social-logos/goodreads.png';
        case "Instagram":
          return '/assets/images/social-logos/instagram.png';
        case "Kuaishou":
          return '/assets/images/social-logos/kuaishou.png';
        case "LinkedIn":
          return '/assets/images/social-logos/linkedin.png';
        case "Mastodon":
          return '/assets/images/social-logos/mastodon.png';
        case "Medium":
          return '/assets/images/social-logos/medium.png';
        case "Myspace":
          return '/assets/images/social-logos/myspace.png';
        case "Pinterest":
          return '/assets/images/social-logos/pinterest.png';
        case "QQ ~??":
          return '/assets/images/social-logos/qq.png';
        case "Quora":
          return '/assets/images/social-logos/quora.png';
        case "Reddit":
          return '/assets/images/social-logos/reddit.png';
        case "Sina Weibo":
          return '/assets/images/social-logos/sina-weibo.png';
        case "Snapchat":
          return '/assets/images/social-logos/snapchat.png';
        case "Telegram":
          return '/assets/images/social-logos/telegram.png';
        case "TikTok":
          return '/assets/images/social-logos/tiktok.png';
        case "Tumblr":
          return '/assets/images/social-logos/tumblr.png';
        case "Twitch":
          return '/assets/images/social-logos/twitch.png';
        case "Twitter X":
          return '/assets/images/social-logos/twitter-x.png';
        case "WeChat":
          return '/assets/images/social-logos/wechat.png';
        case "Whatsapp":
          return '/assets/images/social-logos/whats-app.png';
        case "Youtube":
          return '/assets/images/social-logos/youtube.png';
        default:
          return '';
      }
    }
    static #_ = this.ɵfac = function ProfileLoaderComponent_Factory(t) {
      return new (t || ProfileLoaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_1__.PiiService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_2__.LinksService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_pipes_initials_pipe__WEBPACK_IMPORTED_MODULE_0__.InitialsPipe), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: ProfileLoaderComponent,
      selectors: [["app-profile-loader"]],
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵProvidersFeature"]([src_app_core_pipes_initials_pipe__WEBPACK_IMPORTED_MODULE_0__.InitialsPipe])],
      decls: 21,
      vars: 9,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["class", "text-lg font-semibold text-center mb-3", 4, "ngIf"], [1, "text-lg", "font-semibold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["formControlName", "userId", "id", "userId", "type", "text", "placeholder", "Enter User Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"], ["hideToggle", ""], [4, "ngFor", "ngForOf"], [1, "image", 3, "src"]],
      template: function ProfileLoaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "PROFILE LOADER");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProfileLoaderComponent_div_5_Template, 2, 2, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "form", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngSubmit", function ProfileLoaderComponent_Template_form_ngSubmit_10_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "input", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ProfileLoaderComponent_div_13_Template, 3, 0, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 9)(15, "button", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, " Load Profile ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "mat-accordion");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, ProfileLoaderComponent_div_18_Template, 7, 1, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, ProfileLoaderComponent_div_19_Template, 8, 6, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](20, ProfileLoaderComponent_div_20_Template, 8, 6, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_4_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.id > 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.theme);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.givenName);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.inputForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.inputForm && ((tmp_4_0 = ctx.inputForm.get("userId")) == null ? null : tmp_4_0.invalid) && (((tmp_4_0 = ctx.inputForm.get("userId")) == null ? null : tmp_4_0.dirty) || ((tmp_4_0 = ctx.inputForm.get("userId")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", ctx.inputForm && ctx.inputForm.invalid);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.bio != "");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.linksS.length > 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.linksW.length > 0);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatAccordion, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelTitle, _angular_common__WEBPACK_IMPORTED_MODULE_6__.SlicePipe],
      styles: [".image[_ngcontent-%COMP%]{\r\n    float: left;\r\n    margin-right: 5px;\r\n    height: 20px;\r\n    width: 20px;\r\n}"]
    });
  }
  return ProfileLoaderComponent;
})();

/***/ }),

/***/ 5093:
/*!*******************************************************************!*\
  !*** ./src/app/features-michael/qr-reader/qr-reader.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrReaderComponent": () => (/* binding */ QrReaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let QrReaderComponent = /*#__PURE__*/(() => {
  class QrReaderComponent {
    static #_ = this.ɵfac = function QrReaderComponent_Factory(t) {
      return new (t || QrReaderComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QrReaderComponent,
      selectors: [["app-qr-reader"]],
      decls: 3,
      vars: 0,
      template: function QrReaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "qr-reader works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "\nPlease build a QR code reader here");
        }
      }
    });
  }
  return QrReaderComponent;
})();

/***/ }),

/***/ 9266:
/*!*************************************************!*\
  !*** ./src/app/features/crud/crud.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CrudComponent": () => (/* binding */ CrudComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/connection.service */ 5684);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/core */ 7873);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/button */ 4859);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/icon */ 7392);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ 9549);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/menu */ 8255);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/select */ 4385);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/toolbar */ 3683);










let CrudComponent = /*#__PURE__*/(() => {
  class CrudComponent {
    constructor(router, connection) {
      this.router = router;
      this.connection = connection;
      this.userFullName = 'John Bianchi';
      this.userBio = 'Lorem ipsum dolor sit amet, consectetur Caramels are umm. Vivamus nec tincidunt urna, sed feugiat metus. mollis eget nunc. Integer eu metus ut lectus luctus tempor. Donec sed nisl pretium, porttitor risus eu, lobortis leo. Nullam laoreet vulputate magna sit amet laoreet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus iaculis imperdiet ex, sit amet molestie justo mollis eu. Aenean volutpat diam dui, vitae interdum mi placerat eget. Curabitur at nibh a sem faucibus accumsan. Nullam elementum, risus nec finibus iaculis, erat orci vehicula est, quis fringilla justo tellus vitae metus.';
      this.theme = localStorage.getItem('theme') || '';
      this.selected = '';
      this.envName = this.connection.getEnvironment();
    }
    ngOnInit() {
      if (this.theme) {
        document.body.dataset['theme'] = this.theme;
        this.selected = this.theme;
      }
      if (!this.theme) {
        localStorage.setItem('theme', 'grey');
        this.selected = 'grey';
        document.body.dataset['theme'] = 'grey';
      }
    }
    updateTheme(value) {
      localStorage.setItem('theme', value);
      this.theme = value;
      document.body.dataset['theme'] = value;
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/organization');
    }
    onBadges() {
      this.router.navigateByUrl('/badge');
    }
    onEvents() {
      this.router.navigateByUrl('/events');
    }
    onConnections() {
      this.router.navigateByUrl('/connections');
    }
    onLinks() {
      this.router.navigateByUrl('/links');
    }
    onTags() {
      this.router.navigateByUrl('/tags');
    }
    onRoles() {
      this.router.navigateByUrl('/roles');
    }
    onPii() {
      this.router.navigateByUrl('/pii');
    }
    onQuest() {
      this.router.navigateByUrl('/quest');
    }
    onTrigger() {
      this.router.navigateByUrl('/trigger');
    }
    onJourney() {
      this.router.navigateByUrl('/journey');
    }
    onQRCode() {
      this.router.navigateByUrl('/qrcode');
    }
    onQRCodeSave() {
      this.router.navigateByUrl('/qr-code-save');
    }
    onQR_Code_Reader() {
      this.router.navigateByUrl('/qrcode-reader');
    }
    onProfile_Loader() {
      this.router.navigateByUrl('/profile-loader');
    }
    onImageUploader() {
      this.router.navigateByUrl('/image-uploader');
    }
    static #_ = this.ɵfac = function CrudComponent_Factory(t) {
      return new (t || CrudComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_connection_service__WEBPACK_IMPORTED_MODULE_0__.ConnectionService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CrudComponent,
      selectors: [["app-crud"]],
      decls: 105,
      vars: 17,
      consts: [[1, "bg-primary", "text-infoLight"], [1, "uppercase", "flex-1", "font-sans"], ["src", "/assets/images/onboarding-images/qr-icon.png", "alt", "QR icon", 1, "header-icon", "w-8"], ["mat-icon-button", "", 3, "matMenuTriggerFor"], ["fontIcon", "menu", 1, "text-4xl", "leading-[24px]", "!w-8", "!h-8"], ["xPosition", "before", 1, "w-[25vw]"], ["menu", "matMenu"], ["for", "theme-options", 1, "absolute", "h-[1px]", "w-[1px]", "overflow-hidden"], ["name", "theme-options", "id", "themeoptions", "aria-label", "ThemeOptions", 3, "value", "valueChange", "selectionChange"], ["value", "patchWrk", 3, "selected"], ["value", "nyias", 3, "selected"], ["value", "dragons", 3, "selected"], ["value", "grey", 3, "selected"], ["value", "forest", 3, "selected"], ["value", "racer", 3, "selected"], ["value", "retroDiner", 3, "selected"], ["value", "duke", 3, "selected"], ["value", "raven", 3, "selected"], ["value", "slateGreen", 3, "selected"], ["value", "roseAmber", 3, "selected"], ["value", "violetSky", 3, "selected"], [1, "p-7", "bg-cover", "bg-center", "bg-primary", "retroDiner:bg-accentDark"], [1, "flex", "items-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "w-20"], [1, "ml-5"], [1, "text-xl", "mb-4", "text-infoLight", "uppercase", "font-bold"], [1, "grid", "grid-cols-4", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-8", "h-8", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-8", "h-8"], [1, "bg-inactive", "retroDiner:bg-tertiary", "px-8", "text-left", "py-5"], [1, "text-sm", "uppercase", "text-center", "leading-10", "font-bold"], [1, "pb-4", "text-sm"], ["id", "links"], [1, "flex", "flex-col", "w-9/12", "mx-auto", "mt-8", "space-y-6", "font-semibold"], ["type", "button", 1, "w-full", "border-1", "border-info", "bg-secondary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", "duke:text-info", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-[#353535]", "bg-neutral-200", "truncate", "shadow-gray", "text-center", "text-[#212121]", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-info", "bg-primary", "truncate", "shadow-gray", "text-center", "text-infoLight", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["type", "button", 1, "w-full", "border-1", "border-info", "bg-main", "truncate", "shadow-gray", "text-center", "text-info", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto", 3, "click"], ["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "font-bold", "badges"], [1, "bg-accentDark", "text-infoLight"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"], [1, "text-center", "font-bold"]],
      template: function CrudComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-toolbar", 0)(1, "span", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Profile Page");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "button", 3)(5, "mat-icon", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, "menu");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-menu", 5, 6)(9, "div")(10, "label", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "THEME PICKER");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "mat-label");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "Select a Theme");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "mat-select", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("valueChange", function CrudComponent_Template_mat_select_valueChange_14_listener($event) {
            return ctx.selected = $event;
          })("selectionChange", function CrudComponent_Template_mat_select_selectionChange_14_listener($event) {
            return ctx.updateTheme($event.value);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "mat-option", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "PatchWRK");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "mat-option", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18, "NYIAS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "mat-option", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "DragonCon");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "mat-option", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](22, "Grey");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "mat-option", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, "Forest");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "mat-option", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26, "Left Turn Racer");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "mat-option", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28, "Retro Diner");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "mat-option", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Duke");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "mat-option", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, "Raven");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "mat-option", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, "Slate Green");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "mat-option", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36, "Rose Amber");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "mat-option", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](38, "Violet Sky");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](39, "div", 21)(40, "div", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](41, "img", 23);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 24)(43, "p", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](44);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](45, "div", 26)(46, "a", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](47, "img", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](48, "a", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](49, "img", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](50, "a", 31);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](51, "img", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](52, "a", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](53, "img", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](54, "div", 35)(55, "h1", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](56, "About Me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](57, "p", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](58);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](59, "div", 38)(60, "div", 39)(61, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_61_listener() {
            return ctx.onQRCode();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](62, " QR Code generator ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](63, "button", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_63_listener() {
            return ctx.onQRCodeSave();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](64, " QR Code Save Caption ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](65, "button", 42);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_65_listener() {
            return ctx.onConnections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](66, " Connections ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](67, "button", 42);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_67_listener() {
            return ctx.onBadges();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](68, " Badges ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](69, "button", 43);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_69_listener() {
            return ctx.onEvents();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](70, " Events ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](71, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_71_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](72, " Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](73, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_73_listener() {
            return ctx.onLinks();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](74, " Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](75, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_75_listener() {
            return ctx.onTags();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](76, " Tags ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](77, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_77_listener() {
            return ctx.onRoles();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](78, " Roles ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](79, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_79_listener() {
            return ctx.onPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](80, " PII ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](81, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_81_listener() {
            return ctx.onQR_Code_Reader();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](82, " QR reader ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](83, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_83_listener() {
            return ctx.onProfile_Loader();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](84, " profile-loader ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](85, "button", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CrudComponent_Template_button_click_85_listener() {
            return ctx.onImageUploader();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](86, " ImageUploader ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](87, "div", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](88, "footer", 45)(89, "div", 46)(90, "nav", 47)(91, "div", 48)(92, "a", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](93, "img", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](94, "div", 48)(95, "a", 51);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](96, "img", 52);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](97, "div", 48)(98, "a", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](99, "img", 54);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](100, "div", 48)(101, "a", 55);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](102, "img", 56);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](103, "div", 57);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](104);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matMenuTriggerFor", _r0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx.selected);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "patchWrk");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "nyias");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "dragons");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "grey");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "forest");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "racer");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "retroDiner");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "duke");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "raven");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "slateGreen");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "roseAmber");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selected", ctx.theme === "violetSky");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.userFullName);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.userBio, " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](46);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("This app is running in the ", ctx.envName, ".");
        }
      },
      dependencies: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__.MatOption, _angular_material_button__WEBPACK_IMPORTED_MODULE_4__.MatIconButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIcon, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__.MatLabel, _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__.MatMenu, _angular_material_menu__WEBPACK_IMPORTED_MODULE_7__.MatMenuTrigger, _angular_material_select__WEBPACK_IMPORTED_MODULE_8__.MatSelect, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_9__.MatToolbar],
      styles: ["body {\r\n\theight: fit-content;\r\n\theight: -moz-fit-content;\r\n\theight: -webkit-fit-content;\r\n\tborder-right: #000 2px solid;\r\n\tborder-left: #000 2px solid;\r\n\tbackground-color: #F5F5F5;\r\n}\r\n\r\nlabel {\r\n\tposition: absolute !important;\r\n  height: 1px; width: 1px; \r\n  overflow: hidden;\r\n  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */\r\n  clip: rect(1px, 1px, 1px, 1px);\r\n}"],
      encapsulation: 2
    });
  }
  return CrudComponent;
})();

/***/ }),

/***/ 7098:
/*!***********************************************************************!*\
  !*** ./src/app/features/feature-landing/feature-landing.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeatureLandingComponent": () => (/* binding */ FeatureLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let FeatureLandingComponent = /*#__PURE__*/(() => {
  class FeatureLandingComponent {
    static #_ = this.ɵfac = function FeatureLandingComponent_Factory(t) {
      return new (t || FeatureLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: FeatureLandingComponent,
      selectors: [["app-feature-landing"]],
      decls: 2,
      vars: 0,
      template: function FeatureLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "feature-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return FeatureLandingComponent;
})();

/***/ }),

/***/ 5790:
/*!*********************************************!*\
  !*** ./src/app/features/features.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeaturesModule": () => (/* binding */ FeaturesModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _theme_switcher_theme_switcher_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./theme-switcher/theme-switcher.component */ 9963);
/* harmony import */ var _feature_landing_feature_landing_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./feature-landing/feature-landing.component */ 7098);
/* harmony import */ var _user_avatar_uploader_user_avatar_uploader_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-avatar-uploader/user-avatar-uploader.component */ 1014);
/* harmony import */ var _manage_alias_manage_alias_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manage-alias/manage-alias.component */ 1393);
/* harmony import */ var _crud_crud_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./crud/crud.component */ 9266);
/* harmony import */ var _qr_code_generator_qr_code_generator_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./qr-code-generator/qr-code-generator.component */ 5308);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 7070);
/* harmony import */ var angularx_qrcode__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! angularx-qrcode */ 100);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var _image_uploader_image_uploader_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./image-uploader/image-uploader.component */ 6687);
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../material/material.module */ 898);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4650);














let FeaturesModule = /*#__PURE__*/(() => {
  class FeaturesModule {
    static #_ = this.ɵfac = function FeaturesModule_Factory(t) {
      return new (t || FeaturesModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
      type: FeaturesModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_11__.NgxQRCodeModule, angularx_qrcode__WEBPACK_IMPORTED_MODULE_12__.QRCodeModule, _angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule, _material_material_module__WEBPACK_IMPORTED_MODULE_7__.MaterialModule]
    });
  }
  return FeaturesModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](FeaturesModule, {
    declarations: [_theme_switcher_theme_switcher_component__WEBPACK_IMPORTED_MODULE_0__.ThemeSwitcherComponent, _feature_landing_feature_landing_component__WEBPACK_IMPORTED_MODULE_1__.FeatureLandingComponent, _user_avatar_uploader_user_avatar_uploader_component__WEBPACK_IMPORTED_MODULE_2__.UserAvatarUploaderComponent, _manage_alias_manage_alias_component__WEBPACK_IMPORTED_MODULE_3__.ManageAliasComponent, _crud_crud_component__WEBPACK_IMPORTED_MODULE_4__.CrudComponent, _qr_code_generator_qr_code_generator_component__WEBPACK_IMPORTED_MODULE_5__.QrCodeGeneratorComponent, _image_uploader_image_uploader_component__WEBPACK_IMPORTED_MODULE_6__.ImageUploaderComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_11__.NgxQRCodeModule, angularx_qrcode__WEBPACK_IMPORTED_MODULE_12__.QRCodeModule, _angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule, _material_material_module__WEBPACK_IMPORTED_MODULE_7__.MaterialModule]
  });
})();

/***/ }),

/***/ 6687:
/*!*********************************************************************!*\
  !*** ./src/app/features/image-uploader/image-uploader.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ImageUploaderComponent": () => (/* binding */ ImageUploaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ImageUploaderComponent = /*#__PURE__*/(() => {
  class ImageUploaderComponent {
    constructor() {
      this.message = '';
      this.preview = '';
      this.strImage = '';
    }
    ngOnInit() {
      //this will run a get from the api
    }
    selectFile(event) {
      this.message = '';
      this.preview = '';
      this.selectedFiles = event.target.files;
      if (this.selectedFiles) {
        const file = this.selectedFiles.item(0);
        if (file) {
          this.preview = '';
          this.currentFile = file;
          const reader = new FileReader();
          reader.onload = e => {
            this.preview = e.target.result;
            this.strImage = e.target.result.replace(/^data:image\/[a-z]+;base64,/, "");
            console.log(this.strImage);
          };
          reader.readAsDataURL(this.currentFile);
        }
      }
    }
    upload() {
      if (this.selectedFiles) {
        const file = this.selectedFiles.item(0);
        if (file) {
          this.currentFile = file;
          console.log('clicked!');
          //This is where we will call the api to do the actual upload :)
        }
      }
    }
    static #_ = this.ɵfac = function ImageUploaderComponent_Factory(t) {
      return new (t || ImageUploaderComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ImageUploaderComponent,
      selectors: [["app-image-uploader"]],
      decls: 9,
      vars: 2,
      consts: [[1, "row"], [1, "col-8"], ["type", "file", "accept", "image/*", 3, "change"], [1, "preview", 3, "src"], [1, "flex", "items-center", "justify-between"], [1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled", "click"]],
      template: function ImageUploaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "label")(3, "input", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function ImageUploaderComponent_Template_input_change_3_listener($event) {
            return ctx.selectFile($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4)(7, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ImageUploaderComponent_Template_button_click_7_listener() {
            return ctx.upload();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Upload ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.preview, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.selectedFiles);
        }
      },
      styles: [".preview[_ngcontent-%COMP%] {\r\n    max-width: 200px;\r\n}"]
    });
  }
  return ImageUploaderComponent;
})();

/***/ }),

/***/ 1393:
/*!*****************************************************************!*\
  !*** ./src/app/features/manage-alias/manage-alias.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManageAliasComponent": () => (/* binding */ ManageAliasComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ManageAliasComponent = /*#__PURE__*/(() => {
  class ManageAliasComponent {
    static #_ = this.ɵfac = function ManageAliasComponent_Factory(t) {
      return new (t || ManageAliasComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ManageAliasComponent,
      selectors: [["app-manage-alias"]],
      decls: 2,
      vars: 0,
      template: function ManageAliasComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "manage-alias works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return ManageAliasComponent;
})();

/***/ }),

/***/ 5308:
/*!***************************************************************************!*\
  !*** ./src/app/features/qr-code-generator/qr-code-generator.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrCodeGeneratorComponent": () => (/* binding */ QrCodeGeneratorComponent)
/* harmony export */ });
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 7070);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var angularx_qrcode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angularx-qrcode */ 100);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 4793);





const _c0 = function () {
  return ["/", "org-event"];
};
let QrCodeGeneratorComponent = /*#__PURE__*/(() => {
  class QrCodeGeneratorComponent {
    constructor() {
      this.elementType = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_0__.NgxQrcodeElementTypes.URL;
      this.correctionLevel = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_0__.NgxQrcodeErrorCorrectionLevels.HIGH;
      this.value = 'google.com';
      this.myQrCode = '';
      // assign a value
      this.myQrCode = 'QR code data';
    }
    static #_ = this.ɵfac = function QrCodeGeneratorComponent_Factory(t) {
      return new (t || QrCodeGeneratorComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: QrCodeGeneratorComponent,
      selectors: [["app-qr-code-generator"]],
      decls: 12,
      vars: 18,
      consts: [["cssClass", "bshadow", 3, "elementType", "errorCorrectionLevel", "value"], [3, "qrdata", "width", "errorCorrectionLevel"], [1, "qrcodeImage"], [3, "qrdata", "allowEmptyString", "ariaLabel", "cssClass", "errorCorrectionLevel", "margin", "scale", "title", "width", "colorDark"], [1, "bg-blue-500", "hover:bg-blue-700", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "routerLink"]],
      template: function QrCodeGeneratorComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "ngx-qrcode2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "ngx-qrcode", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "angularx-qrcode");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "qrcode", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "h1");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "customized angularx-qrcode");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "qrcode", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "button", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Generate QR for Panelist\n");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("elementType", ctx.elementType)("errorCorrectionLevel", ctx.correctionLevel)("value", ctx.value);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("qrdata", "Your data string")("width", 256)("errorCorrectionLevel", "M");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("qrdata", ctx.myQrCode)("allowEmptyString", true)("ariaLabel", "QR Code image with the following content...")("cssClass", "right")("errorCorrectionLevel", "M")("margin", 4)("scale", 1)("title", "A custom title attribute")("width", 256)("colorDark", "#3f51b5");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](17, _c0));
        }
      },
      dependencies: [_techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_0__.QrcodeComponent, angularx_qrcode__WEBPACK_IMPORTED_MODULE_2__.QRCodeComponent, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink]
    });
  }
  return QrCodeGeneratorComponent;
})();

/***/ }),

/***/ 9963:
/*!*********************************************************************!*\
  !*** ./src/app/features/theme-switcher/theme-switcher.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ThemeSwitcherComponent": () => (/* binding */ ThemeSwitcherComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let ThemeSwitcherComponent = /*#__PURE__*/(() => {
  class ThemeSwitcherComponent {
    constructor() {
      this.headerFooter = false;
      this.theme = 'theme-grays';
    }
    // onThemeUpdate(updated: boolean) {
    // 	if (updated) this.theme = localStorage.getItem('theme')!;
    // }
    ngOnInit() {
      // localStorage.getItem('theme') === null
      //   ? localStorage.setItem('theme', this.theme)
      //   : (this.theme = localStorage.getItem('theme')!);;
    }
    static #_ = this.ɵfac = function ThemeSwitcherComponent_Factory(t) {
      return new (t || ThemeSwitcherComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ThemeSwitcherComponent,
      selectors: [["app-theme-switcher"]],
      decls: 225,
      vars: 3,
      consts: [[1, "header", "flex", "justify-between", "items-center", "p-3"], [1, "user-info", "flex", "items-center", "gap-4"], ["src", "/assets/images/icon/small-logo-image.png", "alt", "Profile image", 1, "w-12"], [1, "uppercase", "title-text"], [1, "menu", "flex", "items-center", "gap-4"], ["src", "/assets/images/icon/qr-icon.svg", "alt", "QR icon", 1, "header-icon"], ["src", "/assets/images/icon/hamburger-menu-icon.svg", "alt", "Menu icon", 1, "header-icon"], [1, "bg-profile", "p-4"], [1, "flex"], ["src", "/assets/images/ImgPlaceholder.svg", 1, "w-16"], [1, "ml-6"], [1, "text-lg", "text", "uppercase", "font-medium", "title-text"], [1, "grid", "grid-cols-4", "gap-2"], ["src", "/assets/images/icon/facebook-social.png", "alt", "Facebook", 1, "w-10"], ["src", "/assets/images/icon/linkedin-social.png", "alt", "LinkedIn", 1, "w-10"], ["src", "/assets/images/icon/x-social.png", "alt", "X / Twitter", 1, "w-10"], ["src", "/assets/images/icon/instagram-social.png", "alt", "Instagram", 1, "w-10"], [1, "bg-about", "0", "px-8", "text-center", "py-10"], [1, "font-bold", "text-sm", "uppercase", "text-center", "leading-10", "title-text"], [1, "pb-4", "text-sm"], [1, "w-9/12", "mx-auto", "mt-8", "space-y-6"], [1, "ring-1", "primary-button", "ring-gray-600", "shadow-md", "text-center", "py-3", "rounded-full"], [1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10", "badges"], [1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-2xl", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-badge"], ["src", "/assets/images/icon/quest-icon.svg", "alt", "Quest icon", 1, "w-10", "mt-2.5"], [1, "absolute", "inset-0", "flex", "items-center", "justify-center"], [1, "w-12", "h-12", "bg-badge-blur", "blur-md", "rounded-full"], [1, "text-center", "pt-1", "w-full"], ["src", "/assets/images/icon/badges-icon.svg", "alt", "Badges icon", 1, "w-10", "mt-2.5"], ["src", "/assets/images/icon/rewards-icon.svg", "alt", "Rewards icon", 1, "w-10", "mt-2.5"], ["id", "theme-blues"], ["id", "theme-reds"], ["id", "theme-purples"]],
      template: function ThemeSwitcherComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "User's Profile");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "img", 5)(8, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 7)(10, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 10)(13, "div", 8)(14, "p", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, " full name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "img", 13)(18, "img", 14)(19, "img", 15)(20, "img", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 17)(22, "h1", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "about me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 20)(29, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, " Website 1 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, " Website 2 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, " Website 3 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 22)(36, "div", 23)(37, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](38, "img", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 23)(44, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 23)(51, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "img", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](54, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, " My Rewards ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 31)(58, "div", 0)(59, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](60, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "User's Profile");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "img", 5)(65, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "div", 7)(67, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](68, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 10)(70, "p", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](71, " full name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](73, "img", 13)(74, "img", 14)(75, "img", 15)(76, "img", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "div", 17)(78, "h1", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](79, "about me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "div", 20)(85, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](86, " Website 1 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, " Website 2 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](90, " Website 3 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "div", 22)(92, "div", 23)(93, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](94, "img", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](96, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](98, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "div", 23)(100, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](101, "img", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](103, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](105, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "div", 23)(107, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](108, "img", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](110, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 32)(114, "div", 0)(115, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](116, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](118, "User's Profile");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](120, "img", 5)(121, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 7)(123, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](124, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 10)(126, "p", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](127, " full name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](129, "img", 13)(130, "img", 14)(131, "img", 15)(132, "img", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "div", 17)(134, "h1", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](135, "about me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](137, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](139, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "div", 20)(141, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](142, " Website 1 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](144, " Website 2 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](146, " Website 3 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 22)(148, "div", 23)(149, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](150, "img", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](152, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](154, " My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "div", 23)(156, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](157, "img", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](159, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](161, " My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "div", 23)(163, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](164, "img", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](165, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](166, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](168, " My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](169, "div", 33)(170, "div", 0)(171, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](172, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](173, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](174, "User's Profile");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](175, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](176, "img", 5)(177, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](178, "div", 7)(179, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](180, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](181, "div", 10)(182, "p", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](183, " full name ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](184, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](185, "img", 13)(186, "img", 14)(187, "img", 15)(188, "img", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](189, "div", 17)(190, "h1", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](191, "about me:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](192, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](193, " Cupcake ipsum dolor sit amet macaroon jelly beans. Wafer danish biscuit shortbread chupa chups. Jelly tart jujubes biscuit cake pastry candy candy danish. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](194, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](195, " Pudding cheesecake toffee ice cream souffl\u00E9. Caramels sugar plum jelly cupcake gummi bears. Icing tiramisu halvah biscuit pie brownie chocolate cake jelly. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](196, "div", 20)(197, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](198, " Website 1 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](199, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](200, " Website 2 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](201, "div", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](202, " Website 3 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](203, "div", 22)(204, "div", 23)(205, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](206, "img", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](207, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](208, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](209, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](210, " My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](211, "div", 23)(212, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](213, "img", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](214, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](215, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](216, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](217, " My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](218, "div", 23)(219, "div", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](220, "img", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](221, "div", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](222, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](223, "p", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](224, " My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("content ", ctx.theme, "");
        }
      },
      styles: [".theme-container[_ngcontent-%COMP%] {\r\n\tposition: relative;\r\n}\r\n\r\nlabel[_ngcontent-%COMP%] {\r\n\tborder: 0;\r\n\tclip: rect(0 0 0 0);\r\n\theight: 1px;\r\n\tmargin: -1px;\r\n\toverflow: hidden;\r\n\tpadding: 0;\r\n\tposition: absolute;\r\n\twidth: 1px;\r\n}\r\n\r\n.theme-options[_ngcontent-%COMP%] {\r\n\tdisplay: grid;\r\n\tgrid-template-columns: repeat(2, 1fr);\r\n\tgrid-gap: 1.6rem;\r\n\tmargin: 10px 0;\r\n\r\n\t& select {\r\n\t\twidth: 150px;\r\n    font-size: 14px;\r\n\t}\r\n}\r\n\r\n.test-switcher[_ngcontent-%COMP%] {\r\n\tdisplay: none;\r\n}\r\n\r\n.color-block[_ngcontent-%COMP%] {\r\n\twidth: 15px;\r\n\theight: 15px;\r\n}\r\n\r\n.content.theme-grays[_ngcontent-%COMP%] {\r\n\t.color-one {\r\n\t\tbackground-color: #000;\r\n\t}\r\n\t.text {\r\n\t\tcolor: #000;\r\n\t}\r\n\t.color-two,\r\n\t.bg-badge,\r\n\t.bg-footer {\r\n\t\tbackground-color: #353535;\r\n\t}\r\n\t.color-three {\r\n\t\tbackground-color: #7E7E7E;\r\n\t}\r\n\t.color-four,\r\n\t.bg-profile,\r\n\t.bg-badge-blur {\r\n\t\tbackground-color: #979797;\r\n\t}\r\n\t.color-five {\r\n\t\tbackground-color: #CCC;\r\n\t}\r\n\t.color-six,\r\n\t.header,\r\n\t.bg-about,\r\n\t.primary-button\r\n\t{\r\n\t\tbackground-color: #DADADA;\r\n\t}\r\n\t.color-seven {\r\n\t\tbackground-color: #F6F6F6;\r\n\t}\r\n\t.color-eight {\r\n\t\tbackground-color: #FFF;\r\n\t}\r\n\t.text-white {\r\n\t\tcolor: #FFF;\r\n\t}\r\n\t.header .title-text,\r\n\t.bg-profile .title-text,\r\n\t.bg-about .title-text {\r\n\t\tfont-family: 'Roboto Slab', serif;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 700;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n\t.header .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 21px;\r\n\t\tcolor: #000000;\r\n\t}\r\n\t.bg-profile .title-text {\r\n\t\tfont-size: 20.8499px;\r\n\t\tline-height: 27px;\r\n\t\tcolor: #212121;\r\n\t}\r\n\t.bg-about .title-text {\r\n\t\tfont-size: 14px;\r\n\t\tline-height: 18px;\r\n\t\ttext-align: center;\r\n\t\tcolor: #212121;\r\n\t}\r\n\t.primary-button,\r\n\t.badges {\r\n\t\tfont-family: 'Montserrat', sans-serif;\r\n\t\tfont-style: normal;\r\n\t\ttext-align: center;\r\n\t\tletter-spacing: -0.02em;\r\n\t\t\r\n\t\tcolor: #353535;\r\n\t}\r\n\t.primary-button {\r\n\t\tfont-weight: 600;\r\n\t\tfont-size: 14px;\r\n\t\tline-height: 17px;\r\n\t}\r\n\t.badges {\r\n\t\tfont-weight: 700;\r\n\t\tfont-size: 9px;\r\n\t\tline-height: 11px;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n}\r\n\r\n.content.theme-blues[_ngcontent-%COMP%] {\r\n\t.header-icon {\r\n\t\tfilter: invert(100%) sepia(100%) saturate(0%) hue-rotate(205deg) brightness(101%) contrast(102%);\r\n\t}\r\n\t.color-one {\r\n\t\tbackground-color: #000;\r\n\t}\r\n\t.text {\r\n\t\tcolor: #000;\r\n\t}\r\n\t.color-two {\r\n\t\tbackground-color: #979797;\r\n\t}\r\n\t.color-three,\r\n\t.bg-badge,\r\n\t.bg-footer {\r\n\t\tbackground-color: #031A35;\r\n\t}\r\n\t.color-four,\r\n\t.header,\r\n\t.bg-profile,\r\n\t.primary-button {\r\n\t\tbackground-color: #063771;\r\n\t}\r\n\t.color-five {\r\n\t\tbackground-color: #064C91;\r\n\t}\r\n\t.color-six,\r\n\t.bg-badge-blur {\r\n\t\tbackground-color: #2B5CC4;\r\n\t}\r\n\t.color-seven,\r\n\t.bg-about {\r\n\t\tbackground-color: #D3E5FD;\r\n\t}\r\n\t.color-eight {\r\n\t\tbackground-color: #FFF;\r\n\t}\r\n\t.header,\r\n\t.bg-profile p,\r\n\t.primary-button,\r\n\t.text-white {\r\n\t\tcolor: #FFF;\r\n\t}\r\n\t.header .title-text,\r\n\t.bg-profile .title-text,\r\n\t.bg-about .title-text,\r\n\t.badges {\r\n\t\tfont-family: 'Merienda One', cursive;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 400;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n\t.header .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 23px;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.bg-profile .title-text {\r\n\t\tfont-size: 20.8499px;\r\n\t\tline-height: 30px;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.bg-about .title-text {\r\n\t\tfont-size: 14px;\r\n\t\tline-height: 20px;\r\n\t\ttext-align: center;\r\n\t\tcolor: #212121;\r\n\t}\r\n\t.primary-button,\r\n\t.badges {\r\n\t\tline-height: 16px;\r\n\t\ttext-align: center;\r\n\t\tletter-spacing: -0.02em;\r\n\t}\r\n\t.primary-button {\r\n\t\tfont-family: 'Tenor Sans', sans-serif;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 400;\r\n\t\tfont-size: 14px;\r\n\t}\r\n\t.badges {\r\n\t\tfont-size: 11px;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n}\r\n\r\n.content.theme-reds[_ngcontent-%COMP%] {\r\n\t.header-icon {\r\n\t\tfilter: invert(100%) sepia(100%) saturate(0%) hue-rotate(205deg) brightness(101%) contrast(102%);\r\n\t}\r\n\t.color-one,\r\n\t.bg-badge {\r\n\t\tbackground-color: #000;\r\n\t}\r\n\t.color-two,\r\n\t.header,\r\n\t.bg-profile {\r\n\t\tbackground-color: #252525;\r\n\t}\r\n\t.color-three {\r\n\t\tbackground-color: #666;\r\n\t}\r\n\t.color-four {\r\n\t\tbackground-color: #aaadae;\r\n\t}\r\n\t.color-five {\r\n\t\tbackground-color: #DADADA;\r\n\t}\r\n\t.color-six {\r\n\t\tbackground-color: #840417;\r\n\t}\r\n\t.color-seven,\r\n\t.primary-button,\r\n\t.bg-badge-blur {\r\n\t\tbackground-color: #C9132F;\r\n\t}\r\n\t.color-eight {\r\n\t\tbackground-color: #FFF;\r\n\t}\r\n\t.header,\r\n\t.bg-profile p,\r\n\t.primary-button,\r\n\t.text-white {\r\n\t\tcolor: #FFF;\r\n\t}\r\n\t.primary-button {\r\n\t\tborder-radius: 0px;\r\n\t}\r\n\t.header .title-text,\r\n\t.bg-profile .title-text,\r\n\t.bg-about .title-text,\r\n\t.primary-button,\r\n\t.badges {\r\n\t\tfont-family: 'Anton', sans-serif;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 700;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n\t.header .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 24px;\r\n\t\tletter-spacing: 0.02em;\r\n\t\tcolor: #FFF;\r\n\t}\r\n\t.bg-profile .title-text {\r\n\t\tfont-size: 21.85px;\r\n\t\tline-height: 33px;\r\n\t\tletter-spacing: 0.02em;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.bg-about .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 24px;\r\n\t\ttext-align: center;\r\n\t\tcolor: #212121;\r\n\t}\r\n\t.primary-button,\r\n\t.badges {\r\n\t\ttext-align: center;\r\n\t\tletter-spacing: -0.02em;\r\n\t}\r\n\t.primary-button {\r\n\t\tfont-size: 14px;\r\n\t\tline-height: 21px;\r\n\t\tcolor: #FFFFFF;\r\n\t\ttext-transform: none;\r\n\t}\r\n\t.badges {\r\n\t\tfont-size: 13px;\r\n\t\tline-height: 20px;\r\n\t\tcolor: #353535;\r\n\t}\r\n}\r\n\r\n.content.theme-purples[_ngcontent-%COMP%] {\r\n\t.header-icon {\r\n\t\tfilter: invert(100%) sepia(100%) saturate(0%) hue-rotate(205deg) brightness(101%) contrast(102%);\r\n\t}\r\n\t.color-one {\r\n\t\tbackground-color: #000;\r\n\t}\r\n\t.color-two {\r\n\t\tbackground-color: #34034B;\r\n\t}\r\n\t.color-three {\r\n\t\tbackground-color: #561E6E;\r\n\t}\r\n\t.color-four,\r\n\t.header,\r\n\t.bg-profile {\r\n\t\tbackground-color: #60217B;\r\n\t}\r\n\t.color-five {\r\n\t\tbackground-color: #8A3BAB;\r\n\t}\r\n\t.color-six {\r\n\t\tbackground-color: #E4BC34;\r\n\t}\r\n\t.color-seven {\r\n\t\tbackground-color: #FFD950;\r\n\t}\r\n\t.color-eight {\r\n\t\tbackground-color: #FFF;\r\n\t}\r\n\t.header,\r\n\t.bg-profile p,\r\n\t.primary-button,\r\n\t.text-white {\r\n\t\tcolor: #FFF;\r\n\t}\r\n\t.primary-button {\r\n\t\tbackground: linear-gradient(180deg, #60217B 0%, #34034B 100%);\r\n\t\tborder: 2px solid #FFD950;\r\n\t\tbox-shadow: 0px 4px 10px 1px rgba(183, 183, 183, 0.25);\r\n\t\tborder-radius: 100px;\r\n\t}\r\n\t.bg-badge {\r\n\t\tbackground: linear-gradient(180deg, #60217B 0%, #34034B 100%);\r\n\t\tborder: 2px solid #FFD950;\r\n\t\tbox-shadow: 0px 3.6px 3.6px rgba(0, 0, 0, 0.18);\r\n\t}\r\n\t.header .title-text,\r\n\t.bg-profile .title-text,\r\n\t.bg-about .title-text {\r\n\t\tfont-family: 'Titan One', sans-serif;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 400;\r\n\t\ttext-transform: uppercase;\r\n\t}\r\n\t.header .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 18px;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.bg-profile .title-text {\r\n\t\tfont-size: 22.85px;\r\n\t\tline-height: 26px;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.bg-about .title-text {\r\n\t\tfont-size: 16px;\r\n\t\tline-height: 18px;\r\n\t\ttext-align: center;\r\n\t\tcolor: #212121;\r\n\t}\r\n\t.primary-button,\r\n\t.badges {\r\n\t\tfont-family: 'Merriweather Sans', sans-serif;\r\n\t\tfont-style: normal;\r\n\t\tfont-weight: 700;\r\n\t\ttext-align: center;\r\n\t\tletter-spacing: -0.02em;\r\n\t}\r\n\t.primary-button {\r\n\t\tfont-size: 14px;\r\n\t\tline-height: 18px;\r\n\t\tcolor: #FFFFFF;\r\n\t}\r\n\t.badges {\r\n\t\tfont-size: 9px;\r\n\t\tline-height: 11px;\r\n\t\ttext-transform: uppercase;\r\n\t\tcolor: #353535;\r\n\t}\r\n}"]
    });
  }
  return ThemeSwitcherComponent;
})();

/***/ }),

/***/ 1014:
/*!*********************************************************************************!*\
  !*** ./src/app/features/user-avatar-uploader/user-avatar-uploader.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserAvatarUploaderComponent": () => (/* binding */ UserAvatarUploaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UserAvatarUploaderComponent = /*#__PURE__*/(() => {
  class UserAvatarUploaderComponent {
    static #_ = this.ɵfac = function UserAvatarUploaderComponent_Factory(t) {
      return new (t || UserAvatarUploaderComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UserAvatarUploaderComponent,
      selectors: [["app-user-avatar-uploader"]],
      decls: 9,
      vars: 0,
      consts: [["title", "create-an-avatar-uploader-with-angular", "target", "_blank", "href", "https://medium.com/@ruslan.ap2/how-to-create-an-avatar-uploader-with-angular-9fe89ff4fe60"], ["title", "user-avatar-reusable-components", "target", "_blank", "href", "https://zrolson.medium.com/user-avatar-reusable-components-30ed45b9f605"]],
      template: function UserAvatarUploaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "user-avatar-uploader works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ul")(3, "li")(4, "a", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " https://medium.com/@ruslan.ap2/how-to-create-an-avatar-uploader-with-angular-9fe89ff4fe60");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "li")(7, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " https://zrolson.medium.com/user-avatar-reusable-components-30ed45b9f605");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return UserAvatarUploaderComponent;
})();

/***/ }),

/***/ 3648:
/*!******************************************************************************!*\
  !*** ./src/app/guest/guest-public-landing/guest-public-landing.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GuestPublicLandingComponent": () => (/* binding */ GuestPublicLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _user_badge_panel_user_badge_panel_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../user-badge-panel/user-badge-panel.component */ 8454);
/* harmony import */ var _user_bio_panel_user_bio_panel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../user-bio-panel/user-bio-panel.component */ 1771);
/* harmony import */ var _user_link_panel_user_link_panel_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../user-link-panel/user-link-panel.component */ 8461);




let GuestPublicLandingComponent = /*#__PURE__*/(() => {
  class GuestPublicLandingComponent {
    static #_ = this.ɵfac = function GuestPublicLandingComponent_Factory(t) {
      return new (t || GuestPublicLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: GuestPublicLandingComponent,
      selectors: [["app-guest-public-landing"]],
      decls: 3,
      vars: 0,
      template: function GuestPublicLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-user-bio-panel")(1, "app-user-link-panel")(2, "app-user-badge-panel");
        }
      },
      dependencies: [_user_badge_panel_user_badge_panel_component__WEBPACK_IMPORTED_MODULE_0__.UserBadgePanelComponent, _user_bio_panel_user_bio_panel_component__WEBPACK_IMPORTED_MODULE_1__.UserBioPanelComponent, _user_link_panel_user_link_panel_component__WEBPACK_IMPORTED_MODULE_2__.UserLinkPanelComponent]
    });
  }
  return GuestPublicLandingComponent;
})();

/***/ }),

/***/ 1277:
/*!***************************************!*\
  !*** ./src/app/guest/guest.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GuestModule": () => (/* binding */ GuestModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _guest_public_landing_guest_public_landing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guest-public-landing/guest-public-landing.component */ 3648);
/* harmony import */ var _user_badge_panel_user_badge_panel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-badge-panel/user-badge-panel.component */ 8454);
/* harmony import */ var _user_bio_panel_user_bio_panel_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-bio-panel/user-bio-panel.component */ 1771);
/* harmony import */ var _user_link_panel_user_link_panel_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-link-panel/user-link-panel.component */ 8461);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.module */ 4466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4650);







let GuestModule = /*#__PURE__*/(() => {
  class GuestModule {
    static #_ = this.ɵfac = function GuestModule_Factory(t) {
      return new (t || GuestModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: GuestModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule]
    });
  }
  return GuestModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](GuestModule, {
    declarations: [_guest_public_landing_guest_public_landing_component__WEBPACK_IMPORTED_MODULE_0__.GuestPublicLandingComponent, _user_badge_panel_user_badge_panel_component__WEBPACK_IMPORTED_MODULE_1__.UserBadgePanelComponent, _user_bio_panel_user_bio_panel_component__WEBPACK_IMPORTED_MODULE_2__.UserBioPanelComponent, _user_link_panel_user_link_panel_component__WEBPACK_IMPORTED_MODULE_3__.UserLinkPanelComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule],
    exports: [_guest_public_landing_guest_public_landing_component__WEBPACK_IMPORTED_MODULE_0__.GuestPublicLandingComponent, _user_badge_panel_user_badge_panel_component__WEBPACK_IMPORTED_MODULE_1__.UserBadgePanelComponent, _user_bio_panel_user_bio_panel_component__WEBPACK_IMPORTED_MODULE_2__.UserBioPanelComponent, _user_link_panel_user_link_panel_component__WEBPACK_IMPORTED_MODULE_3__.UserLinkPanelComponent]
  });
})();

/***/ }),

/***/ 8454:
/*!**********************************************************************!*\
  !*** ./src/app/guest/user-badge-panel/user-badge-panel.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserBadgePanelComponent": () => (/* binding */ UserBadgePanelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UserBadgePanelComponent = /*#__PURE__*/(() => {
  class UserBadgePanelComponent {
    static #_ = this.ɵfac = function UserBadgePanelComponent_Factory(t) {
      return new (t || UserBadgePanelComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UserBadgePanelComponent,
      selectors: [["app-user-badge-panel"]],
      decls: 30,
      vars: 0,
      consts: [["id", "badges", 1, "grid", "grid-cols-3", "gap-4", "w-10/12", "mx-auto", "mt-12", "mb-10"], ["id", "badgesQuests", 1, "flex", "flex-col", "items-center"], [1, "relative", "shadow-2xl", "shadow-black/50", "w-24", "h-24", "flex", "items-center", "justify-center", "rounded-full", "bg-blue-900", "ring-2", "ring-white"], [1, "absolute", "inset-0", "flex", "items-center", "justify-center"], [1, "w-12", "h-12", "bg-blue-600", "blur-md", "rounded-full"], [1, "text-center", "w-full", "text-white", "z-30"], ["href", "#", "title", "quest badge"], ["src", "../assets/images/onboarding-images/quest.png", "alt", "quest badge", 1, "w-auto", "h-14", "mt-2", "mx-auto"], [1, "text-center", "text-sm", "pt-1", "w-full"], ["id", "badgesMine", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "my badges"], ["src", "../assets/images/onboarding-images/badges.png", "alt", "badges", 1, "w-auto", "h-12", "mx-auto", "mt-3"], ["id", "badgesRewards", 1, "flex", "flex-col", "items-center"], ["href", "#", "title", "rewards badge"], ["src", "../assets/images/onboarding-images/rewards.png", "alt", "rewards badge", 1, "w-auto", "h-16", "mx-auto", "mt-3"]],
      template: function UserBadgePanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5)(6, "div", 5)(7, "a", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "My Quest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9)(12, "div", 2)(13, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 5)(16, "a", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "img", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "p", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "My Badges");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 12)(21, "div", 2)(22, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 5)(25, "div", 5)(26, "a", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "img", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "My Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return UserBadgePanelComponent;
})();

/***/ }),

/***/ 1771:
/*!******************************************************************!*\
  !*** ./src/app/guest/user-bio-panel/user-bio-panel.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserBioPanelComponent": () => (/* binding */ UserBioPanelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UserBioPanelComponent = /*#__PURE__*/(() => {
  class UserBioPanelComponent {
    static #_ = this.ɵfac = function UserBioPanelComponent_Factory(t) {
      return new (t || UserBioPanelComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UserBioPanelComponent,
      selectors: [["app-user-bio-panel"]],
      decls: 16,
      vars: 0,
      consts: [["id", "header", 1, "bg-patchwrq", "p-4", "rounded-b-3xl", "bg-cover", "bg-center", 2, "background-image", "url('/assets/images/onboarding-images/PatchwrqBg.png')"], [1, "flex", "justify-center"], ["alt", "John Bianchi", "src", "../assets/images/onboarding-images/JohnBianchi.png", 1, "mx-auto", "mb-4"], [1, "text-2xl", "mb-4", "text-white", "uppercase"], [1, "w-52", "mx-auto", "relative"], [1, "grid", "grid-cols-4", "gap-2", "absolute", "top-1"], ["href", "https://www.facebook.com/john.bianchi221", "target", "blank", "title", "Facebook"], ["alt", "Facebook logo", "src", "../assets/images/onboarding-images/Facebook.png", 1, "w-15", "h-15", "mr-2"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], ["alt", "LinkedIn logo", "src", "../assets/images/onboarding-images/Linkedin.tif.png", 1, "w-15", "h-15", "mr-2"], ["href", "https://x.com/BTCJohnnyB", "target", "blank", "title", "Twitter X"], ["alt", "Twitter X logo", "src", "../assets/images/onboarding-images/X.tif.png", 1, "w-15", "h-15", "mr-2"], ["href", "https://www.instagram.com/bianchidoingthings/", "target", "blank", "title", "Instagram"], ["alt", "Instagram logo", "src", "../assets/images/onboarding-images/Instagram.tif.png", 1, "w-15", "h-15"]],
      template: function UserBioPanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "John Bianchi");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4)(7, "div", 5)(8, "a", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "a", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "img", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        }
      }
    });
  }
  return UserBioPanelComponent;
})();

/***/ }),

/***/ 8461:
/*!********************************************************************!*\
  !*** ./src/app/guest/user-link-panel/user-link-panel.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserLinkPanelComponent": () => (/* binding */ UserLinkPanelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UserLinkPanelComponent = /*#__PURE__*/(() => {
  class UserLinkPanelComponent {
    static #_ = this.ɵfac = function UserLinkPanelComponent_Factory(t) {
      return new (t || UserLinkPanelComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UserLinkPanelComponent,
      selectors: [["app-user-link-panel"]],
      decls: 16,
      vars: 0,
      consts: [["id", "links"], ["id", "QRcode", 1, "pb-4", "pt-12", "mt-3"], ["alt", "QR Code", "src", "../assets/images/onboarding-images/de4ZAy.tif.png", 1, "h-48", "p-4", "ring-1", "rounded-lg", "mx-auto"], [1, "w-9/12", "mx-auto", "mt-8", "space-y-6", "text-white"], ["href", "https://www.linkedin.com/in/bianchijohn/", "target", "blank", "title", "LinkedIn"], [1, "w-full", "ring-4", "bg-blue-900", "ring-gray-900", "truncate", "shadow-md", "text-center", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto"], ["href", "https://www.circlepass.io/patchwrq", "target", "blank", "title", "PatchWRQ Site"], ["href", "https://www.circlepass.io/quest", "target", "blank", "title", "Quest App"]],
      template: function UserLinkPanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3)(4, "p")(5, "a", 4)(6, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " LinkedIn ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p")(9, "a", 6)(10, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, " PatchWRQ Site ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "p")(13, "a", 7)(14, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, " Quest App ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
        }
      }
    });
  }
  return UserLinkPanelComponent;
})();

/***/ }),

/***/ 898:
/*!*********************************************!*\
  !*** ./src/app/material/material.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaterialModule": () => (/* binding */ MaterialModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/a11y */ 2687);
/* harmony import */ var _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/clipboard */ 4025);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 3555);
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @angular/cdk/portal */ 4080);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @angular/cdk/scrolling */ 7376);
/* harmony import */ var _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/stepper */ 2138);
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/table */ 5013);
/* harmony import */ var _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/cdk/tree */ 7851);
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/autocomplete */ 7957);
/* harmony import */ var _angular_material_badge__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/badge */ 2673);
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/bottom-sheet */ 8242);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/button */ 4859);
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/button-toggle */ 811);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/card */ 3546);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/checkbox */ 6709);
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/chips */ 7331);
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/stepper */ 8425);
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/datepicker */ 148);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/dialog */ 5938);
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/divider */ 4850);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/expansion */ 9652);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/grid-list */ 782);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 7392);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/input */ 284);
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/list */ 6338);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/menu */ 8255);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/core */ 7873);
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/paginator */ 8739);
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/material/progress-bar */ 3162);
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/material/progress-spinner */ 1572);
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/radio */ 1948);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/material/select */ 4385);
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/material/sidenav */ 3267);
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/material/slider */ 7314);
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/material/slide-toggle */ 455);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/material/snack-bar */ 7009);
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/material/sort */ 6308);
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/material/table */ 3626);
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/material/tabs */ 3848);
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/toolbar */ 3683);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/material/tooltip */ 266);
/* harmony import */ var _angular_material_tree__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @angular/material/tree */ 5423);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);












































let MaterialModule = /*#__PURE__*/(() => {
  class MaterialModule {
    static #_ = this.ɵfac = function MaterialModule_Factory(t) {
      return new (t || MaterialModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: MaterialModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__.MatMenuModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__.MatToolbarModule, _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_6__.A11yModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_7__.ClipboardModule, _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_8__.CdkStepperModule, _angular_cdk_table__WEBPACK_IMPORTED_MODULE_9__.CdkTableModule, _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_10__.CdkTreeModule, _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_11__.DragDropModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_12__.MatAutocompleteModule, _angular_material_badge__WEBPACK_IMPORTED_MODULE_13__.MatBadgeModule, _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_14__.MatBottomSheetModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__.MatButtonToggleModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardModule, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_17__.MatCheckboxModule, _angular_material_chips__WEBPACK_IMPORTED_MODULE_18__.MatChipsModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_19__.MatStepperModule, _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_20__.MatDatepickerModule, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_21__.MatDialogModule, _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__.MatDividerModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_23__.MatExpansionModule, _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_24__.MatGridListModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_input__WEBPACK_IMPORTED_MODULE_25__.MatInputModule, _angular_material_list__WEBPACK_IMPORTED_MODULE_26__.MatListModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__.MatMenuModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_27__.MatNativeDateModule, _angular_material_paginator__WEBPACK_IMPORTED_MODULE_28__.MatPaginatorModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_29__.MatProgressBarModule, _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_30__.MatProgressSpinnerModule, _angular_material_radio__WEBPACK_IMPORTED_MODULE_31__.MatRadioModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_27__.MatRippleModule, _angular_material_select__WEBPACK_IMPORTED_MODULE_32__.MatSelectModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_33__.MatSidenavModule, _angular_material_slider__WEBPACK_IMPORTED_MODULE_34__.MatSliderModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_35__.MatSlideToggleModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_36__.MatSnackBarModule, _angular_material_sort__WEBPACK_IMPORTED_MODULE_37__.MatSortModule, _angular_material_table__WEBPACK_IMPORTED_MODULE_38__.MatTableModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_39__.MatTabsModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__.MatToolbarModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_40__.MatTooltipModule, _angular_material_tree__WEBPACK_IMPORTED_MODULE_41__.MatTreeModule, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_42__.PortalModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_43__.ScrollingModule]
    });
  }
  return MaterialModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](MaterialModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__.MatMenuModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__.MatToolbarModule],
    exports: [_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_6__.A11yModule, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_7__.ClipboardModule, _angular_cdk_stepper__WEBPACK_IMPORTED_MODULE_8__.CdkStepperModule, _angular_cdk_table__WEBPACK_IMPORTED_MODULE_9__.CdkTableModule, _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_10__.CdkTreeModule, _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_11__.DragDropModule, _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_12__.MatAutocompleteModule, _angular_material_badge__WEBPACK_IMPORTED_MODULE_13__.MatBadgeModule, _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_14__.MatBottomSheetModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_2__.MatButtonModule, _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__.MatButtonToggleModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_16__.MatCardModule, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_17__.MatCheckboxModule, _angular_material_chips__WEBPACK_IMPORTED_MODULE_18__.MatChipsModule, _angular_material_stepper__WEBPACK_IMPORTED_MODULE_19__.MatStepperModule, _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_20__.MatDatepickerModule, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_21__.MatDialogModule, _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__.MatDividerModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_23__.MatExpansionModule, _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_24__.MatGridListModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule, _angular_material_input__WEBPACK_IMPORTED_MODULE_25__.MatInputModule, _angular_material_list__WEBPACK_IMPORTED_MODULE_26__.MatListModule, _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__.MatMenuModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_27__.MatNativeDateModule, _angular_material_paginator__WEBPACK_IMPORTED_MODULE_28__.MatPaginatorModule, _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_29__.MatProgressBarModule, _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_30__.MatProgressSpinnerModule, _angular_material_radio__WEBPACK_IMPORTED_MODULE_31__.MatRadioModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_27__.MatRippleModule, _angular_material_select__WEBPACK_IMPORTED_MODULE_32__.MatSelectModule, _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_33__.MatSidenavModule, _angular_material_slider__WEBPACK_IMPORTED_MODULE_34__.MatSliderModule, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_35__.MatSlideToggleModule, _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_36__.MatSnackBarModule, _angular_material_sort__WEBPACK_IMPORTED_MODULE_37__.MatSortModule, _angular_material_table__WEBPACK_IMPORTED_MODULE_38__.MatTableModule, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_39__.MatTabsModule, _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__.MatToolbarModule, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_40__.MatTooltipModule, _angular_material_tree__WEBPACK_IMPORTED_MODULE_41__.MatTreeModule, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_42__.PortalModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_43__.ScrollingModule]
  });
})();

/***/ }),

/***/ 1384:
/*!***********************************************************************************!*\
  !*** ./src/app/organization/create-organization/create-organization.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateOrganizationComponent": () => (/* binding */ CreateOrganizationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/organization.service */ 4261);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateOrganizationComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organization Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateOrganizationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Email is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateOrganizationComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Contact Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateOrganizationComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Address is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateOrganizationComponent = /*#__PURE__*/(() => {
  class CreateOrganizationComponent {
    constructor(orgService, fb) {
      this.orgService = orgService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.organizationForm = this.fb.group({
        organization_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.email]],
        point_of_contact_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        address_line1: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.organizationForm.valid) {
      event.preventDefault();
      console.log("Org Form Value", this.organizationForm.value);
      //create organization call 
      //use subscribe with next and error object as per new standard
      this.orgService.createOrganization(this.organizationForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.organizationForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Org completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateOrganizationComponent_Factory(t) {
      return new (t || CreateOrganizationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__.OrganizationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateOrganizationComponent,
      selectors: [["app-create-organization"]],
      decls: 33,
      vars: 6,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "organization_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_name", "id", "organization_name", "type", "text", "placeholder", "Enter Org Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Org Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "point_of_contact_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "point_of_contact_name", "id", "point_of_contact_name", "type", "text", "placeholder", "Enter Org Point of Contact Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "address_line1", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line1", "id", "address_line1", "placeholder", "Enter Org Address", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateOrganizationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "ORGANIZATION DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateOrganizationComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Organization Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, CreateOrganizationComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Organization Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, CreateOrganizationComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Organization Point of Contact Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](23, CreateOrganizationComponent_div_23_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 12)(25, "label", 13)(26, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Organization Address");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "textarea", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](29, CreateOrganizationComponent_div_29_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "div", 15)(31, "button", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, " Create Org ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_4_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.organizationForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationForm && (ctx.organizationForm == null ? null : (tmp_1_0 = ctx.organizationForm.get("organization_name")) == null ? null : tmp_1_0.invalid) && ((ctx.organizationForm == null ? null : (tmp_1_0 = ctx.organizationForm.get("organization_name")) == null ? null : tmp_1_0.dirty) || (ctx.organizationForm == null ? null : (tmp_1_0 = ctx.organizationForm.get("organization_name")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationForm && (ctx.organizationForm == null ? null : (tmp_2_0 = ctx.organizationForm.get("email")) == null ? null : tmp_2_0.invalid) && ((ctx.organizationForm == null ? null : (tmp_2_0 = ctx.organizationForm.get("email")) == null ? null : tmp_2_0.dirty) || (ctx.organizationForm == null ? null : (tmp_2_0 = ctx.organizationForm.get("email")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationForm && (ctx.organizationForm == null ? null : (tmp_3_0 = ctx.organizationForm.get("point_of_contact_name")) == null ? null : tmp_3_0.invalid) && ((ctx.organizationForm == null ? null : (tmp_3_0 = ctx.organizationForm.get("point_of_contact_name")) == null ? null : tmp_3_0.dirty) || (ctx.organizationForm == null ? null : (tmp_3_0 = ctx.organizationForm.get("point_of_contact_name")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationForm && (ctx.organizationForm == null ? null : (tmp_4_0 = ctx.organizationForm.get("address_line1")) == null ? null : tmp_4_0.invalid) && ((ctx.organizationForm == null ? null : (tmp_4_0 = ctx.organizationForm.get("address_line1")) == null ? null : tmp_4_0.dirty) || (ctx.organizationForm == null ? null : (tmp_4_0 = ctx.organizationForm.get("address_line1")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.organizationForm && ctx.organizationForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateOrganizationComponent;
})();

/***/ }),

/***/ 1957:
/*!***********************************************************************************!*\
  !*** ./src/app/organization/delete-organization/delete-organization.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteOrganizationComponent": () => (/* binding */ DeleteOrganizationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/organization.service */ 4261);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteOrganizationComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Organization ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteOrganizationComponent = /*#__PURE__*/(() => {
  class DeleteOrganizationComponent {
    constructor(orgService, fb) {
      this.orgService = orgService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        orgId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteOrganization() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.orgId;
        this.orgService.deleteOrganizations(id).subscribe({
          next: response => {
            console.log('Organization deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting organization:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteOrganizationComponent_Factory(t) {
      return new (t || DeleteOrganizationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__.OrganizationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteOrganizationComponent,
      selectors: [["app-delete-organization"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "orgId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "orgId", "id", "orgId", "type", "number", "placeholder", "Enter Org ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteOrganizationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteOrganizationComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Organization ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteOrganizationComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete Org ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("orgId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("orgId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("orgId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteOrganizationComponent;
})();

/***/ }),

/***/ 6133:
/*!*****************************************************************************!*\
  !*** ./src/app/organization/get-organization/get-organization.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetOrganizationComponent": () => (/* binding */ GetOrganizationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/organization.service */ 4261);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);



function GetOrganizationComponent_div_5_li_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const organization_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"]("", organization_r4.organization_name, " , ", organization_r4.organization_id, "");
  }
}
function GetOrganizationComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, GetOrganizationComponent_div_5_li_2_Template, 2, 2, "li", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.organizations);
  }
}
function GetOrganizationComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0, " No organizations found.\n");
  }
}
let GetOrganizationComponent = /*#__PURE__*/(() => {
  class GetOrganizationComponent {
    constructor(orgService) {
      this.orgService = orgService;
      this.organizations = [];
    }
    ngOnInit() {
      //get all organizations
      this.orgService.getOrganizations().subscribe({
        next: data => {
          this.organizations = data;
          console.log('Organizations:', this.organizations);
        },
        error: error => {
          console.error('Error fetching organizations:', error);
        },
        complete: () => {
          console.log('Request to fetch Org completed');
        }
      });
    }
    static #_ = this.ɵfac = function GetOrganizationComponent_Factory(t) {
      return new (t || GetOrganizationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__.OrganizationService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetOrganizationComponent,
      selectors: [["app-get-organization"]],
      decls: 8,
      vars: 2,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-full"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [4, "ngIf", "ngIfElse"], ["noData", ""], [4, "ngFor", "ngForOf"]],
      template: function GetOrganizationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "ORGANIZATION NAME & ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, GetOrganizationComponent_div_5_Template, 3, 1, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GetOrganizationComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizations.length > 0)("ngIfElse", _r1);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf]
    });
  }
  return GetOrganizationComponent;
})();

/***/ }),

/***/ 3401:
/*!*************************************************************************************!*\
  !*** ./src/app/organization/organization-landing/organization-landing.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrganizationLandingComponent": () => (/* binding */ OrganizationLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let OrganizationLandingComponent = /*#__PURE__*/(() => {
  class OrganizationLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-organization');
    }
    onCreateOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-organization');
    }
    onDeleteOrganization() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-organization');
    }
    onUpdateOrganization() {
      this.router.navigateByUrl('/update-organization');
    }
    static #_ = this.ɵfac = function OrganizationLandingComponent_Factory(t) {
      return new (t || OrganizationLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: OrganizationLandingComponent,
      selectors: [["app-organization-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function OrganizationLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function OrganizationLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function OrganizationLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function OrganizationLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function OrganizationLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateOrganization();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Organization ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return OrganizationLandingComponent;
})();

/***/ }),

/***/ 7197:
/*!*****************************************************!*\
  !*** ./src/app/organization/organization.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrganizationModule": () => (/* binding */ OrganizationModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _organization_landing_organization_landing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./organization-landing/organization-landing.component */ 3401);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _create_organization_create_organization_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-organization/create-organization.component */ 1384);
/* harmony import */ var _delete_organization_delete_organization_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./delete-organization/delete-organization.component */ 1957);
/* harmony import */ var _get_organization_get_organization_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-organization/get-organization.component */ 6133);
/* harmony import */ var _update_organization_update_organization_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./update-organization/update-organization.component */ 9515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4650);








let OrganizationModule = /*#__PURE__*/(() => {
  class OrganizationModule {
    static #_ = this.ɵfac = function OrganizationModule_Factory(t) {
      return new (t || OrganizationModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: OrganizationModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule]
    });
  }
  return OrganizationModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](OrganizationModule, {
    declarations: [_organization_landing_organization_landing_component__WEBPACK_IMPORTED_MODULE_0__.OrganizationLandingComponent, _create_organization_create_organization_component__WEBPACK_IMPORTED_MODULE_1__.CreateOrganizationComponent, _delete_organization_delete_organization_component__WEBPACK_IMPORTED_MODULE_2__.DeleteOrganizationComponent, _get_organization_get_organization_component__WEBPACK_IMPORTED_MODULE_3__.GetOrganizationComponent, _update_organization_update_organization_component__WEBPACK_IMPORTED_MODULE_4__.UpdateOrganizationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule]
  });
})();

/***/ }),

/***/ 9515:
/*!***********************************************************************************!*\
  !*** ./src/app/organization/update-organization/update-organization.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateOrganizationComponent": () => (/* binding */ UpdateOrganizationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/organization.service */ 4261);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdateOrganizationComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organization Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateOrganizationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organization Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateOrganizationComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Email is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateOrganizationComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Contact Name is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateOrganizationComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Address is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateOrganizationComponent = /*#__PURE__*/(() => {
  class UpdateOrganizationComponent {
    constructor(orgService, fb) {
      this.orgService = orgService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.organizationUpdatedForm = this.fb.group({
        organization_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        organization_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.email]],
        point_of_contact_name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        address_line1: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log("Org Updated Form Value", this.organizationUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.orgService.updateOrganization(this.organizationUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.organizationUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated Org completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateOrganizationComponent_Factory(t) {
      return new (t || UpdateOrganizationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_organization_service__WEBPACK_IMPORTED_MODULE_0__.OrganizationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateOrganizationComponent,
      selectors: [["app-update-organization"]],
      decls: 39,
      vars: 7,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "organization_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_id", "id", "organization_id", "type", "text", "placeholder", "Enter Org Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "organization_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_name", "id", "organization_name", "type", "text", "placeholder", "Enter Org Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "email", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "email", "id", "email", "type", "email", "placeholder", "Enter Org Email", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "point_of_contact_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "point_of_contact_name", "id", "point_of_contact_name", "type", "text", "placeholder", "Enter Org Point of Contact Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "address_line1", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "address_line1", "id", "address_line1", "placeholder", "Enter Org Address", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdateOrganizationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE ORGANIZATION DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateOrganizationComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Organization Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateOrganizationComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Organization Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, UpdateOrganizationComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Organization Email");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](23, UpdateOrganizationComponent_div_23_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 4)(25, "label", 12)(26, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Organization Point of Contact Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](29, UpdateOrganizationComponent_div_29_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "div", 14)(31, "label", 15)(32, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](33, "Organization Address");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](34, "textarea", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](35, UpdateOrganizationComponent_div_35_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "div", 17)(37, "button", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](38, " Update Org ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_4_0;
          let tmp_5_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.organizationUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationUpdatedForm && (ctx.organizationUpdatedForm == null ? null : (tmp_1_0 = ctx.organizationUpdatedForm.get("organization_id")) == null ? null : tmp_1_0.invalid) && ((ctx.organizationUpdatedForm == null ? null : (tmp_1_0 = ctx.organizationUpdatedForm.get("organization_id")) == null ? null : tmp_1_0.dirty) || (ctx.organizationUpdatedForm == null ? null : (tmp_1_0 = ctx.organizationUpdatedForm.get("organization_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationUpdatedForm && (ctx.organizationUpdatedForm == null ? null : (tmp_2_0 = ctx.organizationUpdatedForm.get("organization_name")) == null ? null : tmp_2_0.invalid) && ((ctx.organizationUpdatedForm == null ? null : (tmp_2_0 = ctx.organizationUpdatedForm.get("organization_name")) == null ? null : tmp_2_0.dirty) || (ctx.organizationUpdatedForm == null ? null : (tmp_2_0 = ctx.organizationUpdatedForm.get("organization_name")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationUpdatedForm && (ctx.organizationUpdatedForm == null ? null : (tmp_3_0 = ctx.organizationUpdatedForm.get("email")) == null ? null : tmp_3_0.invalid) && ((ctx.organizationUpdatedForm == null ? null : (tmp_3_0 = ctx.organizationUpdatedForm.get("email")) == null ? null : tmp_3_0.dirty) || (ctx.organizationUpdatedForm == null ? null : (tmp_3_0 = ctx.organizationUpdatedForm.get("email")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationUpdatedForm && (ctx.organizationUpdatedForm == null ? null : (tmp_4_0 = ctx.organizationUpdatedForm.get("point_of_contact_name")) == null ? null : tmp_4_0.invalid) && ((ctx.organizationUpdatedForm == null ? null : (tmp_4_0 = ctx.organizationUpdatedForm.get("point_of_contact_name")) == null ? null : tmp_4_0.dirty) || (ctx.organizationUpdatedForm == null ? null : (tmp_4_0 = ctx.organizationUpdatedForm.get("point_of_contact_name")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.organizationUpdatedForm && (ctx.organizationUpdatedForm == null ? null : (tmp_5_0 = ctx.organizationUpdatedForm.get("address_line1")) == null ? null : tmp_5_0.invalid) && ((ctx.organizationUpdatedForm == null ? null : (tmp_5_0 = ctx.organizationUpdatedForm.get("address_line1")) == null ? null : tmp_5_0.dirty) || (ctx.organizationUpdatedForm == null ? null : (tmp_5_0 = ctx.organizationUpdatedForm.get("address_line1")) == null ? null : tmp_5_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.organizationUpdatedForm && ctx.organizationUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdateOrganizationComponent;
})();

/***/ }),

/***/ 9074:
/*!***************************************************************************!*\
  !*** ./src/app/qr-save-mock/qr-code-display/qr-code-display.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrCodeDisplayComponent": () => (/* binding */ QrCodeDisplayComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);




function QrCodeDisplayComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const qrCode_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", "http://localhost:3000/" + qrCode_r1.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](qrCode_r1.caption);
  }
}
let QrCodeDisplayComponent = /*#__PURE__*/(() => {
  class QrCodeDisplayComponent {
    constructor(router, http) {
      this.router = router;
      this.http = http;
      this.qrCodes = [];
    }
    ngOnInit() {
      this.loadQrCodes();
    }
    loadQrCodes() {
      this.http.get('http://localhost:3000/get-qr-codes').subscribe(response => {
        this.qrCodes = response;
      });
    }
    goToGenerateQR() {
      this.router.navigateByUrl('/qr-code-save');
    }
    static #_ = this.ɵfac = function QrCodeDisplayComponent_Factory(t) {
      return new (t || QrCodeDisplayComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QrCodeDisplayComponent,
      selectors: [["app-qr-code-display"]],
      decls: 6,
      vars: 1,
      consts: [[4, "ngFor", "ngForOf"], ["type", "button", 1, "px-4", "py-2", "bg-blue-600", "text-white", "rounded-md", "hover:bg-blue-700", 3, "click"], ["alt", "QR Code", 3, "src"]],
      template: function QrCodeDisplayComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "h2");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Saved QR Codes");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, QrCodeDisplayComponent_div_3_Template, 4, 2, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function QrCodeDisplayComponent_Template_button_click_4_listener() {
            return ctx.goToGenerateQR();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Generate QR Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.qrCodes);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf]
    });
  }
  return QrCodeDisplayComponent;
})();

/***/ }),

/***/ 584:
/*!*********************************************************************!*\
  !*** ./src/app/qr-save-mock/qr-code-save/qr-code-save.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QrCodeSaveComponent": () => (/* binding */ QrCodeSaveComponent)
/* harmony export */ });
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! html2canvas */ 4159);
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(html2canvas__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 529);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 7070);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 4006);







function QrCodeSaveComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "ngx-qrcode", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx_r0.qrData);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.caption);
  }
}
let QrCodeSaveComponent = /*#__PURE__*/(() => {
  class QrCodeSaveComponent {
    constructor(router, http) {
      this.router = router;
      this.http = http;
      this.instagramHandle = '';
      this.qrData = null;
      this.caption = '';
    }
    generateQrCode() {
      const instagramUrl = `https://www.instagram.com/${this.instagramHandle}/`;
      this.qrData = instagramUrl;
      setTimeout(() => this.captureQrCode(), 100); // Wait for QR code to render
    }

    captureQrCode() {
      const qrElement = document.getElementById('qrCodeWithCaption');
      if (qrElement) {
        html2canvas__WEBPACK_IMPORTED_MODULE_0___default()(qrElement).then(canvas => {
          canvas.toBlob(blob => {
            if (blob) {
              // Check if blob is not null
              const formData = new FormData();
              formData.append('image', blob, 'qr-code.png');
              formData.append('caption', this.caption);
              this.saveQrCode(formData);
            } else {
              console.error('Failed to create Blob from canvas');
            }
          }, 'image/png');
        });
      }
    }
    saveQrCode(formData) {
      this.http.post('http://localhost:3000/save-qr-code', formData).subscribe({
        next: response => {
          console.log('QR code saved successfully', response);
        },
        error: error => {
          console.error('Error saving QR code:', error);
        }
      });
    }
    goToDisplayQR() {
      this.router.navigateByUrl('/qr-code-display');
    }
    static #_ = this.ɵfac = function QrCodeSaveComponent_Factory(t) {
      return new (t || QrCodeSaveComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: QrCodeSaveComponent,
      selectors: [["app-qr-code-save"]],
      decls: 17,
      vars: 3,
      consts: [[1, "p-4"], [1, "text-2xl", "font-bold", "mb-4"], [1, "space-y-4", 3, "ngSubmit"], [1, "mb-4"], [1, "block", "text-gray-700"], ["type", "text", "name", "instagramHandle", "required", "", 1, "w-full", "px-4", "py-2", "border", "rounded-md", "focus:outline-none", "focus:ring-2", "focus:ring-blue-600", 3, "ngModel", "ngModelChange"], ["type", "text", "name", "caption", "required", "", 1, "w-full", "px-4", "py-2", "border", "rounded-md", "focus:outline-none", "focus:ring-2", "focus:ring-blue-600", 3, "ngModel", "ngModelChange"], ["type", "submit", 1, "px-4", "py-2", "bg-blue-600", "text-white", "rounded-md", "hover:bg-blue-700"], ["class", "mt-4", 4, "ngIf"], ["type", "button", 1, "px-4", "py-2", "mt-4", "bg-blue-600", "text-white", "rounded-md", "hover:bg-blue-700", 3, "click"], [1, "mt-4"], ["id", "qrCodeWithCaption", 1, "flex", "flex-col", "items-center"], [3, "value"], [1, "mt-2", "text-gray-700"]],
      template: function QrCodeSaveComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "h2", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Generate Follow QR Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "form", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function QrCodeSaveComponent_Template_form_ngSubmit_3_listener() {
            return ctx.generateQrCode();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 3)(5, "label", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, "Instagram Handle(Ex - i.am.sid17)");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "input", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function QrCodeSaveComponent_Template_input_ngModelChange_7_listener($event) {
            return ctx.instagramHandle = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 3)(9, "label", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Caption");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function QrCodeSaveComponent_Template_input_ngModelChange_11_listener($event) {
            return ctx.caption = $event;
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "Generate & Save QR Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, QrCodeSaveComponent_div_14_Template, 5, 2, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "button", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function QrCodeSaveComponent_Template_button_click_15_listener() {
            return ctx.goToDisplayQR();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Display Saved QR Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.instagramHandle);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.caption);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.qrData);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_5__.QrcodeComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgForm]
    });
  }
  return QrCodeSaveComponent;
})();

/***/ }),

/***/ 5027:
/*!****************************************************************!*\
  !*** ./src/app/quest/badge-landing/badge-landing.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BadgeLandingComponent": () => (/* binding */ BadgeLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let BadgeLandingComponent = /*#__PURE__*/(() => {
  class BadgeLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetBadge() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-badge');
    }
    onCreateBadge() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-badge');
    }
    static #_ = this.ɵfac = function BadgeLandingComponent_Factory(t) {
      return new (t || BadgeLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BadgeLandingComponent,
      selectors: [["app-badge-landing"]],
      decls: 9,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function BadgeLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BadgeLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetBadge();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Badge ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BadgeLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateBadge();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Badge ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return BadgeLandingComponent;
})();

/***/ }),

/***/ 3366:
/*!**************************************************************!*\
  !*** ./src/app/quest/create-badge/create-badge.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateBadgeComponent": () => (/* binding */ CreateBadgeComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_badge_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/badge.service */ 4052);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateBadgeComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Org Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateBadgeComponent = /*#__PURE__*/(() => {
  class CreateBadgeComponent {
    constructor(badgeService, fb) {
      this.badgeService = badgeService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.badgeForm = this.fb.group({
        badge_name: [''],
        badge_description: [''],
        small_image_color: [''],
        small_image_greyscale: [''],
        big_image: [''],
        org_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.piiform.valid) {
      event.preventDefault();
      console.log("Badge Form Value", this.badgeForm.value);
      //create pii call 
      //use subscribe with next and error object as per new standard
      this.badgeService.createBadge(this.badgeForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.badgeForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Link completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateBadgeComponent_Factory(t) {
      return new (t || CreateBadgeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_badge_service__WEBPACK_IMPORTED_MODULE_0__.BadgeService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateBadgeComponent,
      selectors: [["app-create-badge"]],
      decls: 40,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "badge_name", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "badge_name", "id", "badge_name", "type", "text", "placeholder", "Enter Badge Name", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "badge_description", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "badge_description", "id", "badge_description", "type", "text", "placeholder", "Enter badge description", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "small_image_color", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "small_image_color", "id", "small_image_color", "type", "text", "placeholder", "Enter small image color", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "small_image_greyscale", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "small_image_greyscale", "id", "small_image_greyscale", "type", "text", "placeholder", "Enter small image Greyscale", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "big_image", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "big_image", "id", "big_image", "type", "text", "placeholder", "Enter big image", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "org_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "org_id", "id", "org_id", "type", "text", "placeholder", "Enter org id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "BADGE DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateBadgeComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Badge Name");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 4)(12, "label", 7)(13, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Badge Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 4)(17, "label", 9)(18, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "Small Image Color");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](20, "input", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 4)(22, "label", 11)(23, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, "Small Image Greyscale");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](25, "input", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "div", 4)(27, "label", 13)(28, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](29, "Big Image");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](30, "input", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "div", 4)(32, "label", 15)(33, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, "Org Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](35, "input", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](36, CreateBadgeComponent_div_36_Template, 3, 0, "div", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div", 18)(38, "button", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39, " Create Badge ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.badgeForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](31);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.badgeForm && (ctx.badgeForm == null ? null : (tmp_1_0 = ctx.badgeForm.get("org_id")) == null ? null : tmp_1_0.invalid) && (((tmp_1_0 = ctx.badgeForm.get("org_id")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.badgeForm.get("org_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.badgeForm && ctx.badgeForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateBadgeComponent;
})();

/***/ }),

/***/ 641:
/*!**************************************************************!*\
  !*** ./src/app/quest/delete-badge/delete-badge.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteBadgeComponent": () => (/* binding */ DeleteBadgeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let DeleteBadgeComponent = /*#__PURE__*/(() => {
  class DeleteBadgeComponent {
    static #_ = this.ɵfac = function DeleteBadgeComponent_Factory(t) {
      return new (t || DeleteBadgeComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DeleteBadgeComponent,
      selectors: [["app-delete-badge"]],
      decls: 2,
      vars: 0,
      template: function DeleteBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "delete-badge works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return DeleteBadgeComponent;
})();

/***/ }),

/***/ 2207:
/*!********************************************************!*\
  !*** ./src/app/quest/get-badge/get-badge.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetBadgeComponent": () => (/* binding */ GetBadgeComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_badge_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/badge.service */ 4052);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function GetBadgeComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Badge Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function GetBadgeComponent_div_14_li_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const badge_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", badge_r3.badge_name, " ");
  }
}
function GetBadgeComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GetBadgeComponent_div_14_li_1_Template, 2, 1, "li", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.badges);
  }
}
let GetBadgeComponent = /*#__PURE__*/(() => {
  class GetBadgeComponent {
    constructor(badgeService, fb) {
      this.badgeService = badgeService;
      this.fb = fb;
      this.badges = [];
      this.getForm = this.fb.group({
        badge_id: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    getBadge() {
      //get all LInks
      if (this.getForm.valid) {
        const id = this.getForm.value.badge_id;
        this.badgeService.getBadge(id).subscribe({
          next: response => {
            this.badges = response;
            console.log('badge get successfully:', response);
            this.getForm.reset();
          },
          error: error => {
            console.error('Error getting link:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function GetBadgeComponent_Factory(t) {
      return new (t || GetBadgeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_badge_service__WEBPACK_IMPORTED_MODULE_0__.BadgeService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetBadgeComponent,
      selectors: [["app-get-badge"]],
      decls: 15,
      vars: 4,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "badge_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "badge_id", "id", "badge_id", "type", "number", "placeholder", "Enter Badge ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-cyan-400", "hover:bg-cyan-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"], [4, "ngFor", "ngForOf"]],
      template: function GetBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Get Badge ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function GetBadgeComponent_Template_form_ngSubmit_5_listener() {
            return ctx.getBadge();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Badge ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, GetBadgeComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Get Badge ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, GetBadgeComponent_div_14_Template, 2, 1, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.getForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("badge_id")) == null ? null : tmp_1_0.invalid) && ((ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("badge_id")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.getForm.get("badge_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.getForm && ctx.getForm.invalid);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.badges.length > 0);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return GetBadgeComponent;
})();

/***/ }),

/***/ 136:
/*!**************************************************************************!*\
  !*** ./src/app/quest/quest-badges-panel/quest-badges-panel.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestBadgesPanelComponent": () => (/* binding */ QuestBadgesPanelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let QuestBadgesPanelComponent = /*#__PURE__*/(() => {
  class QuestBadgesPanelComponent {
    static #_ = this.ɵfac = function QuestBadgesPanelComponent_Factory(t) {
      return new (t || QuestBadgesPanelComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QuestBadgesPanelComponent,
      selectors: [["app-quest-badges-panel"]],
      decls: 32,
      vars: 0,
      consts: [[1, "px-8"], ["left", ""], [1, "uppercase", "text-lg", "mt-12", "font-semibold"], [1, "text-sm", "mt-3"], ["right", ""], [1, "flex", "justify-between", "mt-2"], [1, "bg-gray-500", "w-fit", "rounded-full"], ["src", "/assets/images/badges/exploreSm.png", 1, "p-4", "w-16"], [1, "my-auto", "w-4", "border-2", "border-gray-300"], [1, "bg-gray-200", "w-fit", "rounded-full"], ["src", "/assets/images/badges/meetSmInactive.png", 1, "p-4", "w-16"], [1, "w-full", "bg-gray-200", "rounded-full", "dark:bg-gray-700"], [1, "bg-purple-600", "text-xs", "font-medium", "text-blue-100", "text-center", "p-0.5", "leading-none", "rounded-full", 2, "width", "40%"], [1, "text-right", "text-sm", "mt-4"], ["href", "#", "title", "Link to see Stats"]],
      template: function QuestBadgesPanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div")(2, "div", 1)(3, "p", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Quest 1");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Challenge 1 Details");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 4)(8, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "40%");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 5)(11, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "img", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "img", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div")(26, "div", 11)(27, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, " 40%");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 13)(30, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, "Scores & More >");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        }
      }
    });
  }
  return QuestBadgesPanelComponent;
})();

/***/ }),

/***/ 5301:
/*!****************************************************************!*\
  !*** ./src/app/quest/quest-landing/quest-landing.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestLandingComponent": () => (/* binding */ QuestLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let QuestLandingComponent = /*#__PURE__*/(() => {
  class QuestLandingComponent {
    static #_ = this.ɵfac = function QuestLandingComponent_Factory(t) {
      return new (t || QuestLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QuestLandingComponent,
      selectors: [["app-quest-landing"]],
      decls: 2,
      vars: 0,
      template: function QuestLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "quest-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return QuestLandingComponent;
})();

/***/ }),

/***/ 9098:
/*!**************************************************************************!*\
  !*** ./src/app/quest/quest-rewards-page/quest-rewards-page.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestRewardsPageComponent": () => (/* binding */ QuestRewardsPageComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _quest_badges_panel_quest_badges_panel_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../quest-badges-panel/quest-badges-panel.component */ 136);
/* harmony import */ var _quest_rewards_panel_quest_rewards_panel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../quest-rewards-panel/quest-rewards-panel.component */ 8640);



let QuestRewardsPageComponent = /*#__PURE__*/(() => {
  class QuestRewardsPageComponent {
    static #_ = this.ɵfac = function QuestRewardsPageComponent_Factory(t) {
      return new (t || QuestRewardsPageComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: QuestRewardsPageComponent,
      selectors: [["app-quest-rewards-page"]],
      decls: 4,
      vars: 0,
      template: function QuestRewardsPageComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "quest-rewards-page works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "app-quest-badges-panel")(3, "app-quest-rewards-panel");
        }
      },
      dependencies: [_quest_badges_panel_quest_badges_panel_component__WEBPACK_IMPORTED_MODULE_0__.QuestBadgesPanelComponent, _quest_rewards_panel_quest_rewards_panel_component__WEBPACK_IMPORTED_MODULE_1__.QuestRewardsPanelComponent]
    });
  }
  return QuestRewardsPageComponent;
})();

/***/ }),

/***/ 8640:
/*!****************************************************************************!*\
  !*** ./src/app/quest/quest-rewards-panel/quest-rewards-panel.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestRewardsPanelComponent": () => (/* binding */ QuestRewardsPanelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let QuestRewardsPanelComponent = /*#__PURE__*/(() => {
  class QuestRewardsPanelComponent {
    static #_ = this.ɵfac = function QuestRewardsPanelComponent_Factory(t) {
      return new (t || QuestRewardsPanelComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QuestRewardsPanelComponent,
      selectors: [["app-quest-rewards-panel"]],
      decls: 36,
      vars: 0,
      consts: [[1, "text-center", "uppercase", "text-3xl", "font-medium", "mt-12"], [1, "text-center", "uppercase", "mt-1", "text-lg", "font-semibold"], [1, "flex", "justify-between", "px-8", "mt-8"], [1, "w-8/12"], [1, "text-center", "text-sm", "mb-2", "text-gray-900", "font-light"], ["type", "text", "placeholder", "", "name", "text", 1, "w-full", "rounded", "border-0", "py-2", "text-gray-900", "shadow-sm", "ring-1", "ring-inset", "ring-gray-900", "placeholder:text-gray-400", "focus:ring-2", "focus:ring-inset", "focus:ring-indigo-600", "sm:text-sm", "sm:leading-6"], [1, "text-xs", "text-center", "font-light", "mt-2"], [1, "text-sm", "text-center", "font-light", "mb-2"], [1, "h-16", "w-16", "ring-1", "ring-black", "rounded"], ["src", "../assets/images/onboarding-images/qr-icon.png", "alt", "qr-code"], [1, "uppercase", "font-semibold", "mt-12", "text-lg", "text-center"], [1, "grid", "grid-cols-2", "text-center", "px-8", "text-sm"], [1, ""], [1, "px-8", "mt-8"], ["href", "#", "title", "Redeem Rewards"], [1, "w-full", "ring-4", "text-white", "bg-blue-900", "ring-gray-900", "truncate", "shadow-md", "text-center", "py-3", "mt-0", "mb-0", "rounded-full", "mx-auto"]],
      template: function QuestRewardsPanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h2", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Rewards");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "claim your rewards:");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2)(5, "div", 3)(6, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Enter Redemption Code");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "input", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Having trouble with your code? Contact Us. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div")(12, "p", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Or Scan ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, " previously claimed rewards\n");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 11)(19, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "* Reward 1 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "* Reward 2 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "* Reward 3 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "* Reward 4 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "* Reward 5 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "* Reward 6 | Date");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 13)(32, "p")(33, "a", 14)(34, "button", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Redeem Rewards ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        }
      }
    });
  }
  return QuestRewardsPanelComponent;
})();

/***/ }),

/***/ 3014:
/*!***************************************!*\
  !*** ./src/app/quest/quest.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestModule": () => (/* binding */ QuestModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _quest_badges_panel_quest_badges_panel_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./quest-badges-panel/quest-badges-panel.component */ 136);
/* harmony import */ var _quest_rewards_page_quest_rewards_page_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./quest-rewards-page/quest-rewards-page.component */ 9098);
/* harmony import */ var _quest_rewards_panel_quest_rewards_panel_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./quest-rewards-panel/quest-rewards-panel.component */ 8640);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.module */ 4466);
/* harmony import */ var _quest_landing_quest_landing_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./quest-landing/quest-landing.component */ 5301);
/* harmony import */ var _get_badge_get_badge_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./get-badge/get-badge.component */ 2207);
/* harmony import */ var _create_badge_create_badge_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-badge/create-badge.component */ 3366);
/* harmony import */ var _delete_badge_delete_badge_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./delete-badge/delete-badge.component */ 641);
/* harmony import */ var _update_badge_update_badge_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./update-badge/update-badge.component */ 925);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4650);












let QuestModule = /*#__PURE__*/(() => {
  class QuestModule {
    static #_ = this.ɵfac = function QuestModule_Factory(t) {
      return new (t || QuestModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
      type: QuestModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule]
    });
  }
  return QuestModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](QuestModule, {
    declarations: [_quest_badges_panel_quest_badges_panel_component__WEBPACK_IMPORTED_MODULE_0__.QuestBadgesPanelComponent, _quest_rewards_page_quest_rewards_page_component__WEBPACK_IMPORTED_MODULE_1__.QuestRewardsPageComponent, _quest_rewards_panel_quest_rewards_panel_component__WEBPACK_IMPORTED_MODULE_2__.QuestRewardsPanelComponent, _quest_landing_quest_landing_component__WEBPACK_IMPORTED_MODULE_4__.QuestLandingComponent, _get_badge_get_badge_component__WEBPACK_IMPORTED_MODULE_5__.GetBadgeComponent, _create_badge_create_badge_component__WEBPACK_IMPORTED_MODULE_6__.CreateBadgeComponent, _delete_badge_delete_badge_component__WEBPACK_IMPORTED_MODULE_7__.DeleteBadgeComponent, _update_badge_update_badge_component__WEBPACK_IMPORTED_MODULE_8__.UpdateBadgeComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule],
    exports: [_quest_badges_panel_quest_badges_panel_component__WEBPACK_IMPORTED_MODULE_0__.QuestBadgesPanelComponent, _quest_rewards_page_quest_rewards_page_component__WEBPACK_IMPORTED_MODULE_1__.QuestRewardsPageComponent, _quest_rewards_panel_quest_rewards_panel_component__WEBPACK_IMPORTED_MODULE_2__.QuestRewardsPanelComponent]
  });
})();

/***/ }),

/***/ 925:
/*!**************************************************************!*\
  !*** ./src/app/quest/update-badge/update-badge.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateBadgeComponent": () => (/* binding */ UpdateBadgeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UpdateBadgeComponent = /*#__PURE__*/(() => {
  class UpdateBadgeComponent {
    static #_ = this.ɵfac = function UpdateBadgeComponent_Factory(t) {
      return new (t || UpdateBadgeComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateBadgeComponent,
      selectors: [["app-update-badge"]],
      decls: 2,
      vars: 0,
      template: function UpdateBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "update-badge works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return UpdateBadgeComponent;
})();

/***/ }),

/***/ 3783:
/*!***************************************************************************!*\
  !*** ./src/app/shared/journey/create-journey/create-journey.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateJourneyComponent": () => (/* binding */ CreateJourneyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let CreateJourneyComponent = /*#__PURE__*/(() => {
  class CreateJourneyComponent {
    static #_ = this.ɵfac = function CreateJourneyComponent_Factory(t) {
      return new (t || CreateJourneyComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: CreateJourneyComponent,
      selectors: [["app-create-journey"]],
      decls: 2,
      vars: 0,
      template: function CreateJourneyComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-journey works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return CreateJourneyComponent;
})();

/***/ }),

/***/ 4251:
/*!***************************************************************************!*\
  !*** ./src/app/shared/journey/delete-journey/delete-journey.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteJourneyComponent": () => (/* binding */ DeleteJourneyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let DeleteJourneyComponent = /*#__PURE__*/(() => {
  class DeleteJourneyComponent {
    static #_ = this.ɵfac = function DeleteJourneyComponent_Factory(t) {
      return new (t || DeleteJourneyComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DeleteJourneyComponent,
      selectors: [["app-delete-journey"]],
      decls: 2,
      vars: 0,
      template: function DeleteJourneyComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "delete-journey works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return DeleteJourneyComponent;
})();

/***/ }),

/***/ 4647:
/*!*********************************************************************!*\
  !*** ./src/app/shared/journey/get-journey/get-journey.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetJourneyComponent": () => (/* binding */ GetJourneyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let GetJourneyComponent = /*#__PURE__*/(() => {
  class GetJourneyComponent {
    static #_ = this.ɵfac = function GetJourneyComponent_Factory(t) {
      return new (t || GetJourneyComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: GetJourneyComponent,
      selectors: [["app-get-journey"]],
      decls: 2,
      vars: 0,
      template: function GetJourneyComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "get-journey works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return GetJourneyComponent;
})();

/***/ }),

/***/ 6671:
/*!*****************************************************************************!*\
  !*** ./src/app/shared/journey/journey-landing/journey-landing.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JourneyLandingComponent": () => (/* binding */ JourneyLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let JourneyLandingComponent = /*#__PURE__*/(() => {
  class JourneyLandingComponent {
    static #_ = this.ɵfac = function JourneyLandingComponent_Factory(t) {
      return new (t || JourneyLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: JourneyLandingComponent,
      selectors: [["app-journey-landing"]],
      decls: 2,
      vars: 0,
      template: function JourneyLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "journey-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return JourneyLandingComponent;
})();

/***/ }),

/***/ 8455:
/*!***************************************************************************!*\
  !*** ./src/app/shared/journey/update-journey/update-journey.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateJourneyComponent": () => (/* binding */ UpdateJourneyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UpdateJourneyComponent = /*#__PURE__*/(() => {
  class UpdateJourneyComponent {
    static #_ = this.ɵfac = function UpdateJourneyComponent_Factory(t) {
      return new (t || UpdateJourneyComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateJourneyComponent,
      selectors: [["app-update-journey"]],
      decls: 2,
      vars: 0,
      template: function UpdateJourneyComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "update-journey works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return UpdateJourneyComponent;
})();

/***/ }),

/***/ 1070:
/*!**********************************************************!*\
  !*** ./src/app/shared/layout/footer/footer.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterComponent": () => (/* binding */ FooterComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let FooterComponent = /*#__PURE__*/(() => {
  class FooterComponent {
    static #_ = this.ɵfac = function FooterComponent_Factory(t) {
      return new (t || FooterComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: FooterComponent,
      selectors: [["app-footer"]],
      decls: 15,
      vars: 0,
      consts: [["id", "footer", 1, "bg-blue-900", "text-white"], [1, "mx-auto", "max-w-7xl", "overflow-hidden", "py-6", "lg:px-8"], ["aria-label", "Footer", 1, "-mb-6", "columns-1", "text-center", "grid", "grid-cols-4"], [1, "pb-6"], ["title", "Home page", "href", "#", 1, ""], ["alt", "Home icon", "src", "../assets/icon/home-icon.png", "alt", "home icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Events page", "href", "#", 1, ""], ["alt", "Events map icon", "src", "../assets/icon/events-icon.png", "alt", "events icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Your profiles page", "href", "#", 1, ""], ["alt", "Profile id icon", "src", "../assets/icon/biotool.png", "alt", "biotool icon", 1, "w-8", "h-auto", "mx-auto"], ["title", "Connections to freinds page", "href", "#", 1, ""], ["alt", "Connections comment chat icon", "src", "../assets/icon/connections-icon.png", "alt", "connections icon", 1, "w-8", "h-auto", "mx-auto"]],
      template: function FooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "footer", 0)(1, "div", 1)(2, "nav", 2)(3, "div", 3)(4, "a", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 3)(7, "a", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 3)(10, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "img", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 3)(13, "a", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "img", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
        }
      }
    });
  }
  return FooterComponent;
})();

/***/ }),

/***/ 4162:
/*!**********************************************************!*\
  !*** ./src/app/shared/layout/header/header.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let HeaderComponent = /*#__PURE__*/(() => {
  class HeaderComponent {
    static #_ = this.ɵfac = function HeaderComponent_Factory(t) {
      return new (t || HeaderComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: HeaderComponent,
      selectors: [["app-header"]],
      decls: 18,
      vars: 0,
      consts: [[2, "text-align", "right", "background-color", "#6495ED"], ["href", "guest"], ["href", "crud"], ["href", "gray"], ["href", "blue"], ["href", "red"], ["href", "purple"]],
      template: function HeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p", 0)(1, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "guest");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " \u00A0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "a", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "crud");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " \u00A0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "a", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "gray");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " \u00A0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "a", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "blue");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " \u00A0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "a", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "red");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, " \u00A0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "a", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "purple");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
      }
    });
  }
  return HeaderComponent;
})();

/***/ }),

/***/ 5768:
/*!******************************************************************!*\
  !*** ./src/app/shared/layout/page-error/page-error.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageErrorComponent": () => (/* binding */ PageErrorComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let PageErrorComponent = /*#__PURE__*/(() => {
  class PageErrorComponent {
    static #_ = this.ɵfac = function PageErrorComponent_Factory(t) {
      return new (t || PageErrorComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PageErrorComponent,
      selectors: [["app-page-error"]],
      decls: 2,
      vars: 0,
      template: function PageErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "page-error works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return PageErrorComponent;
})();

/***/ }),

/***/ 742:
/*!**************************************************************************!*\
  !*** ./src/app/shared/layout/page-not-found/page-not-found.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageNotFoundComponent": () => (/* binding */ PageNotFoundComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let PageNotFoundComponent = /*#__PURE__*/(() => {
  class PageNotFoundComponent {
    static #_ = this.ɵfac = function PageNotFoundComponent_Factory(t) {
      return new (t || PageNotFoundComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PageNotFoundComponent,
      selectors: [["app-page-not-found"]],
      decls: 2,
      vars: 0,
      template: function PageNotFoundComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "page-not-found works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return PageNotFoundComponent;
})();

/***/ }),

/***/ 5217:
/*!*********************************************************************!*\
  !*** ./src/app/shared/links/create-links/create-links.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateLinksComponent": () => (/* binding */ CreateLinksComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/links.service */ 7363);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 9549);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/select */ 4385);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/core */ 7873);








function CreateLinksComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateLinksComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Link type is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateLinksComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Link active is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateLinksComponent_mat_option_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const socialMediaType_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", socialMediaType_r6.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", socialMediaType_r6.viewValue, " ");
  }
}
function CreateLinksComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Url Label is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function CreateLinksComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Url link is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateLinksComponent = /*#__PURE__*/(() => {
  class CreateLinksComponent {
    constructor(linkService, fb) {
      this.linkService = linkService;
      this.fb = fb;
      this.socialMediaTypes = [{
        value: 'Facebook',
        viewValue: 'Facebook'
      }, {
        value: 'Whatsapp',
        viewValue: 'Whatsapp'
      }, {
        value: 'Youtube',
        viewValue: 'Youtube'
      }, {
        value: 'Instagram',
        viewValue: 'Instagram'
      }, {
        value: 'TikTok',
        viewValue: 'Tiktok'
      }, {
        value: 'Telegram',
        viewValue: 'Telegram'
      }, {
        value: 'WeChat',
        viewValue: 'WeChat'
      }, {
        value: 'Snapchat',
        viewValue: 'Snapchat'
      }, {
        value: 'Twitter X',
        viewValue: 'Twitter X'
      }, {
        value: 'Pinterest',
        viewValue: 'Pinterest'
      }, {
        value: 'Reddit',
        viewValue: 'Reddit'
      }, {
        value: 'LinkedIn',
        viewValue: 'LinkedIn'
      }, {
        value: 'Quora',
        viewValue: 'Quora'
      }, {
        value: 'Discord',
        viewValue: 'Discord'
      }, {
        value: 'Twitch',
        viewValue: 'Twitch'
      }, {
        value: 'Tumblr',
        viewValue: 'Tumblr'
      }, {
        value: 'Mastodon',
        viewValue: 'Mastodon'
      }, {
        value: 'Medium',
        viewValue: 'Medium'
      }, {
        value: 'Flickr',
        viewValue: 'Flickr'
      }, {
        value: 'Goodreads',
        viewValue: 'Goodreads'
      }, {
        value: 'Myspace',
        viewValue: 'Myspace'
      }, {
        value: 'Classmates',
        viewValue: 'Classmates'
      }, {
        value: 'WeChat',
        viewValue: 'WeChat'
      }, {
        value: 'Kuaishou',
        viewValue: 'Kuaishou'
      }, {
        value: 'Sina Weibo',
        viewValue: 'Sina Weibo'
      }, {
        value: 'QQ ~??',
        viewValue: 'QQ ~??'
      }, {
        value: 'Meetup',
        viewValue: 'Meetup'
      }];
      this.selectedValue = "";
      //basic validators need to put check in UI
      this.linkForm = this.fb.group({
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        link_type: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        link_active: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        url_label: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        url_link: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onDropdownChange($event) {
      console.log("Changes Detected");
      this.selectedValue = $event.value;
      this.linkForm.get('url_label')?.setValue(this.selectedValue);
      console.log(this.selectedValue + " dropdown");
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.piiform.valid) {
      event.preventDefault();
      console.log("Link Form Value", this.linkForm.value);
      //create pii call 
      //use subscribe with next and error object as per new standard
      this.linkService.createLink(this.linkForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.linkForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Link completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateLinksComponent_Factory(t) {
      return new (t || CreateLinksComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__.LinksService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateLinksComponent,
      selectors: [["app-create-links"]],
      decls: 43,
      vars: 8,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "text", "placeholder", "Enter User Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "link_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "link_type", "id", "link_type", "type", "text", "placeholder", "Enter link type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "link_active", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "link_active", "id", "link_active", "type", "text", "placeholder", "Enter link active", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "url_label", 1, "block", "text-gray-700", "text-sm", "mb-2"], [3, "selectionChange"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "url_link", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "url_link", "id", "url_link", "type", "text", "placeholder", "Enter url link", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"], [3, "value"]],
      template: function CreateLinksComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "LINK DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateLinksComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, CreateLinksComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Link Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, CreateLinksComponent_div_17_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 4)(19, "label", 10)(20, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Link Active");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](22, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](23, CreateLinksComponent_div_23_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 4)(25, "label", 12)(26, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Url Label");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "mat-form-field")(29, "mat-label");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Social Media Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "mat-select", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("selectionChange", function CreateLinksComponent_Template_mat_select_selectionChange_31_listener($event) {
            return ctx.onDropdownChange($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](32, CreateLinksComponent_mat_option_32_Template, 2, 2, "mat-option", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](33, CreateLinksComponent_div_33_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "div", 4)(35, "label", 15)(36, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](37, "Url Link");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](38, "input", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](39, CreateLinksComponent_div_39_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](40, "div", 17)(41, "button", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](42, " Create Link ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_5_0;
          let tmp_6_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.linkForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_1_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_1_0.invalid) && ((ctx.linkForm == null ? null : (tmp_1_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_2_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_2_0.invalid) && ((ctx.linkForm == null ? null : (tmp_2_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_2_0.dirty) || ((tmp_2_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_3_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_3_0.invalid) && ((ctx.linkForm == null ? null : (tmp_3_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_3_0.dirty) || ((tmp_3_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.socialMediaTypes);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_5_0 = ctx.linkForm.get("url_label")) == null ? null : tmp_5_0.invalid) && ((ctx.linkForm == null ? null : (tmp_5_0 = ctx.linkForm.get("url_label")) == null ? null : tmp_5_0.dirty) || ((tmp_5_0 = ctx.linkForm.get("url_label")) == null ? null : tmp_5_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.invalid) && ((ctx.linkForm == null ? null : (tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.dirty) || ((tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.linkForm && ctx.linkForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_5__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_6__.MatOption]
    });
  }
  return CreateLinksComponent;
})();

/***/ }),

/***/ 3976:
/*!*********************************************************************!*\
  !*** ./src/app/shared/links/delete-links/delete-links.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteLinksComponent": () => (/* binding */ DeleteLinksComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/links.service */ 7363);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteLinksComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Key Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteLinksComponent = /*#__PURE__*/(() => {
  class DeleteLinksComponent {
    constructor(linkService, fb) {
      this.linkService = linkService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        key_id: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteLink() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.key_id;
        this.linkService.deleteLink(id).subscribe({
          next: response => {
            console.log('Link deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting links:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteLinksComponent_Factory(t) {
      return new (t || DeleteLinksComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__.LinksService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteLinksComponent,
      selectors: [["app-delete-links"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "key_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "key_id", "id", "key_id", "type", "number", "placeholder", "Enter Key ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteLinksComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Link ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteLinksComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Key Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteLinksComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete User Link ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("key_id")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("key_id")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("key_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteLinksComponent;
})();

/***/ }),

/***/ 3576:
/*!***************************************************************!*\
  !*** ./src/app/shared/links/get-links/get-links.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetLinksComponent": () => (/* binding */ GetLinksComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/links.service */ 7363);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function GetLinksComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function GetLinksComponent_div_14_li_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const link_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"]("", link_r3.link_type, " , ", link_r3.url_link, "");
  }
}
function GetLinksComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GetLinksComponent_div_14_li_1_Template, 2, 2, "li", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.links);
  }
}
let GetLinksComponent = /*#__PURE__*/(() => {
  class GetLinksComponent {
    constructor(linkService, fb) {
      this.linkService = linkService;
      this.fb = fb;
      this.links = [];
      this.getForm = this.fb.group({
        userId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    getLink() {
      //get all LInks
      if (this.getForm.valid) {
        const id = this.getForm.value.userId;
        this.linkService.getLink(id).subscribe({
          next: response => {
            this.links = response;
            console.log('link get successfully:', response);
            this.getForm.reset();
          },
          error: error => {
            console.error('Error getting link:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function GetLinksComponent_Factory(t) {
      return new (t || GetLinksComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__.LinksService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetLinksComponent,
      selectors: [["app-get-links"]],
      decls: 15,
      vars: 4,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "userId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "userId", "id", "userId", "type", "number", "placeholder", "Enter User ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-cyan-400", "hover:bg-cyan-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"], [4, "ngFor", "ngForOf"]],
      template: function GetLinksComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Get Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function GetLinksComponent_Template_form_ngSubmit_5_listener() {
            return ctx.getLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, GetLinksComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Get User Link ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, GetLinksComponent_div_14_Template, 2, 1, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.getForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.invalid) && ((ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.getForm && ctx.getForm.invalid);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.links.length > 0);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return GetLinksComponent;
})();

/***/ }),

/***/ 624:
/*!***********************************************************************!*\
  !*** ./src/app/shared/links/links-landing/links-landing.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LinksLandingComponent": () => (/* binding */ LinksLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let LinksLandingComponent = /*#__PURE__*/(() => {
  class LinksLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetLink() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-link');
    }
    onCreateLink() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-link');
    }
    onDeleteLink() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-link');
    }
    onUpdateLink() {
      this.router.navigateByUrl('/update-link');
    }
    static #_ = this.ɵfac = function LinksLandingComponent_Factory(t) {
      return new (t || LinksLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: LinksLandingComponent,
      selectors: [["app-links-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function LinksLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LinksLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LinksLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LinksLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LinksLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateLink();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Links ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return LinksLandingComponent;
})();

/***/ }),

/***/ 3849:
/*!*********************************************************************!*\
  !*** ./src/app/shared/links/update-links/update-links.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateLinksComponent": () => (/* binding */ UpdateLinksComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/links.service */ 7363);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 9549);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/select */ 4385);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/core */ 7873);








function UpdateLinksComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Key Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateLinksComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateLinksComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Link type is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateLinksComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Link Active is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateLinksComponent_mat_option_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const socialMediaType_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", socialMediaType_r6.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", socialMediaType_r6.viewValue, " ");
  }
}
function UpdateLinksComponent_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Url link is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateLinksComponent = /*#__PURE__*/(() => {
  class UpdateLinksComponent {
    constructor(linkService, fb) {
      this.linkService = linkService;
      this.fb = fb;
      this.socialMediaTypes = [{
        value: 'Facebook',
        viewValue: 'Facebook'
      }, {
        value: 'Whatsapp',
        viewValue: 'Whatsapp'
      }, {
        value: 'Youtube',
        viewValue: 'Youtube'
      }, {
        value: 'Instagram',
        viewValue: 'Instagram'
      }, {
        value: 'TikTok',
        viewValue: 'Tiktok'
      }, {
        value: 'Telegram',
        viewValue: 'Telegram'
      }, {
        value: 'WeChat',
        viewValue: 'WeChat'
      }, {
        value: 'Snapchat',
        viewValue: 'Snapchat'
      }, {
        value: 'Twitter X',
        viewValue: 'Twitter X'
      }, {
        value: 'Pinterest',
        viewValue: 'Pinterest'
      }, {
        value: 'Reddit',
        viewValue: 'Reddit'
      }, {
        value: 'LinkedIn',
        viewValue: 'LinkedIn'
      }, {
        value: 'Quora',
        viewValue: 'Quora'
      }, {
        value: 'Discord',
        viewValue: 'Discord'
      }, {
        value: 'Twitch',
        viewValue: 'Twitch'
      }, {
        value: 'Tumblr',
        viewValue: 'Tumblr'
      }, {
        value: 'Mastodon',
        viewValue: 'Mastodon'
      }, {
        value: 'Medium',
        viewValue: 'Medium'
      }, {
        value: 'Flickr',
        viewValue: 'Flickr'
      }, {
        value: 'Goodreads',
        viewValue: 'Goodreads'
      }, {
        value: 'Myspace',
        viewValue: 'Myspace'
      }, {
        value: 'Classmates',
        viewValue: 'Classmates'
      }, {
        value: 'WeChat',
        viewValue: 'WeChat'
      }, {
        value: 'Kuaishou',
        viewValue: 'Kuaishou'
      }, {
        value: 'Sina Weibo',
        viewValue: 'Sina Weibo'
      }, {
        value: 'QQ ~??',
        viewValue: 'QQ ~??'
      }, {
        value: 'Meetup',
        viewValue: 'Meetup'
      }];
      this.selectedValue = "";
      //basic validators need to put check in UI
      this.linkForm = this.fb.group({
        key_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        link_type: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        link_active: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        url_label: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        url_link: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onDropdownChange($event) {
      console.log("Changes Detected");
      this.selectedValue = $event.value;
      this.linkForm.get('url_label')?.setValue(this.selectedValue);
      console.log(this.selectedValue + " dropdown");
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.linkform.valid) {
      event.preventDefault();
      console.log("Link Form Value", this.linkForm.value);
      //create link call 
      //use subscribe with next and error object as per new standard
      this.linkService.updateLink(this.linkForm.value).subscribe({
        next: response => {
          console.log('Form upated successfully:', response);
          this.linkForm.reset();
        },
        error: error => {
          console.error('Error updating form:', error);
        },
        complete: () => {
          console.log('Update link completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateLinksComponent_Factory(t) {
      return new (t || UpdateLinksComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_links_service__WEBPACK_IMPORTED_MODULE_0__.LinksService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateLinksComponent,
      selectors: [["app-update-links"]],
      decls: 47,
      vars: 8,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "key_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "key_id", "id", "key_id", "type", "number", "placeholder", "Enter Key ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "text", "placeholder", "Enter User Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "link_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "link_type", "id", "link_type", "type", "text", "placeholder", "Enter link type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "link_active", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "link_active", "id", "link_active", "type", "text", "placeholder", "Enter link active", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "url_label", 1, "block", "text-gray-700", "text-sm", "mb-2"], [3, "selectionChange"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "url_link", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "url_link", "id", "url_link", "type", "text", "placeholder", "Enter url link", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"], [3, "value"]],
      template: function UpdateLinksComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE LINK DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateLinksComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Key Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateLinksComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "label", 8)(13, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "User Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](16, UpdateLinksComponent_div_16_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Link Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](22, UpdateLinksComponent_div_22_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "div", 4)(24, "label", 12)(25, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26, "Link Active");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](27, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](28, UpdateLinksComponent_div_28_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "div", 4)(30, "label", 14)(31, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, "Url Label");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "mat-form-field")(34, "mat-label");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "Social Media Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "mat-select", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("selectionChange", function UpdateLinksComponent_Template_mat_select_selectionChange_36_listener($event) {
            return ctx.onDropdownChange($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](37, UpdateLinksComponent_mat_option_37_Template, 2, 2, "mat-option", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "div", 4)(39, "label", 17)(40, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](41, "Url Link");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](42, "input", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](43, UpdateLinksComponent_div_43_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](44, "div", 19)(45, "button", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](46, " Update Link ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          let tmp_3_0;
          let tmp_4_0;
          let tmp_6_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.linkForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.linkForm == null ? null : (tmp_1_0 = ctx.linkForm.get("key_id")) == null ? null : tmp_1_0.invalid) && ((ctx.linkForm == null ? null : (tmp_1_0 = ctx.linkForm.get("key_id")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.linkForm.get("key_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_2_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_2_0.invalid) && ((ctx.linkForm == null ? null : (tmp_2_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_2_0.dirty) || ((tmp_2_0 = ctx.linkForm.get("user_id")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_3_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_3_0.invalid) && ((ctx.linkForm == null ? null : (tmp_3_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_3_0.dirty) || ((tmp_3_0 = ctx.linkForm.get("link_type")) == null ? null : tmp_3_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_4_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_4_0.invalid) && ((ctx.linkForm == null ? null : (tmp_4_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_4_0.dirty) || ((tmp_4_0 = ctx.linkForm.get("link_active")) == null ? null : tmp_4_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.socialMediaTypes);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.linkForm && (ctx.linkForm == null ? null : (tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.invalid) && ((ctx.linkForm == null ? null : (tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.dirty) || ((tmp_6_0 = ctx.linkForm.get("url_link")) == null ? null : tmp_6_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.linkForm && ctx.linkForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_5__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_6__.MatOption]
    });
  }
  return UpdateLinksComponent;
})();

/***/ }),

/***/ 2950:
/*!***************************************************************!*\
  !*** ./src/app/shared/pii/create-pii/create-pii.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreatePiiComponent": () => (/* binding */ CreatePiiComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/pii.service */ 8203);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreatePiiComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreatePiiComponent = /*#__PURE__*/(() => {
  class CreatePiiComponent {
    constructor(piiService, fb) {
      this.piiService = piiService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.piiForm = this.fb.group({
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        date_of_birth: [null],
        gender: [''],
        marital_status: [''],
        biography: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.piiform.valid) {
      event.preventDefault();
      console.log("Pii Form Value", this.piiForm.value);
      //create pii call 
      //use subscribe with next and error object as per new standard
      this.piiService.createUserPii(this.piiForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.piiForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create PII completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreatePiiComponent_Factory(t) {
      return new (t || CreatePiiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__.PiiService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreatePiiComponent,
      selectors: [["app-create-pii"]],
      decls: 35,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "text", "placeholder", "Enter User Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "date_of_birth", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "date_of_birth", "id", "date_of_birth", "type", "date", "placeholder", "Enter date of birth", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "gender", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "gender", "id", "gender", "type", "text", "placeholder", "Enter Gender", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "marital_status", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "marital_status", "id", "marital_status", "type", "text", "placeholder", "Enter Marital Status", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "biography", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "biography", "id", "biography", "placeholder", "Enter Biography", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreatePiiComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "PII DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreatePiiComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, CreatePiiComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Date of Birth");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Gender");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 4)(23, "label", 12)(24, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Marital Status");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](26, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 14)(28, "label", 15)(29, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Biography");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](31, "textarea", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div", 17)(33, "button", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, " Create Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.piiForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.piiForm && (ctx.piiForm == null ? null : (tmp_1_0 = ctx.piiForm.get("user_id")) == null ? null : tmp_1_0.invalid) && ((ctx.piiForm == null ? null : (tmp_1_0 = ctx.piiForm.get("user_id")) == null ? null : tmp_1_0.dirty) || (ctx.piiForm == null ? null : (tmp_1_0 = ctx.piiForm.get("user_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.piiForm && ctx.piiForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreatePiiComponent;
})();

/***/ }),

/***/ 5758:
/*!***************************************************************!*\
  !*** ./src/app/shared/pii/delete-pii/delete-pii.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeletePiiComponent": () => (/* binding */ DeletePiiComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/pii.service */ 8203);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeletePiiComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeletePiiComponent = /*#__PURE__*/(() => {
  class DeletePiiComponent {
    constructor(piiService, fb) {
      this.piiService = piiService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        userId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deletePii() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.userId;
        this.piiService.deleteUserPii(id).subscribe({
          next: response => {
            console.log('User pii deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error getting piis:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeletePiiComponent_Factory(t) {
      return new (t || DeletePiiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__.PiiService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeletePiiComponent,
      selectors: [["app-delete-pii"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "userId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "userId", "id", "userId", "type", "number", "placeholder", "Enter User ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeletePiiComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete User Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeletePiiComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deletePii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeletePiiComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete User Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("userId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("userId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("userId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeletePiiComponent;
})();

/***/ }),

/***/ 1351:
/*!*********************************************************!*\
  !*** ./src/app/shared/pii/get-pii/get-pii.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetPiiComponent": () => (/* binding */ GetPiiComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/pii.service */ 8203);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function GetPiiComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let GetPiiComponent = /*#__PURE__*/(() => {
  class GetPiiComponent {
    constructor(piiService, fb) {
      this.piiService = piiService;
      this.fb = fb;
      this.getForm = this.fb.group({
        userId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
      this.piiUserId = 0;
      this.bio = "";
    }
    getPii() {
      //get all Piis
      if (this.getForm.valid) {
        const id = this.getForm.value.userId;
        this.piiService.getUserPii(id).subscribe({
          next: response => {
            this.piiUserId = response.user_id;
            this.bio = response.biography;
            console.log('User pii get successfully:', response);
            this.getForm.reset();
          },
          error: error => {
            console.error('Error deleting pii:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function GetPiiComponent_Factory(t) {
      return new (t || GetPiiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__.PiiService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetPiiComponent,
      selectors: [["app-get-pii"]],
      decls: 18,
      vars: 5,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "userId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "userId", "id", "userId", "type", "number", "placeholder", "Enter User ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function GetPiiComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Get User Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function GetPiiComponent_Template_form_ngSubmit_5_listener() {
            return ctx.getPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, GetPiiComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Get User Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.getForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.invalid) && ((ctx.getForm == null ? null : (tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.getForm.get("userId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.getForm && ctx.getForm.invalid);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("UserId: ", ctx.piiUserId, "");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Bio: ", ctx.bio, "");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return GetPiiComponent;
})();

/***/ }),

/***/ 899:
/*!*****************************************************************!*\
  !*** ./src/app/shared/pii/pii-landing/pii-landing.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PiiLandingComponent": () => (/* binding */ PiiLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let PiiLandingComponent = /*#__PURE__*/(() => {
  class PiiLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetUserPii() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-pii');
    }
    onCreateUserPii() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-pii');
    }
    onDeleteUserPii() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-pii');
    }
    onUpdateUserPii() {
      this.router.navigateByUrl('/update-pii');
    }
    static #_ = this.ɵfac = function PiiLandingComponent_Factory(t) {
      return new (t || PiiLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: PiiLandingComponent,
      selectors: [["app-pii-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function PiiLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PiiLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetUserPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PiiLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateUserPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PiiLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteUserPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PiiLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateUserPii();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return PiiLandingComponent;
})();

/***/ }),

/***/ 7285:
/*!***************************************************************!*\
  !*** ./src/app/shared/pii/update-pii/update-pii.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdatePiiComponent": () => (/* binding */ UpdatePiiComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/pii.service */ 8203);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdatePiiComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "User Id is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdatePiiComponent = /*#__PURE__*/(() => {
  class UpdatePiiComponent {
    constructor(piiService, fb) {
      this.piiService = piiService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.piiUpdatedForm = this.fb.group({
        user_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        date_of_birth: [''],
        gender: [''],
        marital_status: [''],
        biography: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log("Pii Form Value", this.piiUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.piiService.updateUserPii(this.piiUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.piiUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated pii completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdatePiiComponent_Factory(t) {
      return new (t || UpdatePiiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_pii_service__WEBPACK_IMPORTED_MODULE_0__.PiiService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdatePiiComponent,
      selectors: [["app-update-pii"]],
      decls: 35,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "user_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "user_id", "id", "user_id", "type", "text", "placeholder", "Enter User Id", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "date_of_birth", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "date_of_birth", "id", "date_of_birth", "type", "text", "placeholder", "Enter date of birth", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "gender", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "gender", "id", "gender", "type", "text", "placeholder", "Enter Gender", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "marital_status", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "marital_status", "id", "marital_status", "type", "text", "placeholder", "Enter Marital Status", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "biography", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "biography", "id", "biography", "placeholder", "Enter Biography", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdatePiiComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE PII DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdatePiiComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "User Id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdatePiiComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Date of Birth");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Gender");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 4)(23, "label", 12)(24, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Marital Status");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](26, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 14)(28, "label", 15)(29, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Biography");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](31, "textarea", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div", 17)(33, "button", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, " Update Pii ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.piiUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.piiUpdatedForm && (ctx.piiUpdatedForm == null ? null : (tmp_1_0 = ctx.piiUpdatedForm.get("user_id")) == null ? null : tmp_1_0.invalid) && ((ctx.piiUpdatedForm == null ? null : (tmp_1_0 = ctx.piiUpdatedForm.get("user_id")) == null ? null : tmp_1_0.dirty) || (ctx.piiUpdatedForm == null ? null : (tmp_1_0 = ctx.piiUpdatedForm.get("user_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.piiUpdatedForm && ctx.piiUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdatePiiComponent;
})();

/***/ }),

/***/ 183:
/*!*********************************************************************!*\
  !*** ./src/app/shared/quest/create-quest/create-quest.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateQuestComponent": () => (/* binding */ CreateQuestComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let CreateQuestComponent = /*#__PURE__*/(() => {
  class CreateQuestComponent {
    static #_ = this.ɵfac = function CreateQuestComponent_Factory(t) {
      return new (t || CreateQuestComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: CreateQuestComponent,
      selectors: [["app-create-quest"]],
      decls: 2,
      vars: 0,
      template: function CreateQuestComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-quest works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return CreateQuestComponent;
})();

/***/ }),

/***/ 4339:
/*!*********************************************************************!*\
  !*** ./src/app/shared/quest/delete-quest/delete-quest.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteQuestComponent": () => (/* binding */ DeleteQuestComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let DeleteQuestComponent = /*#__PURE__*/(() => {
  class DeleteQuestComponent {
    static #_ = this.ɵfac = function DeleteQuestComponent_Factory(t) {
      return new (t || DeleteQuestComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DeleteQuestComponent,
      selectors: [["app-delete-quest"]],
      decls: 2,
      vars: 0,
      template: function DeleteQuestComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "delete-quest works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return DeleteQuestComponent;
})();

/***/ }),

/***/ 9708:
/*!***************************************************************!*\
  !*** ./src/app/shared/quest/get-quest/get-quest.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetQuestComponent": () => (/* binding */ GetQuestComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let GetQuestComponent = /*#__PURE__*/(() => {
  class GetQuestComponent {
    static #_ = this.ɵfac = function GetQuestComponent_Factory(t) {
      return new (t || GetQuestComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: GetQuestComponent,
      selectors: [["app-get-quest"]],
      decls: 2,
      vars: 0,
      template: function GetQuestComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "get-quest works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return GetQuestComponent;
})();

/***/ }),

/***/ 1001:
/*!***********************************************************************!*\
  !*** ./src/app/shared/quest/quest-landing/quest-landing.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuestLandingComponent": () => (/* binding */ QuestLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let QuestLandingComponent = /*#__PURE__*/(() => {
  class QuestLandingComponent {
    static #_ = this.ɵfac = function QuestLandingComponent_Factory(t) {
      return new (t || QuestLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: QuestLandingComponent,
      selectors: [["app-quest-landing"]],
      decls: 2,
      vars: 0,
      template: function QuestLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "quest-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return QuestLandingComponent;
})();

/***/ }),

/***/ 7790:
/*!*********************************************************************!*\
  !*** ./src/app/shared/quest/update-quest/update-quest.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateQuestComponent": () => (/* binding */ UpdateQuestComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UpdateQuestComponent = /*#__PURE__*/(() => {
  class UpdateQuestComponent {
    static #_ = this.ɵfac = function UpdateQuestComponent_Factory(t) {
      return new (t || UpdateQuestComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateQuestComponent,
      selectors: [["app-update-quest"]],
      decls: 2,
      vars: 0,
      template: function UpdateQuestComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "update-quest works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return UpdateQuestComponent;
})();

/***/ }),

/***/ 1758:
/*!*********************************************************************!*\
  !*** ./src/app/shared/roles/create-roles/create-roles.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateRolesComponent": () => (/* binding */ CreateRolesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/roles.service */ 7245);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateRolesComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organization ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateRolesComponent = /*#__PURE__*/(() => {
  class CreateRolesComponent {
    constructor(roleService, fb) {
      this.roleService = roleService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.rolesForm = this.fb.group({
        role_type: [''],
        organization_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        role_status: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.rolesForm.valid) {
      event.preventDefault();
      console.log('Role Form Value', this.rolesForm.value);
      //create roles call
      //use subscribe with next and error object as per new standard
      this.roleService.createUserRole(this.rolesForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.rolesForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Role completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateRolesComponent_Factory(t) {
      return new (t || CreateRolesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__.RolesService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateRolesComponent,
      selectors: [["app-create-roles"]],
      decls: 25,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "role_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "role_type", "id", "role_type", "type", "text", "placeholder", "Enter Role Type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "organization_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_id", "id", "organization_id", "type", "number", "placeholder", "Enter Org ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], [1, "mb-6"], ["for", "role_status", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "role_status", "id", "role_status", "placeholder", "Enter Role Status", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateRolesComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "ROLE DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateRolesComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Role Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 4)(12, "label", 7)(13, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Role Organization ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](16, CreateRolesComponent_div_16_Template, 3, 0, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 10)(18, "label", 11)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Role Status");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 13)(23, "button", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, " Create Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.rolesForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.rolesForm && (ctx.rolesForm == null ? null : (tmp_1_0 = ctx.rolesForm.get("organization_id")) == null ? null : tmp_1_0.invalid) && ((ctx.rolesForm == null ? null : (tmp_1_0 = ctx.rolesForm.get("organization_id")) == null ? null : tmp_1_0.dirty) || (ctx.rolesForm == null ? null : (tmp_1_0 = ctx.rolesForm.get("organization_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.rolesForm && ctx.rolesForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateRolesComponent;
})();

/***/ }),

/***/ 8178:
/*!*********************************************************************!*\
  !*** ./src/app/shared/roles/delete-roles/delete-roles.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteRolesComponent": () => (/* binding */ DeleteRolesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/roles.service */ 7245);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteRolesComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Role ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteRolesComponent = /*#__PURE__*/(() => {
  class DeleteRolesComponent {
    constructor(roleService, fb) {
      this.roleService = roleService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        roleId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteRole() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.roleId;
        this.roleService.deleteUserRoles(id).subscribe({
          next: response => {
            console.log('Role deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting role:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteRolesComponent_Factory(t) {
      return new (t || DeleteRolesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__.RolesService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteRolesComponent,
      selectors: [["app-delete-roles"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "roleId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "roleId", "id", "roleId", "type", "number", "placeholder", "Enter Role ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteRolesComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteRolesComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteRole();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Role ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteRolesComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("roleId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("roleId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("roleId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteRolesComponent;
})();

/***/ }),

/***/ 2536:
/*!***************************************************************!*\
  !*** ./src/app/shared/roles/get-roles/get-roles.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetRolesComponent": () => (/* binding */ GetRolesComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/roles.service */ 7245);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);



function GetRolesComponent_div_5_li_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const role_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"]("", role_r4.role_type, " , ", role_r4.role_id, "");
  }
}
function GetRolesComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, GetRolesComponent_div_5_li_2_Template, 2, 2, "li", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.roles);
  }
}
function GetRolesComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0, " No roles found.\n");
  }
}
let GetRolesComponent = /*#__PURE__*/(() => {
  class GetRolesComponent {
    constructor(roleService) {
      this.roleService = roleService;
      this.roles = [];
    }
    ngOnInit() {
      //get all roles
      this.roleService.getUserRoles().subscribe({
        next: data => {
          this.roles = data;
          console.log('Roles:', this.roles);
        },
        error: error => {
          console.error('Error fetching roles:', error);
        },
        complete: () => {
          console.log('Request to fetch Role completed');
        }
      });
    }
    static #_ = this.ɵfac = function GetRolesComponent_Factory(t) {
      return new (t || GetRolesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__.RolesService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetRolesComponent,
      selectors: [["app-get-roles"]],
      decls: 8,
      vars: 2,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-full"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [4, "ngIf", "ngIfElse"], ["noData", ""], [4, "ngFor", "ngForOf"]],
      template: function GetRolesComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "ROLE TYPE & ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, GetRolesComponent_div_5_Template, 3, 1, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GetRolesComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.roles.length > 0)("ngIfElse", _r1);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf]
    });
  }
  return GetRolesComponent;
})();

/***/ }),

/***/ 5974:
/*!*********************************************************************!*\
  !*** ./src/app/shared/roles/role-landing/role-landing.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoleLandingComponent": () => (/* binding */ RoleLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let RoleLandingComponent = /*#__PURE__*/(() => {
  class RoleLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetRole() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-role');
    }
    onCreateRole() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-role');
    }
    onDeleteRole() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-role');
    }
    onUpdateRole() {
      this.router.navigateByUrl('/update-role');
    }
    static #_ = this.ɵfac = function RoleLandingComponent_Factory(t) {
      return new (t || RoleLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: RoleLandingComponent,
      selectors: [["app-role-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function RoleLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RoleLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetRole();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RoleLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateRole();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RoleLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteRole();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RoleLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateRole();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return RoleLandingComponent;
})();

/***/ }),

/***/ 5337:
/*!*********************************************************************!*\
  !*** ./src/app/shared/roles/update-roles/update-roles.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateRolesComponent": () => (/* binding */ UpdateRolesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/roles.service */ 7245);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdateRolesComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Role ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
function UpdateRolesComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Organization ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateRolesComponent = /*#__PURE__*/(() => {
  class UpdateRolesComponent {
    constructor(roleService, fb) {
      this.roleService = roleService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.roleUpdatedForm = this.fb.group({
        role_id: [''],
        role_type: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        organization_id: [''],
        role_status: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log('Role Updated Form Value', this.roleUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.roleService.updateUserRole(this.roleUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.roleUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated Role completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateRolesComponent_Factory(t) {
      return new (t || UpdateRolesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_roles_service__WEBPACK_IMPORTED_MODULE_0__.RolesService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateRolesComponent,
      selectors: [["app-update-roles"]],
      decls: 31,
      vars: 4,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "role_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "role_id", "id", "role_id", "type", "number", "placeholder", "Enter Role ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "role_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "role_type", "id", "role_type", "type", "text", "placeholder", "Enter Role Type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "organization_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "organization_id", "id", "organization_id", "type", "number", "placeholder", "Enter Org ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "role_status", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "role_status", "id", "role_status", "type", "text", "placeholder", "Enter Role Status", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdateRolesComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE ROLE DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateRolesComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Role ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateRolesComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Role Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Role Organization_id");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](22, UpdateRolesComponent_div_22_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "div", 4)(24, "label", 12)(25, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26, "Role Status");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](27, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "div", 14)(29, "button", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, " Update Role ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.roleUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.roleUpdatedForm && (ctx.roleUpdatedForm == null ? null : (tmp_1_0 = ctx.roleUpdatedForm.get("role_id")) == null ? null : tmp_1_0.invalid) && ((ctx.roleUpdatedForm == null ? null : (tmp_1_0 = ctx.roleUpdatedForm.get("role_id")) == null ? null : tmp_1_0.dirty) || (ctx.roleUpdatedForm == null ? null : (tmp_1_0 = ctx.roleUpdatedForm.get("role_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.roleUpdatedForm && (ctx.roleUpdatedForm == null ? null : (tmp_2_0 = ctx.roleUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.invalid) && ((ctx.roleUpdatedForm == null ? null : (tmp_2_0 = ctx.roleUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.dirty) || (ctx.roleUpdatedForm == null ? null : (tmp_2_0 = ctx.roleUpdatedForm.get("organization_id")) == null ? null : tmp_2_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.roleUpdatedForm && ctx.roleUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdateRolesComponent;
})();

/***/ }),

/***/ 4466:
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @angular/common */ 6895);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @angular/router */ 4793);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @angular/material/select */ 4385);
/* harmony import */ var _layout_footer_footer_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./layout/footer/footer.component */ 1070);
/* harmony import */ var _layout_header_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./layout/header/header.component */ 4162);
/* harmony import */ var _layout_page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./layout/page-not-found/page-not-found.component */ 742);
/* harmony import */ var _layout_page_error_page_error_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./layout/page-error/page-error.component */ 5768);
/* harmony import */ var _roles_role_landing_role_landing_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./roles/role-landing/role-landing.component */ 5974);
/* harmony import */ var _roles_get_roles_get_roles_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./roles/get-roles/get-roles.component */ 2536);
/* harmony import */ var _roles_create_roles_create_roles_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./roles/create-roles/create-roles.component */ 1758);
/* harmony import */ var _roles_update_roles_update_roles_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./roles/update-roles/update-roles.component */ 5337);
/* harmony import */ var _roles_delete_roles_delete_roles_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./roles/delete-roles/delete-roles.component */ 8178);
/* harmony import */ var _tags_tag_landing_tag_landing_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./tags/tag-landing/tag-landing.component */ 7322);
/* harmony import */ var _tags_get_tags_get_tags_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./tags/get-tags/get-tags.component */ 9904);
/* harmony import */ var _tags_create_tags_create_tags_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./tags/create-tags/create-tags.component */ 4768);
/* harmony import */ var _tags_update_tags_update_tags_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./tags/update-tags/update-tags.component */ 4938);
/* harmony import */ var _tags_delete_tags_delete_tags_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./tags/delete-tags/delete-tags.component */ 404);
/* harmony import */ var _pii_pii_landing_pii_landing_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pii/pii-landing/pii-landing.component */ 899);
/* harmony import */ var _pii_get_pii_get_pii_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pii/get-pii/get-pii.component */ 1351);
/* harmony import */ var _pii_create_pii_create_pii_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pii/create-pii/create-pii.component */ 2950);
/* harmony import */ var _pii_delete_pii_delete_pii_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pii/delete-pii/delete-pii.component */ 5758);
/* harmony import */ var _pii_update_pii_update_pii_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./pii/update-pii/update-pii.component */ 7285);
/* harmony import */ var _links_links_landing_links_landing_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./links/links-landing/links-landing.component */ 624);
/* harmony import */ var _links_get_links_get_links_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./links/get-links/get-links.component */ 3576);
/* harmony import */ var _links_create_links_create_links_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./links/create-links/create-links.component */ 5217);
/* harmony import */ var _links_update_links_update_links_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./links/update-links/update-links.component */ 3849);
/* harmony import */ var _links_delete_links_delete_links_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./links/delete-links/delete-links.component */ 3976);
/* harmony import */ var _journey_journey_landing_journey_landing_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./journey/journey-landing/journey-landing.component */ 6671);
/* harmony import */ var _journey_get_journey_get_journey_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./journey/get-journey/get-journey.component */ 4647);
/* harmony import */ var _journey_create_journey_create_journey_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./journey/create-journey/create-journey.component */ 3783);
/* harmony import */ var _journey_update_journey_update_journey_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./journey/update-journey/update-journey.component */ 8455);
/* harmony import */ var _journey_delete_journey_delete_journey_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./journey/delete-journey/delete-journey.component */ 4251);
/* harmony import */ var _trigger_trigger_landing_trigger_landing_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./trigger/trigger-landing/trigger-landing.component */ 4666);
/* harmony import */ var _trigger_get_trigger_get_trigger_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./trigger/get-trigger/get-trigger.component */ 4813);
/* harmony import */ var _trigger_update_trigger_update_trigger_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./trigger/update-trigger/update-trigger.component */ 3298);
/* harmony import */ var _trigger_create_trigger_create_trigger_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./trigger/create-trigger/create-trigger.component */ 4342);
/* harmony import */ var _trigger_delete_trigger_delete_trigger_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./trigger/delete-trigger/delete-trigger.component */ 9049);
/* harmony import */ var _quest_quest_landing_quest_landing_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./quest/quest-landing/quest-landing.component */ 1001);
/* harmony import */ var _quest_get_quest_get_quest_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./quest/get-quest/get-quest.component */ 9708);
/* harmony import */ var _quest_create_quest_create_quest_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./quest/create-quest/create-quest.component */ 183);
/* harmony import */ var _quest_update_quest_update_quest_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./quest/update-quest/update-quest.component */ 7790);
/* harmony import */ var _quest_delete_quest_delete_quest_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./quest/delete-quest/delete-quest.component */ 4339);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @angular/platform-browser/animations */ 4934);
/* harmony import */ var _quest_badge_landing_badge_landing_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../quest/badge-landing/badge-landing.component */ 5027);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/core */ 4650);














































let SharedModule = /*#__PURE__*/(() => {
  class SharedModule {
    static #_ = this.ɵfac = function SharedModule_Factory(t) {
      return new (t || SharedModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_40__["ɵɵdefineNgModule"]({
      type: SharedModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_40__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_41__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_42__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_43__.ReactiveFormsModule, _angular_material_select__WEBPACK_IMPORTED_MODULE_44__.MatSelectModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_45__.BrowserAnimationsModule]
    });
  }
  return SharedModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_40__["ɵɵsetNgModuleScope"](SharedModule, {
    declarations: [_layout_footer_footer_component__WEBPACK_IMPORTED_MODULE_0__.FooterComponent, _layout_header_header_component__WEBPACK_IMPORTED_MODULE_1__.HeaderComponent, _layout_page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_2__.PageNotFoundComponent, _layout_page_error_page_error_component__WEBPACK_IMPORTED_MODULE_3__.PageErrorComponent, _roles_role_landing_role_landing_component__WEBPACK_IMPORTED_MODULE_4__.RoleLandingComponent, _roles_get_roles_get_roles_component__WEBPACK_IMPORTED_MODULE_5__.GetRolesComponent, _roles_create_roles_create_roles_component__WEBPACK_IMPORTED_MODULE_6__.CreateRolesComponent, _roles_update_roles_update_roles_component__WEBPACK_IMPORTED_MODULE_7__.UpdateRolesComponent, _roles_delete_roles_delete_roles_component__WEBPACK_IMPORTED_MODULE_8__.DeleteRolesComponent, _tags_tag_landing_tag_landing_component__WEBPACK_IMPORTED_MODULE_9__.TagLandingComponent, _tags_get_tags_get_tags_component__WEBPACK_IMPORTED_MODULE_10__.GetTagsComponent, _tags_create_tags_create_tags_component__WEBPACK_IMPORTED_MODULE_11__.CreateTagsComponent, _tags_update_tags_update_tags_component__WEBPACK_IMPORTED_MODULE_12__.UpdateTagsComponent, _tags_delete_tags_delete_tags_component__WEBPACK_IMPORTED_MODULE_13__.DeleteTagsComponent, _pii_pii_landing_pii_landing_component__WEBPACK_IMPORTED_MODULE_14__.PiiLandingComponent, _pii_get_pii_get_pii_component__WEBPACK_IMPORTED_MODULE_15__.GetPiiComponent, _pii_create_pii_create_pii_component__WEBPACK_IMPORTED_MODULE_16__.CreatePiiComponent, _pii_delete_pii_delete_pii_component__WEBPACK_IMPORTED_MODULE_17__.DeletePiiComponent, _pii_update_pii_update_pii_component__WEBPACK_IMPORTED_MODULE_18__.UpdatePiiComponent, _links_links_landing_links_landing_component__WEBPACK_IMPORTED_MODULE_19__.LinksLandingComponent, _links_get_links_get_links_component__WEBPACK_IMPORTED_MODULE_20__.GetLinksComponent, _links_create_links_create_links_component__WEBPACK_IMPORTED_MODULE_21__.CreateLinksComponent, _links_update_links_update_links_component__WEBPACK_IMPORTED_MODULE_22__.UpdateLinksComponent, _links_delete_links_delete_links_component__WEBPACK_IMPORTED_MODULE_23__.DeleteLinksComponent, _journey_journey_landing_journey_landing_component__WEBPACK_IMPORTED_MODULE_24__.JourneyLandingComponent, _journey_get_journey_get_journey_component__WEBPACK_IMPORTED_MODULE_25__.GetJourneyComponent, _journey_create_journey_create_journey_component__WEBPACK_IMPORTED_MODULE_26__.CreateJourneyComponent, _journey_update_journey_update_journey_component__WEBPACK_IMPORTED_MODULE_27__.UpdateJourneyComponent, _journey_delete_journey_delete_journey_component__WEBPACK_IMPORTED_MODULE_28__.DeleteJourneyComponent, _trigger_trigger_landing_trigger_landing_component__WEBPACK_IMPORTED_MODULE_29__.TriggerLandingComponent, _trigger_get_trigger_get_trigger_component__WEBPACK_IMPORTED_MODULE_30__.GetTriggerComponent, _trigger_update_trigger_update_trigger_component__WEBPACK_IMPORTED_MODULE_31__.UpdateTriggerComponent, _trigger_create_trigger_create_trigger_component__WEBPACK_IMPORTED_MODULE_32__.CreateTriggerComponent, _trigger_delete_trigger_delete_trigger_component__WEBPACK_IMPORTED_MODULE_33__.DeleteTriggerComponent, _quest_quest_landing_quest_landing_component__WEBPACK_IMPORTED_MODULE_34__.QuestLandingComponent, _quest_get_quest_get_quest_component__WEBPACK_IMPORTED_MODULE_35__.GetQuestComponent, _quest_create_quest_create_quest_component__WEBPACK_IMPORTED_MODULE_36__.CreateQuestComponent, _quest_update_quest_update_quest_component__WEBPACK_IMPORTED_MODULE_37__.UpdateQuestComponent, _quest_delete_quest_delete_quest_component__WEBPACK_IMPORTED_MODULE_38__.DeleteQuestComponent, _quest_badge_landing_badge_landing_component__WEBPACK_IMPORTED_MODULE_39__.BadgeLandingComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_41__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_42__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_43__.ReactiveFormsModule, _angular_material_select__WEBPACK_IMPORTED_MODULE_44__.MatSelectModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_45__.BrowserAnimationsModule],
    exports: [_layout_footer_footer_component__WEBPACK_IMPORTED_MODULE_0__.FooterComponent, _layout_header_header_component__WEBPACK_IMPORTED_MODULE_1__.HeaderComponent, _layout_page_not_found_page_not_found_component__WEBPACK_IMPORTED_MODULE_2__.PageNotFoundComponent, _layout_page_error_page_error_component__WEBPACK_IMPORTED_MODULE_3__.PageErrorComponent]
  });
})();

/***/ }),

/***/ 4768:
/*!******************************************************************!*\
  !*** ./src/app/shared/tags/create-tags/create-tags.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateTagsComponent": () => (/* binding */ CreateTagsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/tags.service */ 3171);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function CreateTagsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Tag ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let CreateTagsComponent = /*#__PURE__*/(() => {
  class CreateTagsComponent {
    constructor(tagService, fb) {
      this.tagService = tagService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.tagForm = this.fb.group({
        tag_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        tag_header: [''],
        tag_description: [''],
        tag_notes: [''],
        tag_owner_type: [''],
        tag_owner: [''],
        display_tag: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      // if (this.tagForm.valid) {
      event.preventDefault();
      console.log('Tag Form Value', this.tagForm.value);
      //create tag call
      //use subscribe with next and error object as per new standard
      this.tagService.createTag(this.tagForm.value).subscribe({
        next: response => {
          console.log('Form submitted successfully:', response);
          this.tagForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Create Tag completed');
        }
      });
    }
    static #_ = this.ɵfac = function CreateTagsComponent_Factory(t) {
      return new (t || CreateTagsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__.TagsService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CreateTagsComponent,
      selectors: [["app-create-tags"]],
      decls: 45,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "tag_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_id", "id", "tag_id", "type", "number", "placeholder", "Enter Tag ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "tag_header", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_header", "id", "tag_header", "type", "text", "placeholder", "Enter Tag Header", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_description", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_description", "id", "tag_description", "type", "text", "placeholder", "Enter Tag Description", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "tag_notes", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_notes", "id", "tag_notes", "placeholder", "Enter Tag Notes", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_owner_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_owner_type", "id", "tag_owner_type", "type", "text", "placeholder", "Enter Tag Owner Type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_owner", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_owner", "id", "tag_owner", "type", "text", "placeholder", "Enter Tag Owner", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "display_tag", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "display_tag", "id", "display_tag", "type", "text", "placeholder", "Enter Display Tag", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function CreateTagsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "TAG DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CreateTagsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Tag ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, CreateTagsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Tag Header");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Tag Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 12)(23, "label", 13)(24, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Tag Notes");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](26, "textarea", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 4)(28, "label", 15)(29, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Tag Owner Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](31, "input", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div", 4)(33, "label", 17)(34, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "Tag Owner");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](36, "input", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div", 4)(38, "label", 19)(39, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](40, "Display Tag");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](41, "input", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 21)(43, "button", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](44, " Create Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.tagForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.tagForm && (ctx.tagForm == null ? null : (tmp_1_0 = ctx.tagForm.get("tag_id")) == null ? null : tmp_1_0.invalid) && ((ctx.tagForm == null ? null : (tmp_1_0 = ctx.tagForm.get("tag_id")) == null ? null : tmp_1_0.dirty) || (ctx.tagForm == null ? null : (tmp_1_0 = ctx.tagForm.get("tag_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](32);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.tagForm && ctx.tagForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return CreateTagsComponent;
})();

/***/ }),

/***/ 404:
/*!******************************************************************!*\
  !*** ./src/app/shared/tags/delete-tags/delete-tags.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteTagsComponent": () => (/* binding */ DeleteTagsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/tags.service */ 3171);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function DeleteTagsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Valid Tag ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let DeleteTagsComponent = /*#__PURE__*/(() => {
  class DeleteTagsComponent {
    constructor(tagService, fb) {
      this.tagService = tagService;
      this.fb = fb;
      this.deleteForm = this.fb.group({
        tagId: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]]
      });
    }
    deleteTag() {
      if (this.deleteForm.valid) {
        const id = this.deleteForm.value.orgId;
        this.tagService.deleteTags(id).subscribe({
          next: response => {
            console.log('Tag deleted successfully:', response);
            this.deleteForm.reset();
          },
          error: error => {
            console.error('Error deleting tag:', error);
          }
        });
      }
    }
    static #_ = this.ɵfac = function DeleteTagsComponent_Factory(t) {
      return new (t || DeleteTagsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__.TagsService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: DeleteTagsComponent,
      selectors: [["app-delete-tags"]],
      decls: 14,
      vars: 3,
      consts: [[1, "mt-6", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-xl", "text-center", "font-bold", "mb-4"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "tagId", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tagId", "id", "tagId", "type", "number", "placeholder", "Enter Tag ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["type", "submit", 1, "bg-red-400", "hover:bg-red-500", "rounded-full", "w-full", "text-white", "font-bold", "py-2", "px-4", "rounded", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function DeleteTagsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Delete Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function DeleteTagsComponent_Template_form_ngSubmit_5_listener() {
            return ctx.deleteTag();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Tag ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, DeleteTagsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "button", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Delete Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.deleteForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("tagId")) == null ? null : tmp_1_0.invalid) && ((ctx.deleteForm == null ? null : (tmp_1_0 = ctx.deleteForm.get("tagId")) == null ? null : tmp_1_0.dirty) || ((tmp_1_0 = ctx.deleteForm.get("tagId")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.deleteForm && ctx.deleteForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return DeleteTagsComponent;
})();

/***/ }),

/***/ 9904:
/*!************************************************************!*\
  !*** ./src/app/shared/tags/get-tags/get-tags.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTagsComponent": () => (/* binding */ GetTagsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/tags.service */ 3171);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6895);



function GetTagsComponent_div_5_li_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const tag_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](tag_r4.tag_id);
  }
}
function GetTagsComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, GetTagsComponent_div_5_li_2_Template, 2, 1, "li", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.tags);
  }
}
function GetTagsComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](0, " No tags found.\n");
  }
}
let GetTagsComponent = /*#__PURE__*/(() => {
  class GetTagsComponent {
    constructor(orgService) {
      this.orgService = orgService;
      this.tags = [];
    }
    ngOnInit() {
      //get all tags
      this.orgService.getTags().subscribe({
        next: data => {
          this.tags = data;
          console.log('Tags:', this.tags);
        },
        error: error => {
          console.error('Error fetching tags:', error);
        },
        complete: () => {
          console.log('Request to fetch Tag completed');
        }
      });
    }
    static #_ = this.ɵfac = function GetTagsComponent_Factory(t) {
      return new (t || GetTagsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__.TagsService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: GetTagsComponent,
      selectors: [["app-get-tags"]],
      decls: 8,
      vars: 2,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-full"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [4, "ngIf", "ngIfElse"], ["noData", ""], [4, "ngFor", "ngForOf"]],
      template: function GetTagsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "TAG ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, GetTagsComponent_div_5_Template, 3, 1, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GetTagsComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.tags.length > 0)("ngIfElse", _r1);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf]
    });
  }
  return GetTagsComponent;
})();

/***/ }),

/***/ 7322:
/*!******************************************************************!*\
  !*** ./src/app/shared/tags/tag-landing/tag-landing.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TagLandingComponent": () => (/* binding */ TagLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 4793);


let TagLandingComponent = /*#__PURE__*/(() => {
  class TagLandingComponent {
    constructor(router) {
      this.router = router;
    }
    onGetTag() {
      //using router to navigate on same page
      this.router.navigateByUrl('/get-tag');
    }
    onCreateTag() {
      //using router to navigate on same page
      this.router.navigateByUrl('/create-tag');
    }
    onDeleteTag() {
      //using router to navigate on same page
      this.router.navigateByUrl('/delete-tag');
    }
    onUpdateTag() {
      this.router.navigateByUrl('/update-tag');
    }
    static #_ = this.ɵfac = function TagLandingComponent_Factory(t) {
      return new (t || TagLandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: TagLandingComponent,
      selectors: [["app-tag-landing"]],
      decls: 13,
      vars: 0,
      consts: [[1, "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], ["type", "button", 1, "bg-gray-400", "mb-3", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "click"]],
      template: function TagLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "CHOOSE OPTION");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TagLandingComponent_Template_button_click_5_listener() {
            return ctx.onGetTag();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Get Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TagLandingComponent_Template_button_click_7_listener() {
            return ctx.onCreateTag();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Create Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TagLandingComponent_Template_button_click_9_listener() {
            return ctx.onDeleteTag();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Delete Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TagLandingComponent_Template_button_click_11_listener() {
            return ctx.onUpdateTag();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Update Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        }
      }
    });
  }
  return TagLandingComponent;
})();

/***/ }),

/***/ 4938:
/*!******************************************************************!*\
  !*** ./src/app/shared/tags/update-tags/update-tags.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateTagsComponent": () => (/* binding */ UpdateTagsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4006);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 4650);
/* harmony import */ var src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/tags.service */ 3171);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6895);





function UpdateTagsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "p", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Tag ID is required.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
}
let UpdateTagsComponent = /*#__PURE__*/(() => {
  class UpdateTagsComponent {
    constructor(tagService, fb) {
      this.tagService = tagService;
      this.fb = fb;
      //basic validators need to put check in UI
      this.tagUpdatedForm = this.fb.group({
        tag_id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
        tag_header: [''],
        tag_description: [''],
        tag_notes: [''],
        tag_owner_type: [''],
        tag_owner: [''],
        display_tag: ['']
      });
    }
    onSubmit(event) {
      //keep validation check for form
      event.preventDefault();
      console.log('Tag Updated Form Value', this.tagUpdatedForm.value);
      //use subscribe with next and error object as per new standard
      this.tagService.updateTag(this.tagUpdatedForm.value).subscribe({
        next: response => {
          console.log('Updated Form submitted successfully:', response);
          this.tagUpdatedForm.reset();
        },
        error: error => {
          console.error('Error submitting form:', error);
        },
        complete: () => {
          console.log('Updated Tag completed');
        }
      });
    }
    static #_ = this.ɵfac = function UpdateTagsComponent_Factory(t) {
      return new (t || UpdateTagsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_tags_service__WEBPACK_IMPORTED_MODULE_0__.TagsService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: UpdateTagsComponent,
      selectors: [["app-update-tags"]],
      decls: 45,
      vars: 3,
      consts: [[1, "flex", "items-center", "justify-center", "min-h-screen"], [1, "bg-white", "p-8", "rounded-lg", "shadow-md", "w-full", "max-w-lg"], [1, "text-lg", "font-bold", "text-center", "mb-3"], [3, "formGroup", "ngSubmit"], [1, "mb-4"], ["for", "tag_id", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_id", "id", "tag_id", "type", "number", "placeholder", "Enter Tag ID", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [4, "ngIf"], ["for", "tag_header", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_header", "id", "tag_header", "type", "text", "placeholder", "Enter Tag Header", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_description", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_description", "id", "tag_description", "type", "text", "placeholder", "Enter Tag Description", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "mb-6"], ["for", "tag_notes", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_notes", "id", "tag_notes", "placeholder", "Enter Tag Notes", "rows", "4", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_owner_type", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_owner_type", "id", "tag_owner_type", "type", "text", "placeholder", "Enter Tag Owner Type", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "tag_owner", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "tag_owner", "id", "tag_owner", "type", "text", "placeholder", "Enter Tag Owner", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], ["for", "display_tag", 1, "block", "text-gray-700", "text-sm", "mb-2"], ["formControlName", "display_tag", "id", "display_tag", "type", "text", "placeholder", "Enter Display Tag", 1, "shadow", "appearance-none", "border", "rounded", "w-full", "py-2", "px-3", "text-gray-700", "leading-tight", "focus:outline-none", "focus:shadow-outline"], [1, "flex", "items-center", "justify-between"], ["type", "submit", 1, "bg-gray-400", "hover:bg-gray-500", "w-full", "text-white", "py-2", "px-4", "rounded-full", "focus:outline-none", "focus:shadow-outline", 3, "disabled"], [1, "text-red-500", "text-xs", "italic"]],
      template: function UpdateTagsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h1", 2)(3, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "UPDATE TAG DETAILS");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "form", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function UpdateTagsComponent_Template_form_ngSubmit_5_listener($event) {
            return ctx.onSubmit($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4)(7, "label", 5)(8, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Tag ID");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, UpdateTagsComponent_div_11_Template, 3, 0, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 4)(13, "label", 8)(14, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Tag Header");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 4)(18, "label", 10)(19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Tag Description");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "input", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 12)(23, "label", 13)(24, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Tag Notes");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](26, "textarea", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 4)(28, "label", 15)(29, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Tag Owner Type");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](31, "input", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div", 4)(33, "label", 17)(34, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "Tag Owner");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](36, "input", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div", 4)(38, "label", 19)(39, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](40, "Display Tag");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](41, "input", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 21)(43, "button", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](44, " Update Tag ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_1_0;
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.tagUpdatedForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.tagUpdatedForm && (ctx.tagUpdatedForm == null ? null : (tmp_1_0 = ctx.tagUpdatedForm.get("tag_id")) == null ? null : tmp_1_0.invalid) && ((ctx.tagUpdatedForm == null ? null : (tmp_1_0 = ctx.tagUpdatedForm.get("tag_id")) == null ? null : tmp_1_0.dirty) || (ctx.tagUpdatedForm == null ? null : (tmp_1_0 = ctx.tagUpdatedForm.get("tag_id")) == null ? null : tmp_1_0.touched)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](32);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.tagUpdatedForm && ctx.tagUpdatedForm.invalid);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName]
    });
  }
  return UpdateTagsComponent;
})();

/***/ }),

/***/ 4342:
/*!***************************************************************************!*\
  !*** ./src/app/shared/trigger/create-trigger/create-trigger.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateTriggerComponent": () => (/* binding */ CreateTriggerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let CreateTriggerComponent = /*#__PURE__*/(() => {
  class CreateTriggerComponent {
    static #_ = this.ɵfac = function CreateTriggerComponent_Factory(t) {
      return new (t || CreateTriggerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: CreateTriggerComponent,
      selectors: [["app-create-trigger"]],
      decls: 2,
      vars: 0,
      template: function CreateTriggerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-trigger works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return CreateTriggerComponent;
})();

/***/ }),

/***/ 9049:
/*!***************************************************************************!*\
  !*** ./src/app/shared/trigger/delete-trigger/delete-trigger.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteTriggerComponent": () => (/* binding */ DeleteTriggerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let DeleteTriggerComponent = /*#__PURE__*/(() => {
  class DeleteTriggerComponent {
    static #_ = this.ɵfac = function DeleteTriggerComponent_Factory(t) {
      return new (t || DeleteTriggerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: DeleteTriggerComponent,
      selectors: [["app-delete-trigger"]],
      decls: 2,
      vars: 0,
      template: function DeleteTriggerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "delete-trigger works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return DeleteTriggerComponent;
})();

/***/ }),

/***/ 4813:
/*!*********************************************************************!*\
  !*** ./src/app/shared/trigger/get-trigger/get-trigger.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetTriggerComponent": () => (/* binding */ GetTriggerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let GetTriggerComponent = /*#__PURE__*/(() => {
  class GetTriggerComponent {
    static #_ = this.ɵfac = function GetTriggerComponent_Factory(t) {
      return new (t || GetTriggerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: GetTriggerComponent,
      selectors: [["app-get-trigger"]],
      decls: 2,
      vars: 0,
      template: function GetTriggerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "get-trigger works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return GetTriggerComponent;
})();

/***/ }),

/***/ 4666:
/*!*****************************************************************************!*\
  !*** ./src/app/shared/trigger/trigger-landing/trigger-landing.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TriggerLandingComponent": () => (/* binding */ TriggerLandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let TriggerLandingComponent = /*#__PURE__*/(() => {
  class TriggerLandingComponent {
    static #_ = this.ɵfac = function TriggerLandingComponent_Factory(t) {
      return new (t || TriggerLandingComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: TriggerLandingComponent,
      selectors: [["app-trigger-landing"]],
      decls: 2,
      vars: 0,
      template: function TriggerLandingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "trigger-landing works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return TriggerLandingComponent;
})();

/***/ }),

/***/ 3298:
/*!***************************************************************************!*\
  !*** ./src/app/shared/trigger/update-trigger/update-trigger.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateTriggerComponent": () => (/* binding */ UpdateTriggerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 4650);

let UpdateTriggerComponent = /*#__PURE__*/(() => {
  class UpdateTriggerComponent {
    static #_ = this.ɵfac = function UpdateTriggerComponent_Factory(t) {
      return new (t || UpdateTriggerComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: UpdateTriggerComponent,
      selectors: [["app-update-trigger"]],
      decls: 2,
      vars: 0,
      template: function UpdateTriggerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "update-trigger works!");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }
    });
  }
  return UpdateTriggerComponent;
})();

/***/ }),

/***/ 1652:
/*!*********************************************!*\
  !*** ./src/environments/environment.dev.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
const environment = {
  production: false,
  environmentName: "development",
  apiUrl_user: 'http://api.mozli.com/UserProfile',
  apiUrl_event: 'http://api.mozli.com/Event',
  apiUrl_organization: 'http://api.mozli.com/Organization',
  apiUrl_connection: 'http://api.mozli.com/Social',
  apiUrl_profilePicture: 'http://localhost:2000/profile-picture',
  apiUrl_tags: 'http://api.mozli.com/Tag',
  apiUrl_userPii: 'http://api.mozli.com/Pii',
  apiUrl_socialMediLink: 'http://api.mozli.com/Link',
  apiUrl_roles: 'http://api.mozli.com/Role',
  apiUrl_themes: 'http://api.mozli.com/Theme',
  apiUrl_badges: 'http://api.mozli.com/Badge'
};
// Dont forget to copy over the parts in angular
// GetUserPii/{id}  [working]
// GetSocialMediaLinks/id
// AddSocialMediaLink
// UpdateSocialMediaLink
// UpdateSocialMediaLinks
// DeleteSocialMediaLink/id
// https://www.amazon.com/dp/B0D28Y843K?psc=1&ref=ppx_yo2ov_dt_b_product_details
// GetSocialMediaLinks/id
// GetSocialMediaLinks/{id}  [working]
// {{domain}}/GetSocialMediaLinks/105

/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 1481);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);